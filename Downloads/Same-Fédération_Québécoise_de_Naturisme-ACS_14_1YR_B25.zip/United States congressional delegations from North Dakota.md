**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/United%20States%20congressional%20delegations%20from%20North%20Dakota\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

United States congressional delegations from North Dakota
=========================================================

-   *North Dakota was admitted to the Union on November 2, 1889.*

North Dakota was admitted to the Union on November 2, 1889.

United States Senate
====================

Living former senators
======================

-   *As of January 2019\[update\], there are five living former
    senators.*

As of January 2019\[update\], there are five living former senators.

United States House of Representatives
======================================

Living former members of the House
==================================

-   *As of January 2019\[update\], there are five living former members
    of the House.*

As of January 2019\[update\], there are five living former members of
the House.

Key
===
