**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Endorsements%20in%20the%202020%20Republican%20Party%20presidential%20primaries\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Endorsements in the 2020 Republican Party presidential primaries
================================================================

-   *This is a list of endorsements for declared candidates for the
    Republican primaries for the 2020 United States presidential
    election.*

This is a list of endorsements for declared candidates for the
Republican primaries for the 2020 United States presidential election.

Donald Trump
============

Bill Weld
=========

References
==========
