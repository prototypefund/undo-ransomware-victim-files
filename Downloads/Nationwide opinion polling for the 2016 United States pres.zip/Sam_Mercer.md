**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Sam\_Mercer\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Sam Mercer
==========

-   *He also produced the M. Night Shyamalan films The Happening and The
    Last Airbender.*

-   *Sam Mercer is a producer of many Hollywood films, including several
    projects directed by M. Night Shyamalan such as Signs, Lady in the
    Water and Unbreakable, as well as other films like Van Helsing and
    Things We Lost in the Fire.*

Sam Mercer is a producer of many Hollywood films, including several
projects directed by M. Night Shyamalan such as Signs, Lady in the Water
and Unbreakable, as well as other films like Van Helsing and Things We
Lost in the Fire. His career started during the early 1980s as a
location manager and later advanced to a producer and executive
producer. He also produced the M. Night Shyamalan films The Happening
and The Last Airbender.

Filmography
===========

External links
==============

-   *Sam Mercer on IMDb*

Sam Mercer on IMDb
