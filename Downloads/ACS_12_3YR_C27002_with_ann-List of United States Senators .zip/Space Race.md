**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Space%20Race\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Space Race
==========

-   *The Space Race spawned pioneering efforts to launch artificial
    satellites, uncrewed space probes of the Moon, Venus, and Mars, and
    human spaceflight in low Earth orbit and to the Moon.*

-   *The Space Race has left a legacy of Earth communications and
    weather satellites, and continuing human space presence on the
    International Space Station.*

The Space Race refers to the 20th-century competition between two Cold
War rivals, the Soviet Union (USSR) and the United States (US), for
dominance in spaceflight capability. It had its origins in the
missile-based nuclear arms race between the two nations that occurred
following World War II, aided by captured German missile technology and
personnel from the Aggregat program.\
The technological superiority required for such dominance was seen as
necessary for national security, and symbolic of ideological
superiority. The Space Race spawned pioneering efforts to launch
artificial satellites, uncrewed space probes of the Moon, Venus, and
Mars, and human spaceflight in low Earth orbit and to the Moon.

The Space Race began on August 2, 1955, when the Soviet Union responded
to the US announcement four days earlier of intent to launch artificial
satellites for the International Geophysical Year, by declaring they
would also launch a satellite "in the near future". The Soviet Union
beat the US to the first successful launch, with the October 4, 1957,
orbiting of Sputnik 1, and later beat the US to have the first human in
earth orbit, Yuri Gagarin, on April 12, 1961. The "race" peaked with the
July 20, 1969, US landing of the first humans on the Moon with Apollo
11. The USSR attempted several crewed lunar missions but eventually
canceled them and concentrated on Earth orbital space stations.

A period of détente followed with the April 1972 agreement on a
co-operative Apollo–Soyuz Test Project, resulting in the July 1975
rendezvous in Earth orbit of a US astronaut crew with a Soviet cosmonaut
crew. The end of the Space Race is harder to pinpoint than its
beginning, but it was over by the December 1991 dissolution of the
Soviet Union, after which spaceflight cooperation between the US and
Russia flourished.

The Space Race has left a legacy of Earth communications and weather
satellites, and continuing human space presence on the International
Space Station. It has also sparked increases in spending on education
and research and development, which led to beneficial spin-off
technologies.

Early rocket development
========================

![](media/image1.jpg){width="4.473332239720035in" height="5.5in"}\
*Wernher von Braun (1912–1977), technical director of Nazi Germany's
missile program, became the United States' lead rocket engineer during
the 1950s and 1960s*

Germany during World War II
===========================

-   *The origins of the Space Race can be traced to Germany, beginning
    in the 1930s and continuing during World War II when Nazi Germany
    researched and built operational ballistic missiles capable of
    sub-orbital spaceflight.*

-   *After the war, the V-2 became the basis of early American and
    Soviet rocket designs.*

-   *They led the team that built the Aggregat-4 (A-4) rocket, which
    became the first vehicle to reach outer space during its test flight
    program in 1942 and 1943.*

The origins of the Space Race can be traced to Germany, beginning in the
1930s and continuing during World War II when Nazi Germany researched
and built operational ballistic missiles capable of sub-orbital
spaceflight. Starting in the early 1930s, during the last stages of the
Weimar Republic, German aerospace engineers experimented with
liquid-fueled rockets, with the goal that one day they would be capable
of reaching high altitudes and traversing long distances. The head of
the German Army's Ballistics and Munitions Branch, Lieutenant Colonel
Karl Emil Becker, gathered a small team of engineers that included
Walter Dornberger and Leo Zanssen, to figure out how to use rockets as
long-range artillery in order to get around the Treaty of Versailles'
ban on research and development of long-range cannons. Wernher von
Braun, a young engineering prodigy, was recruited by Becker and
Dornberger to join their secret army program at Kummersdorf-West in
1932. Von Braun dreamed of conquering outer space with rockets and did
not initially see the military value in missile technology.

During the Second World War, General Dornberger was the military head of
the army's rocket program, Zanssen became the commandant of the
Peenemünde army rocket center, and von Braun was the technical director
of the ballistic missile program. They led the team that built the
Aggregat-4 (A-4) rocket, which became the first vehicle to reach outer
space during its test flight program in 1942 and 1943. By 1943, Germany
began mass-producing the A-4 as the Vergeltungswaffe 2 ("Vengeance
Weapon" 2, or more commonly, V2), a ballistic missile with a 320
kilometers (200 mi) range carrying a 1,130 kilograms (2,490 lb) warhead
at 4,000 kilometers per hour (2,500 mph). Its supersonic speed meant
there was no defense against it, and radar detection provided little
warning. Germany used the weapon to bombard southern England and parts
of Allied-liberated western Europe from 1944 until 1945. After the war,
the V-2 became the basis of early American and Soviet rocket designs.

At war's end, American, British, and Soviet scientific intelligence
teams competed to capture Germany's rocket engineers along with the
German rockets themselves and the designs on which they were based. Each
of the Allies captured a share of the available members of the German
rocket team, but the United States benefited the most with Operation
Paperclip, recruiting von Braun and most of his engineering team, who
later helped develop the American missile and space exploration
programs. The United States also acquired a large number of complete V2
rockets.

Soviet rocket development
=========================

-   *He had been involved in space clubs and early Soviet rocket design
    in the 1930s, but was arrested in 1938 during Joseph Stalin's Great
    Purge and imprisoned for six years in Gulag.*

-   *After the war, he became the USSR's chief rocket and spacecraft
    engineer, essentially the Soviet counterpart to von Braun.*

The German rocket center in Peenemünde was located in the eastern part
of Germany, which became the Soviet zone of occupation. On Stalin's
orders, the Soviet Union sent its best rocket engineers to this region
to see what they could salvage for future weapons systems. The Soviet
rocket engineers were led by Sergei Korolev. He had been involved in
space clubs and early Soviet rocket design in the 1930s, but was
arrested in 1938 during Joseph Stalin's Great Purge and imprisoned for
six years in Gulag. After the war, he became the USSR's chief rocket and
spacecraft engineer, essentially the Soviet counterpart to von Braun.
His identity was kept a state secret throughout the Cold War, and he was
identified publicly only as "the Chief Designer." In the West, his name
was only officially revealed when he died in 1966.

After almost a year in the area around Peenemünde, Soviet officials
conducted Operation Osoaviakhim and later moved more than 170 of the top
captured German rocket specialists to Gorodomlya Island on Lake Seliger,
about 240 kilometers (150 mi) northwest of Moscow. They were not allowed
to participate in final Soviet missile design, but were used as
problem-solving consultants to the Soviet engineers. They helped in the
following areas: the creation of a Soviet version of the A-4; work on
"organizational schemes"; research in improving the A-4 main engine;
development of a 100-ton engine; assistance in the "layout" of plant
production rooms; and preparation of rocket assembly using German
components. With their help, particularly Helmut Gröttrup's group,
Korolev reverse-engineered the A-4 and built his own version of the
rocket, the R-1, in 1948. Later, he developed his own distinct designs,
though many of these designs were influenced by the Gröttrup Group's
G4-R10 design from 1949. The Germans were eventually repatriated in
1951–53.

American rocket development
===========================

-   *These tests led to the first rocket to take photos from outer
    space, and the first two-stage rocket, the WAC Corporal-V2
    combination, in 1949.*

-   *From here, von Braun and his team developed the Army's first
    operational medium-range ballistic missile, the Redstone rocket,
    that in slightly modified versions, launched both America's first
    satellite, and the first piloted Mercury space missions.*

The American professor Robert H. Goddard had worked on developing
solid-propellant rockets since 1914, and demonstrated a light
battlefield rocket to the US Army Signal Corps only five days before the
signing of the armistice that ended World War I. He also started
developing liquid-propellant rockets in 1921, yet he had not been taken
seriously by the public.

Von Braun and his team were sent to the United States Army's White Sands
Proving Ground, located in New Mexico, in 1945. They set about
assembling the captured V2s and began a program of launching them and
instructing American engineers in their operation. These tests led to
the first rocket to take photos from outer space, and the first
two-stage rocket, the WAC Corporal-V2 combination, in 1949. The German
rocket team was moved from Fort Bliss to the Army's new Redstone
Arsenal, located in Huntsville, Alabama, in 1950. From here, von Braun
and his team developed the Army's first operational medium-range
ballistic missile, the Redstone rocket, that in slightly modified
versions, launched both America's first satellite, and the first piloted
Mercury space missions. It became the basis for both the Jupiter and
Saturn family of rockets.

Cold War missile race
=====================

-   *It was later used to launch the first satellite into space, and
    derivatives launched all piloted Soviet spacecraft.*

-   *With the Cold War as an engine for change in the ideological
    competition between the United States and the Soviet Union, a
    coherent space policy began to take shape in the United States
    during the late 1950s.*

The Cold War (1947–1991) developed between two former allies, the Soviet
Union and the United States, soon after the end of the Second World War.
It involved a continuing state of political conflict, military tension,
proxy wars, and economic competition, primarily between the Soviet Union
and its satellite states (often referred to as the Eastern Bloc) and the
powers of the Western world, particularly the United States. The primary
participants' military forces never clashed directly, but expressed this
conflict through military coalitions, strategic conventional force
deployments, extensive aid to states deemed vulnerable, proxy wars,
espionage, propaganda, a nuclear arms race, and economic and
technological competitions, such as the Space Race.

In simple terms, the Cold War could be viewed as an expression of the
ideological struggle between communism and capitalism. The United States
faced a new uncertainty beginning in September 1949, when it lost its
monopoly on the atomic bomb. American intelligence agencies discovered
that the Soviet Union had exploded its first atomic bomb, with the
consequence that the United States potentially could face a future
nuclear war that, for the first time, might devastate its cities. Given
this new danger, the United States participated in an arms race with the
Soviet Union that included development of the hydrogen bomb, as well as
intercontinental strategic bombers and intercontinental ballistic
missiles (ICBMs) capable of delivering nuclear weapons. A new fear of
communism and its sympathizers swept the United States during the 1950s,
which devolved into paranoid McCarthyism. With communism spreading in
China, Korea, and Eastern Europe, Americans came to feel so threatened
that popular and political culture condoned extensive "witch-hunts" to
expose communist spies. Part of the American reaction to the Soviet
atomic and hydrogen bomb tests included maintaining a large Air Force,
under the control of the Strategic Air Command (SAC). SAC employed
intercontinental strategic bombers, as well as medium-bombers based
close to Soviet airspace (in western Europe and in Turkey) that were
capable of delivering nuclear payloads.

For its part, the Soviet Union harbored fears of invasion. Having
suffered at least 27 million casualties during World War II after being
invaded by Nazi Germany in 1941, the Soviet Union was wary of its former
ally, the United States, which until late 1949 was the sole possessor of
atomic weapons. The United States had used these weapons operationally
during World War II, and it could use them again against the Soviet
Union, laying waste to its cities and military centers. Since the
Americans had a much larger air force than the Soviet Union, and the
United States maintained advance air bases near Soviet territory, in
1947 Stalin ordered the development of intercontinental ballistic
missiles (ICBMs) in order to counter the perceived American threat.

In 1953, Korolev was given the go-ahead to develop the R-7 Semyorka
rocket, which represented a major advance from the German design.
Although some of its components (notably boosters) still resembled the
German G-4, the new rocket incorporated staged design, a completely new
control system, and a new fuel. It was successfully tested on August 21,
1957, and became the world's first fully operational ICBM the following
month. It was later used to launch the first satellite into space, and
derivatives launched all piloted Soviet spacecraft.

The United States had multiple rocket programs divided among the
different branches of the American armed services, which meant that each
force developed its own ICBM program. The Air Force initiated ICBM
research in 1945 with the MX-774. However, its funding was cancelled and
only three partially successful launches were conducted in 1947. In
1950, von Braun began testing the Air Force PGM-11 Redstone rocket
family at Cape Canaveral. In 1951, the Air Force began a new ICBM
program called MX-1593, and by 1955 this program was receiving
top-priority funding. The MX-1593 program evolved to become the Atlas-A,
with its maiden launch occurring June 11, 1957, becoming the first
successful American ICBM. Its upgraded version, the Atlas-D rocket,
later served as a nuclear ICBM and as the orbital launch vehicle for
Project Mercury and the remote-controlled Agena Target Vehicle used in
Project Gemini.

With the Cold War as an engine for change in the ideological competition
between the United States and the Soviet Union, a coherent space policy
began to take shape in the United States during the late 1950s. Korolev
took inspiration from the competition as well, achieving many firsts to
counter the possibility that the United States might prevail.

The Race begins
===============

First artificial satellite
==========================

-   *In 1955, with both the United States and the Soviet Union building
    ballistic missiles that could be utilized to launch objects into
    space, the "starting line" was drawn for the Space Race.*

-   *The Council of Ministers of the Soviet Union began a policy of
    treating development of its space program as a classified state
    secret.*

In 1955, with both the United States and the Soviet Union building
ballistic missiles that could be utilized to launch objects into space,
the "starting line" was drawn for the Space Race. In separate
announcements four days apart, both nations publicly announced that they
would launch artificial Earth satellites by 1957 or 1958. On July 29,
1955, James C. Hagerty, President Dwight D. Eisenhower's press
secretary, announced that the United States intended to launch "small
Earth circling satellites" between July 1, 1957, and December 31, 1958,
as part of their contribution to the International Geophysical Year
(IGY). Four days later, at the Sixth Congress of International
Astronautical Federation in Copenhagen, scientist Leonid I. Sedov spoke
to international reporters at the Soviet embassy and announced his
country's intention to launch a satellite as well, in the "near future".
On August 30, 1955, Korolev managed to get the Soviet Academy of
Sciences to create a commission whose purpose was to beat the Americans
into Earth orbit: this was the de facto start date for the Space Race.
The Council of Ministers of the Soviet Union began a policy of treating
development of its space program as a classified state secret.

Initially, President Eisenhower was worried that a satellite passing
above a nation at over 100 kilometers (62 mi), might be construed as
violating that nation's sovereign airspace. He was concerned that the
Soviet Union would accuse the Americans of an illegal overflight,
thereby scoring a propaganda victory at his expense. Eisenhower and his
advisors believed that a nation's airspace sovereignty did not extend
into outer space, acknowledged as the Kármán line, and he used the
1957–58 International Geophysical Year launches to establish this
principle in international law. Eisenhower also feared that he might
cause an international incident and be called a "warmonger" if he were
to use military missiles as launchers. Therefore, he selected the
untried Naval Research Laboratory's Vanguard rocket, which was a
research-only booster. This meant that von Braun's team was not allowed
to put a satellite into orbit with their Jupiter-C rocket, because of
its intended use as a future military vehicle. On September 20, 1956,
von Braun and his team did launch a Jupiter-C that was capable of
putting a satellite into orbit, but the launch was used only as a
suborbital test of nose cone reentry technology.

Korolev received word about von Braun's 1956 Jupiter-C test, but
thinking it was a satellite mission that failed, he expedited plans to
get his own satellite in orbit. Since his R-7 was substantially more
powerful than any of the American boosters, he made sure to take full
advantage of this capability by designing Object D as his primary
satellite. It was given the designation 'D', to distinguish it from
other R-7 payload designations 'A', 'B', 'V', and 'G' which were nuclear
weapon payloads. Object D dwarfed the proposed American satellites, by
having a weight of 1,400 kilograms (3,100 lb), of which 300 kilograms
(660 lb) would be composed of scientific instruments that would
photograph the Earth, take readings on radiation levels, and check on
the planet's magnetic field. However, things were not going along well
with the design and manufacturing of the satellite, so in February 1957,
Korolev sought and received permission from the Council of Ministers to
create a Prosteishy Sputnik (PS-1), or simple satellite. The Council
also decreed that Object D be postponed until April 1958. The new
Sputnik was a shiny sphere that would be a much lighter craft, weighing
83.8 kilograms (185 lb) and having a 58-centimeter (23 in) diameter. The
satellite would not contain the complex instrumentation that Object D
had, but had two radio transmitters operating on different short wave
radio frequencies, the ability to detect if a meteoroid were to
penetrate its pressure hull, and the ability to detect the density of
the Earth's thermosphere.

Korolev was buoyed by the first successful launches of his R-7 rocket in
August and September, which paved the way for him to launch his sputnik.
Word came that the Americans were planning to announce a major
breakthrough at an International Geophysical Year conference at the
National Academy of Sciences in Washington D.C., with a paper entitled
"Satellite Over the Planet", on October 6, 1957. Korolev anticipated
that von Braun might launch a Jupiter-C with a satellite payload on or
around October 4 or 5, in conjunction with the paper. He hastened the
launch, moving it to October 4. The launch vehicle for PS-1, was a
modified R-7 – vehicle 8K71PS number M1-PS– without much of the test
equipment and radio gear that was present in the previous launches. It
arrived at the Soviet missile base Tyura-Tam in September and was
prepared for its mission at launch site number one. On Friday, October
4, 1957, at exactly 10:28:34 pm Moscow time, the R-7, with the now named
Sputnik 1 satellite, lifted off the launch pad, and placed this
artificial "moon" into an orbit a few minutes later. This "fellow
traveler," as the name is translated in English, was a small, beeping
ball, less than two feet in diameter and weighing less than 200 pounds.
But the celebrations were muted at the launch control center until the
down-range far east tracking station at Kamchatka received the first
distinctive beep ... beep ... beep sounds from Sputnik 1's radio
transmitters, indicating that it was on its way to completing its first
orbit. About 95 minutes after launch, the satellite flew over its launch
site, and its radio signals were picked up by the engineers and military
personnel at Tyura-Tam: that's when Korolev and his team celebrated the
first successful artificial satellite placed into Earth-orbit.

![](media/image2.jpg){width="4.33400043744532in" height="5.5in"}\
*William Hayward Pickering, James Van Allen, and Wernher von Braun
display a full-scale model of Explorer 1 at a Washington, DC news
conference after confirmation the satellite was in orbit*

US reaction
===========

-   *On April 2, 1958, President Eisenhower reacted to the Soviet space
    lead in launching the first satellite by recommending to the US
    Congress that a civilian agency be established to direct nonmilitary
    space activities.*

-   *On July 1, 1960, the Redstone Arsenal became NASA's George C.
    Marshall Space Flight Center, with von Braun as its first director.*

The Soviet success raised a great deal of concern in the United States.
For example, economist Bernard Baruch wrote in an open letter titled
"The Lessons of Defeat" to the New York Herald Tribune: "While we devote
our industrial and technological power to producing new model
automobiles and more gadgets, the Soviet Union is conquering space. ...
It is Russia, not the United States, who has had the imagination to
hitch its wagon to the stars and the skill to reach for the moon and all
but grasp it. America is worried. It should be."

Eisenhower ordered project Vanguard to move up its timetable and launch
its satellite much sooner than originally planned. The December 6, 1957
Project Vanguard launch failure occurred at Cape Canaveral Air Force
Station in Florida, broadcast live in front of a US television audience.
It was a monumental failure, exploding a few seconds after launch, and
it became an international joke. The satellite appeared in newspapers
under the names Flopnik, Stayputnik, Kaputnik, and Dudnik. In the United
Nations, the Soviet delegate offered the US representative aid "under
the Soviet program of technical assistance to backwards nations." Only
in the wake of this very public failure did von Braun's Redstone team
get the go-ahead to launch their Jupiter-C rocket as soon as they could.
In Britain, the US's Western Cold War ally, the reaction was mixed: some
celebrated the fact that the Soviets had reached space first, while
others feared the destructive potential that military uses of spacecraft
might bring.

On January 31, 1958, nearly four months after the launch of Sputnik 1,
von Braun and the United States successfully launched its first
satellite on a four-stage Juno I rocket derived from the US Army's
Redstone missile, at Cape Canaveral. The satellite Explorer 1 was 30.66
pounds (13.91 kg) in mass. The payload of Explorer 1 weighed 18.35
pounds (8.32 kg). It carried a micrometeorite gauge and a Geiger-Müller
tube. It passed in and out of the Earth-encompassing radiation belt with
its 194-by-1,368-nautical-mile (360 by 2,534 km) orbit, therefore
saturating the tube's capacity and proving what Dr. James Van Allen, a
space scientist at the University of Iowa, had theorized. The belt,
named the Van Allen radiation belt, is a doughnut-shaped zone of
high-level radiation intensity around the Earth above the magnetic
equator. Van Allen was also the man who designed and built the satellite
instrumentation of Explorer 1. The satellite measured three phenomena:
cosmic ray and radiation levels, the temperature in the spacecraft, and
the frequency of collisions with micrometeorites. The satellite had no
memory for data storage, therefore it had to transmit continuously. In
March 1958 a second satellite was sent into orbit with augmented cosmic
ray instruments.

On April 2, 1958, President Eisenhower reacted to the Soviet space lead
in launching the first satellite by recommending to the US Congress that
a civilian agency be established to direct nonmilitary space activities.
Congress, led by Senate Majority Leader Lyndon B. Johnson, responded by
passing the National Aeronautics and Space Act, which Eisenhower signed
into law on July 29, 1958. This law turned the National Advisory
Committee on Aeronautics into the National Aeronautics and Space
Administration (NASA). It also created a Civilian-Military Liaison
Committee, chaired by the President, responsible for coordinating the
nation's civilian and military space programs.

On October 21, 1959, Eisenhower approved the transfer of the Army's
remaining space-related activities to NASA. On July 1, 1960, the
Redstone Arsenal became NASA's George C. Marshall Space Flight Center,
with von Braun as its first director. Development of the Saturn rocket
family, which when mature gave the US parity with the Soviets in terms
of lifting capability, was thus transferred to NASA.

Uncrewed lunar probes
=====================

-   *The fourth attempt, Luna 1, launched successfully on January 2,
    1959, but missed the Moon.*

-   *The Block I Ranger 1 and Ranger 2 suffered Atlas-Agena launch
    failures in August and November 1961.*

-   *The US reacted to the Luna program by embarking on the Ranger
    program in 1959, managed by NASA's Jet Propulsion Laboratory.*

In 1958, Korolev upgraded the R-7 to be able to launch a 400-kilogram
(880 lb) payload to the Moon. Three secret 1958 attempts to launch Luna
E-1-class impactor probes failed. The fourth attempt, Luna 1, launched
successfully on January 2, 1959, but missed the Moon. The fifth attempt
on June 18 also failed at launch. The 390-kilogram (860 lb) Luna 2
successfully impacted the Moon on September 14, 1959. The 278.5-kilogram
(614 lb) Luna 3 successfully flew by the Moon and sent back pictures of
its far side on October 6, 1959.

The US reacted to the Luna program by embarking on the Ranger program in
1959, managed by NASA's Jet Propulsion Laboratory. The Block I Ranger 1
and Ranger 2 suffered Atlas-Agena launch failures in August and November
1961.\
The 727-pound (330 kg) Block II Ranger 3 launched successfully on
January 26, 1962, but missed the Moon. The 730-pound (330 kg) Ranger 4
became the first US spacecraft to reach the Moon, but its solar panels
and navigational system failed near the Moon and it impacted the far
side without returning any scientific data. Ranger 5 ran out of power
and missed the Moon by 725 kilometers (391 nmi) on October 21, 1962. The
first successful Ranger mission was the 806-pound (366 kg) Block III
Ranger 7 which impacted on July 31, 1964.

![](media/image3.jpg){width="3.78125in" height="5.5in"}\
*Yuri Gagarin, the first person in space, 1961*

First human in space
====================

-   *became a historical phrase in the Eastern Bloc, used to refer to
    the beginning of the human space flight era.*

-   *In 2011, it was declared the International Day of Human Space
    Flight by the United Nations.*

-   *By 1959, American observers believed that the Soviet Union would be
    the first to get a human into space, because of the time needed to
    prepare for Mercury's first launch.*

By 1959, American observers believed that the Soviet Union would be the
first to get a human into space, because of the time needed to prepare
for Mercury's first launch. On April 12, 1961, the USSR surprised the
world again by launching Yuri Gagarin into a single orbit around the
Earth in a craft they called Vostok 1. They dubbed Gagarin the first
cosmonaut, roughly translated from Russian and Greek as "sailor of the
universe". Although he had the ability to take over manual control of
his capsule in an emergency by opening an envelope he had in the cabin
that contained a code that could be typed into the computer, it was
flown in an automatic mode as a precaution; medical science at that time
did not know what would happen to a human in the weightlessness of
space. Vostok 1 orbited the Earth for 108 minutes and made its reentry
over the Soviet Union, with Gagarin ejecting from the spacecraft at
7,000 meters (23,000 ft), and landing by parachute. The Fédération
Aéronautique Internationale (International Federation of Aeronautics)
credited Gagarin with the world's first human space flight, although
their qualifying rules for aeronautical records at the time required
pilots to take off and land with their craft. For this reason, the
Soviet Union omitted from their FAI submission the fact that Gagarin did
not land with his capsule. When the FAI filing for Gherman Titov's
second Vostok flight in August 1961 disclosed the ejection landing
technique, the FAI committee decided to investigate, and concluded that
the technological accomplishment of human spaceflight lay in the safe
launch, orbiting, and return, rather than the manner of landing, and
revised their rules, keeping Gagarin's and Titov's records intact.

Gagarin became a national hero of the Soviet Union and the Eastern Bloc,
and a worldwide celebrity. Moscow and other cities in the USSR held mass
demonstrations, the scale of which was second only to the World War II
Victory Parade of 1945. April 12 was declared Cosmonautics Day in the
USSR, and is celebrated today in Russia as one of the official
"Commemorative Dates of Russia." In 2011, it was declared the
International Day of Human Space Flight by the United Nations.

The radio communication between the launch control room and Gagarin
included the following dialogue at the moment of rocket launch:

Gagarin's informal poyekhali! became a historical phrase in the Eastern
Bloc, used to refer to the beginning of the human space flight era.

![](media/image4.jpg){width="5.5in" height="4.125in"}\
*Alan Shepard, the first American in space, 1961*

First American in space
=======================

-   *On May 5, 1961, Alan Shepard became the first American in space,
    launched in a ballistic trajectory on Mercury-Redstone 3, in a
    spacecraft he named Freedom 7.*

-   *The US Air Force had been developing a program to launch the first
    man in space, named Man in Space Soonest.*

The US Air Force had been developing a program to launch the first man
in space, named Man in Space Soonest. This program studied several
different types of one-man space vehicles, settling on a ballistic
re-entry capsule launched on a derivative Atlas missile, and selecting a
group of nine candidate pilots. After NASA's creation, the program was
transferred over to the civilian agency and renamed Project Mercury on
November 26, 1958. NASA selected a new group of astronaut (from the
Greek for "star sailor") candidates from Navy, Air Force and Marine test
pilots, and narrowed this down to a group of seven for the program.
Capsule design and astronaut training began immediately, working toward
preliminary suborbital flights on the Redstone missile, followed by
orbital flights on the Atlas. Each flight series would first start
uncrewed, then carry a non-human primate, then finally humans.

On May 5, 1961, Alan Shepard became the first American in space,
launched in a ballistic trajectory on Mercury-Redstone 3, in a
spacecraft he named Freedom 7. Though he did not achieve orbit like
Gagarin, he was the first person to exercise manual control over his
spacecraft's attitude and retro-rocket firing. After his successful
return, Shepard was celebrated as a national hero, honored with parades
in Washington, New York and Los Angeles, and received the NASA
Distinguished Service Medal from President John F. Kennedy.

Kennedy directs the Race toward the Moon
========================================

-   *Some were surprised by Kennedy's eventual support of NASA and the
    space program because of how often he had attacked the Eisenhower
    administration's inefficiency during the election.*

-   *Jerome Wiesner of MIT, who served as a science advisor to
    presidents Eisenhower and Kennedy, and himself an opponent of crewed
    space exploration, remarked, "If Kennedy could have opted out of a
    big space program without hurting the country in his judgment, he
    would have."*

Before Gagarin's flight, US President John F. Kennedy's support for
America's crewed space program was lukewarm. Jerome Wiesner of MIT, who
served as a science advisor to presidents Eisenhower and Kennedy, and
himself an opponent of crewed space exploration, remarked, "If Kennedy
could have opted out of a big space program without hurting the country
in his judgment, he would have." As late as March 1961, when NASA
administrator James E. Webb submitted a budget request to fund a Moon
landing before 1970, Kennedy rejected it because it was simply too
expensive. Some were surprised by Kennedy's eventual support of NASA and
the space program because of how often he had attacked the Eisenhower
administration's inefficiency during the election.

Gagarin's flight changed this; now Kennedy sensed the humiliation and
fear on the part of the American public over the Soviet lead.
Additionally, the Bay of Pigs invasion, planned before his term began
but executed during it, was an embarrassment to his administration due
to the colossal failure of the American forces. Looking for something to
save political face, he sent a memo dated April 20, 1961, to Vice
President Lyndon B. Johnson, asking him to look into the state of
America's space program, and into programs that could offer NASA the
opportunity to catch up. The two major options at the time seemed to be,
either establishment of an Earth orbital space station, or a crewed
landing on the Moon. Johnson, in turn, consulted with von Braun, who
answered Kennedy's questions based on his estimates of US and Soviet
rocket lifting capability. Based on this, Johnson responded to Kennedy,
concluding that much more was needed to reach a position of leadership,
and recommending that the crewed Moon landing was far enough in the
future that the US had a fighting chance to achieve it first.

Kennedy ultimately decided to pursue what became the Apollo program, and
on May 25 took the opportunity to ask for Congressional support in a
Cold War speech titled "Special Message on Urgent National Needs". Full
text \
He justified the program in terms of its importance to national
security, and its focus of the nation's energies on other scientific and
social fields. He rallied popular support for the program in his "We
choose to go to the Moon" speech, on September 12, 1962, before a large
crowd at Rice University Stadium, in Houston, Texas, near the
construction site of the new Manned Spacecraft Center facility. Full
text \
Khrushchev responded to Kennedy's implicit challenge with silence,
refusing to publicly confirm or deny the Soviets were pursuing a "Moon
race". As later disclosed, the Soviet Union secretly pursued a crewed
lunar program until 1974.

Completion of Vostok and Mercury programs
=========================================

![](media/image5.jpg){width="5.5in" height="4.06003937007874in"}\
*John Glenn, the first American in orbit, 1962*

Mercury
=======

-   *Almost a year after the Soviet Union put a human into orbit,
    astronaut John Glenn became the first American to orbit the Earth,
    on February 20, 1962.*

-   *NASA at first intended to launch one more mission, extending the
    spacecraft's endurance to three days, but since this would not beat
    the Soviet record, it was decided instead to concentrate on
    developing Project Gemini.*

American Virgil "Gus" Grissom repeated Shepard's suborbital flight in
Liberty Bell 7 on July 21, 1961. Almost a year after the Soviet Union
put a human into orbit, astronaut John Glenn became the first American
to orbit the Earth, on February 20, 1962. His Mercury-Atlas 6 mission
completed three orbits in the Friendship 7 spacecraft, and splashed down
safely in the Atlantic Ocean, after a tense reentry, due to what falsely
appeared from the telemetry data to be a loose heat-shield. As the first
American in orbit, Glenn became a national hero, and received a
ticker-tape parade in New York City, reminiscent of that given for
Charles Lindbergh. On February 23, 1962, President Kennedy escorted him
in a parade at Cape Canaveral Air Force Station, where he awarded Glenn
with the NASA service medal.

The United States launched three more Mercury flights after Glenn's:
Aurora 7 on May 24, 1962, duplicated Glenn's three orbits; Sigma 7 on
October 3, 1962, six orbits; and Faith 7 on May 15, 1963, 22 orbits
(32.4 hours), the maximum capability of the spacecraft. NASA at first
intended to launch one more mission, extending the spacecraft's
endurance to three days, but since this would not beat the Soviet
record, it was decided instead to concentrate on developing Project
Gemini.

![](media/image6.jpg){width="4.121333114610674in" height="5.5in"}\
*Replica of the Vostok capsule*

Vostok
======

-   *There were no maneuvering rockets on the Vostok to permit space
    rendezvous, required to keep two spacecraft a controlled distance
    apart.*

-   *Vostok 4 also set a record of nearly four days in space.*

-   *This time they launched the first woman (also the first civilian),
    Valentina Tereshkova, into space on Vostok 6.*

Gherman Titov became the first Soviet cosmonaut to exercise manual
control of his Vostok 2 craft on August 6, 1961. The Soviet Union
demonstrated 24-hour launch pad turnaround and the capability to launch
two piloted spacecraft, Vostok 3 and Vostok 4, in essentially identical
orbits, on August 11 and 12, 1962. The two spacecraft came within
approximately 6.5 kilometers (4.0 mi) of one another, close enough for
radio communication. Vostok 4 also set a record of nearly four days in
space. Though the two craft's orbits were as nearly identical as
possible given the accuracy of the launch rocket's guidance system,
slight variations still existed which drew the two craft at first as
close to each other as 6.5 kilometers (3.5 nautical miles), then as far
apart as 2,850 kilometers (1,540 nautical miles). There were no
maneuvering rockets on the Vostok to permit space rendezvous, required
to keep two spacecraft a controlled distance apart.

The Soviet Union duplicated its dual-launch feat with Vostok 5 and
Vostok 6 (June 16, 1963). This time they launched the first woman (also
the first civilian), Valentina Tereshkova, into space on Vostok 6.
Launching a woman was reportedly Korolev's idea, and it was accomplished
purely for propaganda value. Tereshkova was one of a small corps of
female cosmonauts who were amateur parachutists, but Tereshkova was the
only one to fly. The USSR didn't again open its cosmonaut corps to women
until 1980, two years after the United States opened its astronaut corps
to women.

The Soviets kept the details and true appearance of the Vostok capsule
secret until the April 1965 Moscow Economic Exhibition, where it was
first displayed without its aerodynamic nose cone concealing the
spherical capsule. The "Vostok spaceship" had been first displayed at
the July 1961 Tushino air show, mounted on its launch vehicle's third
stage, with the nose cone in place. A tail section with eight fins was
also added, in an apparent attempt to confuse western observers. This
spurious tail section also appeared on official commemorative stamps and
a documentary.

Kennedy proposes a joint US-USSR program
========================================

-   *On September 20, 1963, in a speech before the United Nations
    General Assembly, President Kennedy proposed that the United States
    and the Soviet Union join forces in an effort to reach the Moon.*

-   *Kennedy thus changed his mind regarding the desirability of the
    space race, preferring instead to ease tensions with the Soviet
    Union by cooperating on projects such as a joint lunar landing.*

On September 20, 1963, in a speech before the United Nations General
Assembly, President Kennedy proposed that the United States and the
Soviet Union join forces in an effort to reach the Moon. Kennedy thus
changed his mind regarding the desirability of the space race,
preferring instead to ease tensions with the Soviet Union by cooperating
on projects such as a joint lunar landing. Soviet Premier Nikita
Khrushchev initially rejected Kennedy's proposal. However, on October 2,
1997, it was reported that Khrushchev's son Sergei claimed Khrushchev
was poised to accept Kennedy's proposal at the time of Kennedy's
assassination on November 22, 1963. During the next few weeks he
reportedly concluded that both nations might realize cost benefits and
technological gains from a joint venture, and decided to accept
Kennedy's offer based on a measure of rapport during their years as
leaders of the world's two superpowers, but changed his mind and dropped
the idea since he did not have the same trust for Kennedy's successor,
Lyndon Johnson.

As President, Johnson steadfastly pursued the Gemini and Apollo
programs, promoting them as Kennedy's legacy to the American public. One
week after Kennedy's death, he issued an executive order renaming the
Cape Canaveral and Apollo launch facilities after Kennedy.

Gemini and Voskhod
==================

-   *Focused by the commitment to a Moon landing, in January 1962 the US
    announced Project Gemini, a two-man spacecraft that would support
    the later three-man Apollo by developing the key spaceflight
    technologies of space rendezvous and docking of two craft, flight
    durations of sufficient length to simulate going to the Moon and
    back, and extra-vehicular activity to accomplish useful work outside
    the spacecraft.*

Focused by the commitment to a Moon landing, in January 1962 the US
announced Project Gemini, a two-man spacecraft that would support the
later three-man Apollo by developing the key spaceflight technologies of
space rendezvous and docking of two craft, flight durations of
sufficient length to simulate going to the Moon and back, and
extra-vehicular activity to accomplish useful work outside the
spacecraft.

Meanwhile, Korolev had planned further, long-term missions for the
Vostok spacecraft, and had four Vostoks in various stages of fabrication
in late 1963 at his OKB-1 facilities. At that time, the Americans
announced their ambitious plans for the Project Gemini flight schedule.
These plans included major advancements in spacecraft capabilities,
including a two-person spacecraft, the ability to change orbits, the
capacity to perform an extravehicular activity (EVA), and the goal of
docking with another spacecraft. These represented major advances over
the previous Mercury or Vostok capsules, and Korolev felt the need to
try to beat the Americans to many of these innovations. Korolev already
had begun designing the Vostok's replacement, the next-generation Soyuz
spacecraft, a multi-cosmonaut spacecraft that had at least the same
capabilities as the Gemini spacecraft. Soyuz would not be available for
at least three years, and it could not be called upon to deal with this
new American challenge in 1964 or 1965. Political pressure in early
1964–which some sources claim was from Khrushchev while other sources
claim was from other Communist Party officials—pushed him to modify his
four remaining Vostoks to beat the Americans to new space firsts in the
size of flight crews, and the duration of missions.

Voskhod program
===============

-   *The greater advances of the Soviet space program at the time
    allowed their space program to achieve other significant firsts,
    including the first EVA "spacewalk" and the first mission performed
    by a crew in shirt-sleeves.*

-   *There was a two-year pause in Soviet piloted space flights while
    Voskhod's replacement, the Soyuz spacecraft, was designed and
    developed.*

The greater advances of the Soviet space program at the time allowed
their space program to achieve other significant firsts, including the
first EVA "spacewalk" and the first mission performed by a crew in
shirt-sleeves. Gemini took a year longer than planned to accomplish its
first flight, allowing the Soviets to achieve another first, launching
Voskhod 1 on October 12, 1964, the first spacecraft with a
three-cosmonaut crew. The USSR touted another technological achievement
during this mission: it was the first space flight during which
cosmonauts performed in a shirt-sleeve-environment. However, flying
without spacesuits was not due to safety improvements in the Soviet
spacecraft's environmental systems; rather this innovation was
accomplished because the craft's limited cabin space did not allow for
spacesuits. Flying without spacesuits exposed the cosmonauts to
significant risk in the event of potentially fatal cabin
depressurization. This feat was not repeated until the US Apollo Command
Module flew in 1968; this later mission was designed from the outset to
safely transport three astronauts in a shirt-sleeve environment while in
space.

Between October 14–16, 1964, Leonid Brezhnev and a small cadre of
high-ranking Communist Party officials deposed Khrushchev as Soviet
government leader a day after Voskhod 1 landed, in what was called the
"Wednesday conspiracy".\
The new political leaders, along with Korolev, ended the technologically
troublesome Voskhod program, cancelling Voskhod 3 and 4, which were in
the planning stages, and started concentrating on the race to the Moon.
Voskhod 2 ended up being Korolev's final achievement before his death on
January 14, 1966, as it became the last of the many space firsts that
demonstrated the USSR's domination in spacecraft technology during the
early 1960s. According to historian Asif Siddiqi, Korolev's
accomplishments marked "the absolute zenith of the Soviet space program,
one never, ever attained since." There was a two-year pause in Soviet
piloted space flights while Voskhod's replacement, the Soyuz spacecraft,
was designed and developed.

On March 18, 1965, about a week before the first American piloted
Project Gemini space flight, the USSR accelerated the competition, by
launching the two-cosmonaut Voskhod 2 mission with Pavel Belyayev and
Alexei Leonov. Voskhod 2's design modifications included the addition of
an inflatable airlock to allow for extravehicular activity (EVA), also
known as a spacewalk, while keeping the cabin pressurized so that the
capsule's electronics would not overheat. Leonov performed the
first-ever EVA as part of the mission. A fatality was narrowly avoided
when Leonov's spacesuit expanded in the vacuum of space, preventing him
from re-entering the airlock. In order to overcome this, he had to
partially depressurize his spacesuit to a potentially dangerous level.
He succeeded in safely re-entering the ship, but he and Belyayev faced
further challenges when the spacecraft's atmospheric controls flooded
the cabin with 45% pure oxygen, which had to be lowered to acceptable
levels before re-entry. The reentry involved two more challenges: an
improperly timed retrorocket firing caused the Voskhod 2 to land 386
kilometers (240 mi) off its designated target area, the town of Perm;
and the instrument compartment's failure to detach from the descent
apparatus caused the spacecraft to become unstable during reentry.

![](media/image7.jpg){width="5.5in" height="5.463576115485564in"}\
*Rendezvous of Gemini 6 and 7, December 1965*

Project Gemini
==============

-   *On Gemini 6A (December 1965), Command Pilot Wally Schirra achieved
    the first space rendezvous with Gemini 7, accurately matching his
    orbit to that of the other craft, station-keeping for three
    consecutive orbits at distances as close as 1 foot (0.30 m).*

-   *On Gemini 5 (August 1965), astronauts L. Gordon Cooper and Charles
    "Pete" Conrad set a record of almost eight days in space, long
    enough for a piloted lunar mission.*

Though delayed a year to reach its first flight, Gemini was able to take
advantage of the USSR's two-year hiatus after Voskhod, which enabled the
US to catch up and surpass the previous Soviet lead in piloted
spaceflight. Gemini achieved several significant firsts during the
course of ten piloted missions:

On Gemini 3 (March 1965), astronauts Virgil "Gus" Grissom and John W.
Young became the first to demonstrate their ability to change their
craft's orbit.

On Gemini 5 (August 1965), astronauts L. Gordon Cooper and Charles
"Pete" Conrad set a record of almost eight days in space, long enough
for a piloted lunar mission.

On Gemini 6A (December 1965), Command Pilot Wally Schirra achieved the
first space rendezvous with Gemini 7, accurately matching his orbit to
that of the other craft, station-keeping for three consecutive orbits at
distances as close as 1 foot (0.30 m).

Gemini 7 also set a human spaceflight endurance record of fourteen days
for Frank Borman and James A. Lovell, which stood until both nations
started launching space laboratories in the early 1970s.

On Gemini 8 (March 1966), Command Pilot Neil Armstrong achieved the
first docking between two spacecraft, his Gemini craft and an Agena
target vehicle.

Gemini 11 (September 1966), commanded by Conrad, achieved the first
direct-ascent rendezvous with its Agena target on the first orbit, and
used the Agena's rocket to achieve an apogee of 742 nautical miles
(1,374 km), the crewed Earth orbit record still current as of 2015.

On Gemini 12 (November 1966), Edwin E. "Buzz" Aldrin spent over five
hours working comfortably during three (EVA) sessions, finally proving
that humans could perform productive tasks outside their spacecraft.
This proved to be the most difficult goal to achieve.

Most of the novice pilots on the early missions would command the later
missions. In this way, Project Gemini built up spaceflight experience
for the pool of astronauts for the Apollo lunar missions.

Soviet crewed Moon programs
===========================

-   *Korolev's lunar landing program was designated N1/L3, for its N1
    super rocket and a more advanced Soyuz 7K-L3 spacecraft, also known
    as the lunar orbital module ("Lunniy Orbitalny Korabl", LOK), with a
    crew of two.*

-   *The combined space vehicle was roughly the same height and takeoff
    mass as the three-stage US Apollo/ Saturn V and exceeded its takeoff
    thrust by 28%, but had only roughly half the translunar injection
    payload capability.*

Korolev's design bureau produced two prospectuses for circumlunar
spaceflight (March 1962 and May 1963), the main spacecraft for which
were early versions of his Soyuz design. Soviet Communist Party Central
Committee Command 655-268 officially established two secret, competing
crewed programs for circumlunar flights and lunar landings, on August 3,
1964. The circumlunar flights were planned to occur in 1967, and the
landings to start in 1968.

The circumlunar program (Zond), created by Vladimir Chelomey's design
bureau OKB-52, was to fly two cosmonauts in a stripped-down Soyuz 7K-L1,
launched by Chelomey's Proton UR-500 rocket. The Zond sacrificed
habitable cabin volume for equipment, by omitting the Soyuz orbital
module. Chelomey gained favor with Khruschev by employing members of his
family.

Korolev's lunar landing program was designated N1/L3, for its N1 super
rocket and a more advanced Soyuz 7K-L3 spacecraft, also known as the
lunar orbital module ("Lunniy Orbitalny Korabl", LOK), with a crew of
two. A separate lunar lander ("Lunniy Korabl", LK), would carry a single
cosmonaut to the lunar surface.

The N1/L3 launch vehicle had three stages to Earth orbit, a fourth stage
for Earth departure, and a fifth stage for lunar landing assist. The
combined space vehicle was roughly the same height and takeoff mass as
the three-stage US Apollo/ Saturn V and exceeded its takeoff thrust by
28%, but had only roughly half the translunar injection payload
capability.

Following Khruschev's ouster from power, Chelomey's Zond program was
merged into the N1/L3 program.

Outer space treaty
==================

-   *Following the passing of this resolution, Kennedy commenced his
    communications proposing a cooperative American/Soviet space
    program.*

-   *The US and USSR began discussions on the peaceful uses of space as
    early as 1958, presenting issues for debate to the United Nations,
    which created a Committee on the Peaceful Uses of Outer Space
    in 1959.*

-   *holds any State liable for damages caused by their space object;*

The US and USSR began discussions on the peaceful uses of space as early
as 1958, presenting issues for debate to the United Nations, which
created a Committee on the Peaceful Uses of Outer Space in 1959.

On May 10, 1962, Vice President Johnson addressed the Second National
Conference on the Peaceful Uses of Space revealing that the United
States and the USSR both supported a resolution passed by the Political
Committee of the UN General Assembly on December 1962, which not only
urged member nations to "extend the rules of international law to outer
space," but to also cooperate in its exploration. Following the passing
of this resolution, Kennedy commenced his communications proposing a
cooperative American/Soviet space program.

The UN ultimately created a Treaty on Principles Governing the
Activities of States in the Exploration and Use of Outer Space,
including the Moon and Other Celestial Bodies, which was signed by the
United States, USSR, and the United Kingdom on January 27, 1967, and
went into force the following October 10.

This treaty:

bars party States from placing weapons of mass destruction in Earth
orbit, on the Moon, or any other celestial body;

exclusively limits the use of the Moon and other celestial bodies to
peaceful purposes, and expressly prohibits their use for testing weapons
of any kind, conducting military maneuvers, or establishing military
bases, installations, and fortifications;

declares that the exploration of outer space shall be done to benefit
all countries and shall be free for exploration and use by all the
States;

explicitly forbids any government from claiming a celestial resource
such as the Moon or a planet, claiming that they are the common heritage
of mankind, "not subject to national appropriation by claim of
sovereignty, by means of use or occupation, or by any other means".
However, the State that launches a space object retains jurisdiction and
control over that object;

holds any State liable for damages caused by their space object;

declares that "the activities of non-governmental entities in outer
space, including the Moon and other celestial bodies, shall require
authorization and continuing supervision by the appropriate State Party
to the Treaty", and "States Parties shall bear international
responsibility for national space activities whether carried out by
governmental or non-governmental entities"; and

"A State Party to the Treaty which has reason to believe that an
activity or experiment planned by another State Party in outer space,
including the Moon and other celestial bodies, would cause potentially
harmful interference with activities in the peaceful exploration and use
of outer space, including the Moon and other celestial bodies, may
request consultation concerning the activity or experiment."

The treaty remains in force, signed by 107 member states. – As of July
2017\[update\]

![](media/image8.jpg){width="5.5in" height="3.712871828521435in"}\
*Charred interior of the Apollo 1 spacecraft after the fire that killed
the first crew*

![](media/image9.jpg){width="5.5in" height="5.5in"}\
*Commemorative plaque and the Fallen Astronaut sculpture left on the
Moon in 1971 by the crew of Apollo 15 in memory of 14 deceased NASA
astronauts and USSR cosmonauts*

Disaster strikes both sides
===========================

-   *On January 27, 1967, the same day the US and USSR signed the Outer
    Space Treaty, the crew of the first crewed Apollo mission, Command
    Pilot Virgil "Gus" Grissom, Senior Pilot Ed White, and Pilot Roger
    Chaffee, were killed in a fire that swept through their spacecraft
    cabin during a ground test, less than a month before the planned
    February 21 launch.*

-   *The mission was planned to be a three-day test, to include the
    first Soviet docking with an unpiloted Soyuz 2, but the mission was
    plagued with problems.*

In 1967, both nations faced serious challenges that brought their
programs to temporary halts. Both had been rushing at full-speed toward
the first piloted flights of Apollo and Soyuz, without paying due
diligence to growing design and manufacturing problems. The results
proved fatal to both pioneering crews.

On January 27, 1967, the same day the US and USSR signed the Outer Space
Treaty, the crew of the first crewed Apollo mission, Command Pilot
Virgil "Gus" Grissom, Senior Pilot Ed White, and Pilot Roger Chaffee,
were killed in a fire that swept through their spacecraft cabin during a
ground test, less than a month before the planned February 21 launch. An
investigative board determined the fire was probably caused by an
electrical spark, and quickly grew out of control, fed by the
spacecraft's pure oxygen atmosphere. Crew escape was made impossible by
inability to open the plug door hatch cover against the
greater-than-atmospheric internal pressure. The board also found design
and construction flaws in the spacecraft, and procedural failings,
including failure to appreciate the hazard of the pure-oxygen
atmosphere, as well as inadequate safety procedures. All these flaws had
to be corrected over the next twenty-two months until the first piloted
flight could be made.\
Mercury and Gemini veteran Grissom had been a favored choice of Deke
Slayton, NASA's Director of Flight Crew Operations, to make the first
piloted landing.

On April 24, 1967, the single pilot of Soyuz 1, Vladimir Komarov, became
the first in-flight spaceflight fatality. The mission was planned to be
a three-day test, to include the first Soviet docking with an unpiloted
Soyuz 2, but the mission was plagued with problems. Early on, Komarov's
craft lacked sufficient electrical power because only one of two solar
panels had deployed. Then the automatic attitude control system began
malfunctioning and eventually failed completely, resulting in the craft
spinning wildly. Komarov was able to stop the spin with the manual
system, which was only partially effective. The flight controllers
aborted his mission after only one day. During the emergency re-entry, a
fault in the landing parachute system caused the primary chute to fail,
and the reserve chute became tangled with the drogue chute, causing
descent speed to reach as high as 40 m/s (140 km/h; 89 mph). Shortly
thereafter, Soyuz 1 impacted the ground 3 km (1.9 mi) west of Karabutak,
exploding into a ball of flames. The official autopsy states Komarov
died of blunt force trauma on impact, and that the subsequent heat
mutilation of his corpse was a result of the explosive impact. Fixing
the spacecraft's faults caused an eighteen-month delay before piloted
Soyuz flights could resume.

![](media/image10.jpg){width="5.485333552055993in" height="5.5in"}\
*Earthrise, as seen from Apollo 8, December 24, 1968 (photograph by
astronaut William Anders)*

![](media/image11.jpg){width="5.5in" height="5.5in"}\
*Lunar Module in lunar orbit on Apollo 10, May 22–23, 1969*

Onward to the Moon
==================

-   *Unknown to the Americans, the Soviet Moon program was in deep
    trouble.*

-   *On December 21, 1968, Frank Borman, James Lovell, and William
    Anders became the first humans to ride the Saturn V rocket into
    space, on Apollo 8.*

-   *It was the first-ever docking of two crewed spacecraft, and the
    first transfer of crew from one space vehicle to another.*

The United States recovered from the Apollo 1 fire, fixing the fatal
flaws in an improved version of the Block II command module. The US
proceeded with unpiloted test launches of the Saturn V launch vehicle
(Apollo 4 and Apollo 6) and the Lunar Module (Apollo 5) during the
latter half of 1967 and early 1968. Apollo 1's mission to check out the
Apollo Command/Service Module in Earth orbit was accomplished by
Grissom's backup crew commanded by Walter Schirra on Apollo 7, launched
on October 11, 1968. The eleven-day mission was a total success, as the
spacecraft performed a virtually flawless mission, paving the way for
the United States to continue with its lunar mission schedule.

The Soviet Union also fixed the parachute and control problems with
Soyuz, and the next piloted mission Soyuz 3 was launched on October 26,
1968. The goal was to complete Komarov's rendezvous and docking mission
with the un-piloted Soyuz 2. Ground controllers brought the two craft to
within 200 meters (660 ft) of each other, then cosmonaut Georgy
Beregovoy took control. He got within 40 meters (130 ft) of his target,
but was unable to dock before expending 90 percent of his maneuvering
fuel, due to a piloting error that put his spacecraft into the wrong
orientation and forced Soyuz 2 to automatically turn away from his
approaching craft. The first docking of Soviet spacecraft was finally
realized in January 1969 by the Soyuz 4 and Soyuz 5 missions. It was the
first-ever docking of two crewed spacecraft, and the first transfer of
crew from one space vehicle to another.

The Soviet Zond spacecraft was not yet ready for piloted circumlunar
missions in 1968, after five\[verification needed\] unsuccessful and
partially successful automated test launches: Cosmos 146 on March 10,
1967; Cosmos 154 on April 8, 1967; Zond 1967A September 27, 1967; Zond
1967B on November 22, 1967. Zond 4 was launched on March 2, 1968, and
successfully made a circumlunar flight. After its successful flight
around the Moon, Zond 4 encountered problems with its Earth reentry on
March 9, and was ordered destroyed by an explosive charge 15,000 meters
(49,000 ft) over the Gulf of Guinea. The Soviet official announcement
said that Zond 4 was an automated test flight which ended with its
intentional destruction, due to its recovery trajectory positioning it
over the Atlantic Ocean instead of over the USSR.

During the summer of 1968, the Apollo program hit another snag: the
first pilot-rated Lunar Module (LM) was not ready for orbital tests in
time for a December 1968 launch. NASA planners overcame this challenge
by changing the mission flight order, delaying the first LM flight until
March 1969, and sending Apollo 8 into lunar orbit without the LM in
December. This mission was in part motivated by intelligence rumors the
Soviet Union might be ready for a piloted Zond flight during late 1968.
In September 1968, Zond 5 made a circumlunar flight with tortoises on
board and returned safely to Earth, accomplishing the first successful
water landing of the Soviet space program in the Indian Ocean. It also
scared NASA planners, as it took them several days to figure out that it
was only an automated flight, not piloted, because voice recordings were
transmitted from the craft en route to the Moon. On November 10, 1968,
another automated test flight, Zond 6, was launched. It encountered
difficulties in Earth reentry, and depressurized and deployed its
parachute too early, causing it to crash-land only 16 kilometers
(9.9 mi) from where it had been launched six days earlier. It turned out
there was no chance of a piloted Soviet circumlunar flight during 1968,
due to the unreliability of the Zonds.

On December 21, 1968, Frank Borman, James Lovell, and William Anders
became the first humans to ride the Saturn V rocket into space, on
Apollo 8. They also became the first to leave low-Earth orbit and go to
another celestial body, entering lunar orbit on December 24. They made
ten orbits in twenty hours, and transmitted one of the most watched TV
broadcasts in history, with their Christmas Eve program from lunar
orbit, which concluded with a reading from the biblical Book of Genesis.
Two and a half hours after the broadcast, they fired their engine to
perform the first trans-Earth injection to leave lunar orbit and return
to the Earth. Apollo 8 safely landed in the Pacific Ocean on December
27, in NASA's first dawn splashdown and recovery.

The American Lunar Module was finally ready for a successful piloted
test flight in low Earth orbit on Apollo 9 in March 1969. The next
mission, Apollo 10, conducted a "dress rehearsal" for the first landing
in May 1969, flying the LM in lunar orbit as close as 47,400 feet
(14.4 km) above the surface, the point where the powered descent to the
surface would begin. With the LM proven to work well, the next step was
to attempt the landing.

Unknown to the Americans, the Soviet Moon program was in deep trouble.
After two successive launch failures of the N1 rocket in 1969, Soviet
plans for a piloted landing suffered delay. The launch pad explosion of
the N-1 on July 3, 1969, was a significant setback. The rocket hit the
pad after an engine shutdown, destroying itself and the launch facility.
Without the N-1 rocket, the USSR could not send a large enough payload
to the Moon to land a human and return him safely.

![](media/image12.jpg){width="5.4486668853893265in" height="5.5in"}\
*American Buzz Aldrin during the first Moon walk in 1969*

Apollo 11
=========

-   *On July 16, 1969, at exactly 9:32 am EDT, the Saturn V rocket,
    AS-506, lifted off from Kennedy Space Center Launch Complex 39 in
    Florida.*

-   *The first humans on the Moon waited six hours before they left
    their craft.*

-   *With the safe completion of the Apollo 11 mission, the Americans
    won the race to the Moon.*

Apollo 11 was prepared with the goal of a July landing in the Sea of
Tranquility. The crew, selected in January 1969, consisted of commander
(CDR) Neil Armstrong, Command Module Pilot (CMP) Michael Collins, and
Lunar Module Pilot (LMP) Edwin "Buzz" Aldrin. They trained for the
mission until just before the launch day. On July 16, 1969, at exactly
9:32 am EDT, the Saturn V rocket, AS-506, lifted off from Kennedy Space
Center Launch Complex 39 in Florida.

The trip to the Moon took just over three days. After achieving orbit,
Armstrong and Aldrin transferred into the Lunar Module, named Eagle, and
after a landing gear inspection by Collins remaining in the
Command/Service Module Columbia, began their descent. After overcoming
several computer overload alarms caused by an antenna switch left in the
wrong position, and a slight downrange error, Armstrong took over manual
flight control at about 180 meters (590 ft), and guided the Lunar Module
to a safe landing spot at 20:18:04 UTC, July 20, 1969 (3:17:04 pm CDT).
The first humans on the Moon waited six hours before they left their
craft. At 02:56 UTC, July 21 (9:56 pm CDT July 20), Armstrong became the
first human to set foot on the Moon.

The first step was witnessed by at least one-fifth of the population of
Earth, or about 723 million people. His first words when he stepped off
the LM's landing footpad were, "That's one small step for \[a\] man, one
giant leap for mankind." Aldrin joined him on the surface almost 20
minutes later. Altogether, they spent just under two and one-quarter
hours outside their craft. The next day, they performed the first launch
from another celestial body, and rendezvoused back with Columbia.

Apollo 11 left lunar orbit and returned to Earth, landing safely in the
Pacific Ocean on July 24, 1969. When the spacecraft splashed down, 2,982
days had passed since Kennedy's commitment to landing a man on the Moon
and returning him safely to the Earth before the end of the decade; the
mission was completed with 161 days to spare. With the safe completion
of the Apollo 11 mission, the Americans won the race to the Moon.

![](media/image13.jpg){width="5.5in" height="4.3836340769903765in"}\
*Apollo 17's Saturn V in 1972*

![](media/image14.jpg){width="5.324000437445319in" height="5.5in"}\
*Moonwalk, December 13, 1972*

The Race winds down
===================

-   *Agnew was an enthusiastic proponent of NASA's follow-on plans, and
    the STG recommended plans to develop a reusable Space Transportation
    System including a Space Shuttle, which would facilitate development
    of permanent space stations in Earth and lunar orbit, perhaps a base
    on the lunar surface, and the first human flight to Mars as early as
    1986 or as late as 2000.*

NASA had ambitious follow-on human spaceflight plans as it reached its
lunar goal, but soon discovered it had expended most of its political
capital to do so.

The first landing was followed by another, precision landing on Apollo
12 in November 1969. NASA had achieved its first landing goal with
enough Apollo spacecraft and Saturn V launchers left for eight follow-on
lunar landings through Apollo 20, conducting extended-endurance missions
and transporting the landing crews in Lunar Roving Vehicles on the last
five. They also planned an Apollo Applications Program to develop a
longer-duration Earth orbital workshop (later named Skylab) to be
constructed in orbit from a spent S-IVB upper stage, using several
launches of the smaller Saturn IB launch vehicle. But planners soon
decided this could be done more efficiently by using the two live stages
of a Saturn V to launch the workshop pre-fabricated from an S-IVB (which
was also the Saturn V third stage), which immediately removed Apollo 20.
Belt-tightening budget cuts soon led NASA to cut Apollo 18 and 19 as
well, but keep three extended/Lunar Rover missions. Apollo 13
encountered an in-flight spacecraft failure and had to abort its lunar
landing in April 1970, returning its crew safely but temporarily
grounding the program again. It resumed with four successful landings on
Apollo 14 (February 1971), Apollo 15 (July 1971), Apollo 16 (April
1972), and Apollo 17 (December 1972).

In February 1969, President Richard M. Nixon convened a Space Task Group
to set recommendations for the future US civilian space program, headed
by his Vice President Spiro T. Agnew. Agnew was an enthusiastic
proponent of NASA's follow-on plans, and the STG recommended plans to
develop a reusable Space Transportation System including a Space
Shuttle, which would facilitate development of permanent space stations
in Earth and lunar orbit, perhaps a base on the lunar surface, and the
first human flight to Mars as early as 1986 or as late as 2000. Nixon
had a better sense of the declining political support in Congress for a
new Apollo-style program, which had disappeared with the achievement of
the landing, and he intended to pursue detente with the USSR and China,
which he hoped might ease Cold War tensions. He cut the spending
proposal he sent to Congress to include funding for only the Space
Shuttle, with perhaps an option to pursue the Earth orbital space
station for the foreseeable future.

The USSR continued trying to perfect their N1 rocket, finally canceling
it in 1976, after two more launch failures in 1971 and 1972.

![](media/image15.jpg){width="5.5in" height="3.9099529746281716in"}\
*The Soyuz 11 crew with the Salyut station in the background, in a
Soviet commemorative stamp*

Salyuts and Skylab
==================

-   *Having lost the race to the Moon, the USSR decided to concentrate
    on orbital space stations.*

-   *The disaster was blamed on a faulty cabin pressure valve, that
    allowed all the air to vent into space.*

-   *The crew became the second in-flight space fatality during their
    reentry on June 30.*

-   *During 1969 and 1970, they launched six more Soyuz flights after
    Soyuz 3, then launched the first space station, the Salyut 1
    laboratory designed by Kerim Kerimov, on April 19, 1971.*

Having lost the race to the Moon, the USSR decided to concentrate on
orbital space stations. During 1969 and 1970, they launched six more
Soyuz flights after Soyuz 3, then launched the first space station, the
Salyut 1 laboratory designed by Kerim Kerimov, on April 19, 1971. Three
days later, the Soyuz 10 crew attempted to dock with it, but failed to
achieve a secure enough connection to safely enter the station. The
Soyuz 11 crew of Vladislav Volkov, Georgi Dobrovolski and Viktor
Patsayev successfully docked on June 7, and completed a record 22-day
stay. The crew became the second in-flight space fatality during their
reentry on June 30. They were asphyxiated when their spacecraft's cabin
lost all pressure, shortly after undocking. The disaster was blamed on a
faulty cabin pressure valve, that allowed all the air to vent into
space. The crew was not wearing pressure suits and had no chance of
survival once the leak occurred.

Salyut 1's orbit was increased to prevent premature reentry, but further
piloted flights were delayed while the Soyuz was redesigned to fix the
new safety problem. The station re-entered the Earth's atmosphere on
October 11, after 175 days in orbit. The USSR attempted to launch a
second Salyut-class station designated Durable Orbital Station-2 (DOS-2)
on July 29, 1972, but a rocket failure caused it to fail to achieve
orbit. After the DOS-2 failure, the USSR attempted to launch four more
Salyut-class stations up to 1975, with another failure due to an
explosion of the final rocket stage, which punctured the station with
shrapnel so that it would not hold pressure. All of the Salyuts were
presented to the public as non-military scientific laboratories, but
some of them were covers for the military Almaz reconnaissance stations.

The United States launched the orbital workstation Skylab 1 on May 14,
1973. It weighed 169,950 pounds (77,090 kg), was 58 feet (18 m) long by
21.7 feet (6.6 m) in diameter, with a habitable volume of 10,000 cubic
feet (280 m3). Skylab was damaged during the ascent to orbit, losing one
of its solar panels and a meteoroid thermal shield. Subsequent crewed
missions repaired the station, and the final mission's crew, Skylab 4,
set the Space Race endurance record with 84 days in orbit when the
mission ended on February 8, 1974. Skylab stayed in orbit another five
years before reentering the Earth's atmosphere over the Indian Ocean and
Western Australia on July 11, 1979.

![](media/image16.jpg){width="5.5in" height="4.402347987751531in"}\
*Apollo-Soyuz crew: From left to right: Donald "Deke" Slayton, Thomas
Patten Stafford, Vance Brand, Alexei Leonov, and Valeri Kubasov*

Apollo–Soyuz Test Project
=========================

-   *In May 1972, President Richard M. Nixon and Soviet Premier Leonid
    Brezhnev negotiated an easing of relations known as detente,
    creating a temporary "thaw" in the Cold War.*

-   *To prepare, the US designed a docking module for the Apollo that
    was compatible with the Soviet docking system, which allowed any of
    their craft to dock with any other (e.g.*

In May 1972, President Richard M. Nixon and Soviet Premier Leonid
Brezhnev negotiated an easing of relations known as detente, creating a
temporary "thaw" in the Cold War. In the spirit of good sportsmanship,
the time seemed right for cooperation rather than competition, and the
notion of a continuing "race" began to subside.

The two nations planned a joint mission to dock the last US Apollo craft
with a Soyuz, known as the Apollo-Soyuz Test Project (ASTP). To prepare,
the US designed a docking module for the Apollo that was compatible with
the Soviet docking system, which allowed any of their craft to dock with
any other (e.g. Soyuz/Soyuz as well as Soyuz/Salyut). The module was
also necessary as an airlock to allow the men to visit each other's
craft, which had incompatible cabin atmospheres. The USSR used the Soyuz
16 mission in December 1974 to prepare for ASTP.

The joint mission began when Soyuz 19 was first launched on July 15,
1975, at 12:20 UTC, and the Apollo craft was launched with the docking
module six and a half hours later. The two craft rendezvoused and docked
on July 17 at 16:19 UTC. The three astronauts conducted joint
experiments with the two cosmonauts, and the crew shook hands, exchanged
gifts, and visited each other's craft.

Legacy
======

![](media/image17.jpg){width="5.5in" height="3.5076531058617673in"}\
*International Space Station in 2010*

Human spaceflight after Apollo
==============================

-   *The USSR continued to develop space station technology with the
    Salyut program and Mir ('Peace' or 'World', depending on the
    context) space station, supported by Soyuz spacecraft.*

-   *The United States and Russia have worked together in space with the
    Shuttle–Mir Program, and again with the International Space
    Station.*

-   *They developed their own large space shuttle under the Buran
    program.*

In the 1970s, the United States began developing a new generation of
reusable orbital spacecraft known as the Space Shuttle, and launched a
range of uncrewed probes. The USSR continued to develop space station
technology with the Salyut program and Mir ('Peace' or 'World',
depending on the context) space station, supported by Soyuz spacecraft.
They developed their own large space shuttle under the Buran program.
The USSR dissolved in 1991 and the remains of its space program mainly
passed to Russia. The United States and Russia have worked together in
space with the Shuttle–Mir Program, and again with the International
Space Station.

The Russian R-7 rocket family, which launched the first Sputnik at the
beginning of the Space Race, is still in use today. It services the
International Space Station (ISS) as the launcher for both the Soyuz and
Progress spacecraft. It also ferries both Russian and American crews to
and from the station.

See also
========

Notes
=====

References
==========

-   *Space Race: The Epic Battle Between America and the Soviet Union
    for Dominance of Space.*

-   *Sputnik and the Soviet Space Challenge.*

-   *A Man on the Moon: The Triumphant Story of the Apollo Space
    Program.*

-   *The Space Shuttle Decision: NASA's Search for a Reusable Space
    Vehicle.*

-   *The Soviet Space Race with Apollo.*

Bilstein, Roger E. (1996). Stages to Saturn: A Technological History of
the Apollo/Saturn Launch Vehicles. Washington: Scientific and Technical
Information Branch, National Aeronautics and Space Administration.
ISBN 0-16-048909-1.

Burgess, Colin; Kate Doolan; Bert Vis (2003). Fallen Astronauts: Heroes
Who Died Reaching for the Moon. Lincoln: University of Nebraska Press.
ISBN 0-8032-6212-4.

Brzezinski, Matthew (2007). Red Moon Rising: Sputnik and the Hidden
Rivalries that Ingnited the Space Race. New York: Times Books, Henry
Holt and Company. ISBN 978-0-8050-8147-3.

Burrows, William E. (1998). This New Ocean: The Story of the First Space
Age. New York: Random House. ISBN 978-0-679-44521-0. ASIN 0679445218.

Cadbury, Deborah (2006). Space Race: The Epic Battle Between America and
the Soviet Union for Dominance of Space. New York: Harper Collins
Publishers. ISBN 978-0-06-084553-7.

Chaikin, Andrew (1994). A Man on the Moon: The Triumphant Story of the
Apollo Space Program. New York: Penguin Books. ISBN 0140272011.

Cornwell, John (2003). Hitler's Scientists: Science, War, and the
Devil's Pact. New York: Viking Press. ISBN 0-670-03075-9.

Dallek, Robert (2003). An Unfinished Life: John F. Kennedy, 1917–1963.
Boston: Little, Brown and Company. ISBN 0-316-17238-3.

David, Leonard. Moon Rush (Simon and Schuster, 2019).

Gainor, Chris (2001). Arrows to the Moon: Avro's Engineers and the Space
Race. Burlington, Ontario: Apogee Books. ISBN 1-896522-83-1. Archived
from the original on July 23, 2008.CS1 maint: BOT: original-url status
unknown (link)

Gatland, Kenneth (1976). Manned Spacecraft, Second Revision. New York,
NY, USA: Macmillan Publishing Co., Inc. pp. 100–101. ISBN 0-02-542820-9.

Hall, Rex; David J. Shayler (2001). The Rocket Men: Vostok & Voskhod,
The First Soviet Manned Spaceflights. New York: Springer–Praxis Books.
ISBN 1-85233-391-X.

Hall, Rex; David J. Shayler (2003). Soyuz: A Universal Spacecraft. New
York: Springer–Praxis Books. ISBN 1-85233-657-9.

Hardesty, Von; Gene Eisman (2007). Epic Rivalry: The Inside Story of the
Soviet and American Space Race. Foreword by Sergei Khrushchev.
Washington: National Geographic Society. ISBN 978-1-4262-0119-6.

Harford, James J. (1997). Korolev: How One Man Masterminded the Soviet
Drive to Beat America to the Moon (1 ed.). New York: John Wiley & Sons.
ISBN 0-471-14853-9.

Hepplewhite, T.A. (1999). The Space Shuttle Decision: NASA's Search for
a Reusable Space Vehicle. Washington, DC: NASA.

Jones, Eric M. (January 1, 2010). "Apollo 11 Lunar Surface Journal".
Apollo Lunar Surface Journal. Internet. Retrieved August 15, 2010.

Kraft, Chris; James Schefter (2001). Flight: My Life in Mission Control.
New York: Dutton. ISBN 0-525-94571-7.

Murray, Charles; Catherine Bly Cox (1990). Apollo: The Race to the Moon.
New York: Touchstone (Simon & Schuster). ISBN 0-671-70625-X. The link is
to the 2004 edition, pages differ, but content the same.

Parry, Dan (2009). Moonshot: The Inside Story of Mankind's Greatest
Adventure. Chatham, United Kingdom: Ebury Press. ISBN 978-0-09-192837-7.

Pekkanen, Saadia M. "Governing the New Space Race." AJIL Unbound 113
(2019): 92-97. online, role of international law.

Polmar, Norman; Timothy M. Laur (1990). Strategic Air Command: People,
Aircraft, and Missiles (2 ed.). Baltimore: Nautical and Publishing
Company of America. ISBN 0-933852-77-0.

Poole, Robert (2008). Earthrise: How Man First Saw the Earth. New Haven,
Connecticut: Yale University. ISBN 978-0-300-13766-8.

Portree, David S.F. (March 1995), "Mir Hardware Heritage", Reference
Publication, NASA Reference Publication 1357, Houston TX: NASA, 95:
23249, Bibcode:1995STIN...9523249P |chapter= ignored (help)

Schefter, James (1999). The Race: The uncensored story of how America
beat Russia to the Moon. New York: Doubleday. ISBN 0-385-49253-7.

Schmitz, David F. (1999). "Cold War (1945–91): Causes". In Whiteclay
Chambers, John (ed.). The Oxford Companion to American Military History.
Oxford University Press. ISBN 0-19-507198-0.

Seamans, Robert C., Jr. (1967). "Findings, Determinations And
Recommendations". Report of Apollo 204 Review Board. NASA History
Office.

Siddiqi, Asif A. (2003). Sputnik and the Soviet Space Challenge.
Gainesville: University Press of Florida. ISBN 0-8130-2627-X.

Siddiqi, Asif A. (2003). The Soviet Space Race with Apollo. Gainesville:
University Press of Florida. ISBN 0-8130-2628-8.

Stocker, Jeremy (2004). Britain and Ballistic Missile Defence,
1942–2002. London: Frank Case. pp. 12–24. ISBN 0-7146-5696-8.

Turnhill, Reginald (2004). The Moonlandings: An Eyewitness Account. New
York: Cambridge University Press. ISBN 0-521-81595-9.

Первушин, Антон (2011). 108 минут, изменившие мир. Эксмо.
ISBN 978-5-699-48001-2. (Anton Pervushin. 108 minutes which changed the
world; in Russian)

External links
==============

-   *Shadows of the Soviet Space Age, Paul Lucas*

-   *Space Race Exhibition at the Smithsonian National Air and Space
    Museum*

-   *TheSpaceRace.com – Mercury, Gemini, and Apollo space programs*

-   *"America's Space Program: Exploring a New Frontier", a National
    Park Service Teaching with Historic Places (TwHP) lesson plan*

-   *Timeline of the Space Race to the Moon 1960 – 1969*

Scanned letter from Wernher Von Braun to Vice President Johnson

"America's Space Program: Exploring a New Frontier", a National Park
Service Teaching with Historic Places (TwHP) lesson plan

Why Did the USSR Lose the Moon Race? from Pravda, 2002-12-03

Space Race Exhibition at the Smithsonian National Air and Space Museum

TheSpaceRace.com – Mercury, Gemini, and Apollo space programs

Timeline of the Space Race to the Moon 1960 – 1969

Shadows of the Soviet Space Age, Paul Lucas

Chronology:Moon Race at russianspaceweb.com

John F. Kennedy Moon Speech at Rice Stadium and Apollo 11 Mission Video
on YouTube
