**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Tax%20returns%20of%20Donald%20Trump\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Tax returns of Donald Trump
===========================

-   *Since Trump's election, he has refused requests to release the
    returns, making him one of the few presidents in recent times to not
    reveal their tax returns.*

-   *During his presidential campaign, Trump first said he would release
    his returns after they were "worked on", then Trump claimed that,
    because the returns were being audited, he could not make them
    public, but would do so.*

The tax returns of Donald Trump have been the subject of controversy for
the past several years, particularly over making them public due to his
political career.

Before Trump announced his candidacy for president, he had offered in
2011, 2014 ("absolutely") and 2015 to release his tax returns. During
his presidential campaign, Trump first said he would release his returns
after they were "worked on", then Trump claimed that, because the
returns were being audited, he could not make them public, but would do
so. No law actually prevents tax returns from being released due to an
audit, as emphasized by the Commissioner of Internal Revenue. Further on
during his campaign, he said that voters were not interested in his
returns, "there's nothing to learn from them", and that his tax rate is
"none of your business".

Since Trump's election, he has refused requests to release the returns,
making him one of the few presidents in recent times to not reveal their
tax returns. Historians say he has been the first major party nominee
since 1976 not to make his tax returns public. Several states have
proposed bills that would require presidential candidates to release
their tax returns in order to be listed on the 2020 ballot; such a bill
was passed by the California state senate.

In May 2019 the New York State Senate passed the TRUST Act which if
signed by Gov. Andrew Cuomo would amend state law to permit the
commissioner of the state Department of Taxation and Finance to release
any state tax return requested by the leaders of the House Ways and
Means Committee, the Senate Finance Committee or the Joint Committee on
Taxation for any "specific and legitimate legislative purpose." The New
York State Legislature approved the bill on May 22, 2019.

The United States House Committee on Ways and Means has formally
requested from the Internal Revenue Service (IRS) six years of Trump's
returns. As of April 23, 2019, Treasury Secretary Steven Mnuchin has
refused to comply with the second deadline given by the committee. On
May 10, 2019, committee chairman Richard Neal subpoenaed the Treasury
Department and the IRS for the returns and seven days later the
subpoenas were defied. On May 20, 2019, a judge upheld the House
subpoenas and rejected a lawsuit which Trump filed to keep his tax and
financial records secret. The judge also denied a requested stay of his
order. A draft IRS legal memo, written in fall 2018 and reported in May
2019, concluded that the IRS must provide the requested tax returns to
Congress unless Trump invokes executive privilege, contradicting the
administration's justification for defying the earlier subpoena.

Tax figures from 1985 through 1994
==================================

-   *Trump lost \$1.17 billion between 1985 and 1994 according to 10
    years of Trump's tax information obtained by the New York Times,
    with the amount more than "nearly any other individual American
    taxpayer" during that period.*

-   *Although Trump has acknowledged the tax-advantaged nature of the
    real estate business due to large depreciation write-offs to
    generate losses and reduce tax liabilities, the Times reported
    “depreciation cannot account for the hundreds of millions of dollars
    in losses.” Due to losing more than \$500 million in combined
    losses, section 172 of the Omnibus Budget Reconciliation Act of 1993
    gave Trump \$915.7 million in tax exemption, which he used to pay
    off 8 years of taxes.*

Trump lost \$1.17 billion between 1985 and 1994 according to 10 years of
Trump's tax information obtained by the New York Times, with the amount
more than "nearly any other individual American taxpayer" during that
period. Although Trump has acknowledged the tax-advantaged nature of the
real estate business due to large depreciation write-offs to generate
losses and reduce tax liabilities, the Times reported “depreciation
cannot account for the hundreds of millions of dollars in losses.” Due
to losing more than \$500 million in combined losses, section 172 of the
Omnibus Budget Reconciliation Act of 1993 gave Trump \$915.7 million in
tax exemption, which he used to pay off 8 years of taxes.

Leaked returns of 1995 and 2005
===============================

-   *Trump claimed on his tax returns that he lost money, but did not
    recognize it in the form of canceled debts.*

-   *challenged Trump's use of the swaps because he has not released his
    tax returns.*

-   *Parts of Trump's 1995 and 2005 tax returns have been leaked.*

-   *An audit of Trump's tax returns for 2002 through 2008 was "closed
    administratively by agreement with the I.R.S.*

Parts of Trump's 1995 and 2005 tax returns have been leaked.

In October 2016, The New York Times published some tax documents from
1995. The New York Times reported that the Times had been given three
pages of certain state tax returns for Trump for the year 1995. The
materials indicated that Trump incurred a \$916 million net operating
loss which, for Federal income tax purposes, could have prevented Trump
from owing any Federal income taxes for up to 18 years. Marc Kasowitz of
Kasowitz, Benson, Torres & Friedman wrote to the Times stating,
according to one report, that "the publication of Trump's tax records
was illegal because Trump had not authorized their disclosure ...
\[and\] threatening 'prompt initiation of appropriate legal action.'"

Trump claimed on his tax returns that he lost money, but did not
recognize it in the form of canceled debts. Trump might have performed a
stock-for-debt swap. This would have allowed Trump to avoid paying
income taxes for at least 18 years. An audit of Trump's tax returns for
2002 through 2008 was "closed administratively by agreement with the
I.R.S. without assessment or payment, on a net basis, of any
deficiency." Tax attorneys believe the government may have reduced what
Trump was able to claim as a loss without requiring him to pay any
additional taxes. It is unknown whether the I.R.S. challenged Trump's
use of the swaps because he has not released his tax returns. Trump's
lawyers advised against Trump using the equity for debt swap, as they
believed it to be potentially illegal.

On March 14, 2017, the first two pages of Trump's 2005 federal income
tax returns were leaked to Rachel Maddow and shown on MSNBC. The
document states that Trump had a gross adjusted income of \$150 million
and paid \$38 million in federal taxes. The White House confirmed the
authenticity of these documents and claimed: "Despite this substantial
income figure and tax paid, it is totally illegal to steal and publish
tax returns."

Before his presidency
=====================

-   *In January 2016, Trump was asked by Chuck Todd if he would release
    his tax returns.*

-   *In 2016, Trump's tax attorneys have stated that Trump has been
    under audit since 2002.*

-   *In May 2016, Trump said that he did not plan to release his tax
    returns before the November 2016 election; the tax returns were not
    released.*

In April 2011, Trump said that when President Barack Obama produces "his
birth certificate ... I’d love to give my tax returns". Obama's birth
certificate was released a week later, resulting in Trump saying his tax
returns would be released "at the appropriate time".

In May 2014, Trump said in an interview: "If I decide to run for office,
I’ll produce my tax returns, absolutely and I would love to do that."

In February 2015, Trump said that if he ran for the presidency: "I would
release tax returns ... But I will tell you upfront ... I want to pay as
little taxes as I can as a private person".

Trump announced his candidacy for President in June 2015.

In January 2016, Trump was asked by Chuck Todd if he would release his
tax returns. Trump answered: "we'll be working that over in the next
period of time, Chuck. Absolutely. \[...\] at the appropriate time,
you'll be very satisfied."

In February 2016, Trump said that he would release his tax returns
"\[p\]robably over the next few months. They’re being worked on now."

Also in February 2016, Trump said that he could not release his tax
returns because he was under audit. Trump has elaborated that he has
been audited for a consecutive "twelve years or something like that." In
2016, Trump's tax attorneys have stated that Trump has been under audit
since 2002. However, in 2011, 2014, and 2015, Trump made offers to
release his tax returns, presumably while he was still under audit.

The IRS Commissioner at the time, John Koskinen, said that an IRS audit
does not prevent the taxpayer from releasing tax returns. Koskinen also
said that it "would be rare for anyone to be audited every year", and
that if a past audit revealed no problems, "it’s a number of years — two
or three at least" before the IRS would conduct an audit again.

There is no requirement that presidential candidates release their tax
returns but candidates are legally free to do so even when under audit.
Tax lawyers differ as to whether releasing tax returns is legally
advisable for someone like Trump who has stated he is under audit.
According to NPR, tax experts, such as New York University Law School
professor Daniel Shaviro, say that "Trump's lawyers may advise him not
to release the returns for legal strategy purposes." In contrast,
economist Paul Krugman argued that Trump should be more willing to
reveal his tax information if he were already under audit, as the reveal
might have triggered an audit if there was not one.

In May 2016, Trump said that he did not plan to release his tax returns
before the November 2016 election; the tax returns were not released.
Trump also said in May 2016 that "there's nothing to learn from" his tax
returns, and said on ABC News that his tax rate is "none of your
business".

Trump was criticized for his refusal to release tax information. Former
Republican presidential candidate Mitt Romney said, "It is disqualifying
for a modern-day presidential nominee to refuse to release tax returns
to the voters." Romney speculated, "There is only one logical
explanation for Mr. Trump's refusal to release his returns: there is a
bombshell in them." John Fund of the National Review said that
Republican convention delegates should abstain from voting for Trump if
he does not release the information, fearing that the returns could
contain an electoral "time bomb".

During the 2016 United States presidential debates, rival presidential
candidate Hillary Clinton criticized Trump, saying that only "a couple
of years" of Trump's tax returns were publicly available, "and they
showed he didn't pay any federal income tax". Trump directly responded:
"That makes me smart." Clinton went on to suggest that Trump might not
have "paid any federal income tax for a lot of years"; this resulted in
Trump saying that the taxes he paid "would be squandered" by the
government.

During his presidency
=====================

-   *Trump has continued to withhold his tax returns even into his
    presidency as of May 2019.*

-   *In May 2017, Trump said that he "might" release his tax returns
    only after he had stepped down as President.*

-   *This was in spite of his previous commitment made during his
    campaign to release his tax returns once they were not under audit.*

Trump has continued to withhold his tax returns even into his presidency
as of May 2019.

In May 2017, Trump said that he "might" release his tax returns only
after he had stepped down as President. This was in spite of his
previous commitment made during his campaign to release his tax returns
once they were not under audit.

Tax March protests
==================

-   *In January 2017, an online petition on the "We the People" portion
    of the White House's website calling for the release of Trump's tax
    returns was set up.*

-   *It constituted a series of demonstrations to pressure Trump into
    releasing his tax returns.*

-   *Trump spokesperson Kellyanne Conway then announced that Trump would
    not release his tax returns due to lack of interest.*

In January 2017, an online petition on the "We the People" portion of
the White House's website calling for the release of Trump's tax returns
was set up. The petition gained over 1 million signatures, becoming the
most signed petition on the White House's website. However, the White
House gave no official response to the petition as of April 2017. Trump
spokesperson Kellyanne Conway then announced that Trump would not
release his tax returns due to lack of interest.\[citation needed\] In
response, the Tax Marches were planned.\[citation needed\]

In April 2017, the Tax March took place. It constituted a series of
demonstrations to pressure Trump into releasing his tax returns. Cities
in the United States that had demonstrations included Arizona,
California, Colorado, Florida, Illinois, Indiana, Maine, Massachusetts,
Michigan, Minnesota, Missouri, Nevada, New Jersey, New York, North
Carolina, Ohio, Oregon, Pennsylvania, South Carolina, Texas, Utah,
Vermont, Washington State, and Washington, D.C. There were also
demonstrations in cities abroad, including Stuttgart, Germany, Tokyo,
Japan, Auckland, New Zealand and London, United Kingdom. In all, at
least 180 different protests were organized.\[citation needed\]

Formal Congressional Request to IRS
===================================

-   *Desmond served as a tax advisor to the Trump Organization and also
    worked alongside two other longtime tax advisors to the Trump
    Organization.*

-   *Under a 1924 federal tax law, 26 U.S. Code § 6103, Congress may
    request copies of anyone's tax returns.*

-   *It requested both Trump's business and personal returns for the
    years 2013 through 2018.*

On the night of the midterm elections, November 6, 2018, House Democrats
said they would use their new power to demand Trump's tax returns.
Journalist Ari Melber broke the story live on MSNBC, reporting a top
Democratic source on the Ways and Means Committee said the Committee
does "intend to request President Trump's tax returns."

In April 2019, the chairman of the United States House Committee on Ways
and Means, Congressman Richard Neal, formally requested from the IRS six
years of Trump's returns. The last time a sitting president's tax
information was requested was 45 years ago. The request was made on
April 3 via a letter to IRS Commissioner Charles Rettig. It requested
both Trump's business and personal returns for the years 2013 through
2018. The deadline he set was April 10, seven days later. After the
first deadline was not met, Neal again wrote to Rettig on April 13,
setting a second deadline of April 23, 2019, and writing that a failure
to meet the deadline would be "interpreted as a denial".

Under a 1924 federal tax law, 26 U.S. Code § 6103, Congress may request
copies of anyone's tax returns. The treasury secretary is legally
obliged to provide the tax returns, and there is no apparent legal
mechanism to deny Congress's request.

The request will be vetted by Michael J. Desmond, Chief Counsel of the
IRS and Assistant General Counsel in the Department of the Treasury.
Desmond was appointed to the IRS position by Trump. Desmond served as a
tax advisor to the Trump Organization and also worked alongside two
other longtime tax advisors to the Trump Organization. According to the
New York Times, on February 5, 2019, Trump asked Mitch McConnell to
speed up the confirmation of Desmond, reportedly indicating Desmond was
a higher priority than nominating William Barr for Attorney General.

Responses to congressional request
==================================

Official responses
==================

-   *On June 13, Steven Engel, head of the Office of Legal Counsel,
    issued an opinion supporting Mnuchin's refusal to release Trump's
    tax returns.*

-   *On April 23, after the IRS missed the second deadline to release
    the tax returns, Treasury Secretary Mnuchin declared that the
    Treasury Department would make a "final decision" on whether the tax
    returns should be released "by May 6, after receiving the Justice
    Department's legal conclusions".*

On April 10, Treasury Secretary Steven Mnuchin officially replied in a
letter to the congressional request, writing that he would be personally
supervising the matter. Mnuchin refused to meet that day's deadline for
the congressional request, writing that the Treasury Department needed
time to consult with the Justice Department on whether it would comply
with the congressional request. IRS Commissioner Charles Rettig, after
being told by Senator Ron Wyden that it was his job to respond to the
request, said that the IRS is "a bureau of the Treasury", and that
Mnuchin is his boss. Representative Neal responded on April 13 that
concerns about his request "lack merit" and that "judicial precedent
commands that none of the concerns raised can legitimately be used to
deny the committee’s request."

On April 23, after the IRS missed the second deadline to release the tax
returns, Treasury Secretary Mnuchin declared that the Treasury
Department would make a "final decision" on whether the tax returns
should be released "by May 6, after receiving the Justice Department's
legal conclusions". Representative Neal responded that day that he was
seeking legal advice on this development. Mnuchin wrote to Neal on May 6
that the tax returns would not be provided, stating that the request did
not “serve a legitimate legislative purpose.” On May 10, Neal responded
by issuing subpoenas to both the Treasury Department and Internal
Revenue Service to hand over six years of President Trump’s personal and
business tax returns and grant access by May 17. On May 17, Mnuchin
again refused to hand over the records, prompting Neal to move directly
to court. On May 20, U.S. District Judge Amit Mehta in Washington
refused a request by Trump's attorneys to quash the House subpoena,
saying the IRS should comply with it. Mehta also denied a request from
Trump to allow a stay of his ruling pending an expected appeal.

On June 13, Steven Engel, head of the Office of Legal Counsel, issued an
opinion supporting Mnuchin's refusal to release Trump's tax returns.

Other responses
===============

-   *Mulvaney argued that Trump does not need to release his tax returns
    because the issue was "litigated" when voters elected Trump to the
    presidency despite his ability to release the tax returns and his
    refusal to do so; this ignored Trump's previous commitments to
    releasing his tax returns.*

-   *While there is no law requiring Trump to publicly release his tax
    returns, federal law of IRS Code section 6103(f) does require
    Trump's (or anyone else's) tax returns to be given to Congress if
    they request it.*

The White House responded to the request with White House Press
Secretary Sarah Sanders saying on Fox News: "While his taxes continue to
be under audit, he doesn’t anticipate that changing at any point anytime
soon, and therefore doesn’t have any intention to release those
returns." As of April 4, 2019, the White House has not allowed an
independent verification that an audit is actually being conducted.

Neal responded to the claim that any audit precludes release of a tax
return with: "The professional staff and the attorneys say that you can
still submit your tax forms even if you’re under audit."

On April 5, Trump's personal lawyer William Consovoy responded to the
request with a letter to the United States Department of the Treasury,
the parent agency of the IRS. The letter claimed that asking for his tax
information is "not consistent with governing law" and that Congress is
trying to violate Trump’s First Amendment rights.

When Trump was asked by reporters about whether or not he would instruct
the IRS to ignore the request, he responded "They'll speak to my lawyers
and they'll speak to the attorney general." The IRS has yet to comment
on the request.

On April 7, White House Acting Chief of Staff Mick Mulvaney said that
Trump's tax returns will "never" be released. Mulvaney argued that Trump
does not need to release his tax returns because the issue was
"litigated" when voters elected Trump to the presidency despite his
ability to release the tax returns and his refusal to do so; this
ignored Trump's previous commitments to releasing his tax returns. When
Mulvaney was questioned on Trump's claims that the tax returns could not
be released due to an audit, Mulvaney replied: "You could always allow
people to see it".

On April 10, Trump falsely stated: "There’s no law whatsoever" that
requires him to provide Congress his tax returns. While there is no law
requiring Trump to publicly release his tax returns, federal law of IRS
Code section 6103(f) does require Trump's (or anyone else's) tax returns
to be given to Congress if they request it. Trump continued, repeating
an old argument that he is not going to release his tax returns while
under audit, despite IRS commissioner Charles Rettig saying a day
earlier that an audit would not stop a taxpayer from releasing his
returns. Trump additionally made a similar argument to his aide
Mulvaney, saying that "the people don't care" about his tax returns.

Also on April 10, Fox News reported a Trump adviser as saying under
condition of anonymity that Trump has repeatedly questioned his aides
about the status of the congressional request, and also asked about the
"loyalty" of top IRS officials.

On April 14, White House press secretary Sarah Sanders said that in her
opinion, Congress is not "smart enough" to examine Trump's tax returns.
Ten members of Congress are accountants, according to the Congressional
Research Service. Three of these ten are Certified Public Accountants
licensed by their respective states.

By May 6, the White House still had not complied with the Congressional
order. On May 7, The New York Times revealed that it had acquired
information about Trump's tax returns showing over one billion dollars
in business losses with a decade in the red.

See also
========

-   *Wealth of Donald Trump*

-   *Timeline of investigations into Trump and Russia (2019)*

Timeline of investigations into Trump and Russia (2019)

Wealth of Donald Trump

References
==========
