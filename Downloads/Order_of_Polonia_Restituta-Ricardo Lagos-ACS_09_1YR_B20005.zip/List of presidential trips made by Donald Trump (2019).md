**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/List%20of%20presidential%20trips%20made%20by%20Donald%20Trump%20%282019%29\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

List of presidential trips made by Donald Trump (2019)
======================================================

-   *Also excluded are trips to Camp David, the country residence of the
    President.*

-   *This is a list of presidential trips made by Donald Trump during
    2019, the third year of his presidency as the 45th President of the
    United States.*

This is a list of presidential trips made by Donald Trump during 2019,
the third year of his presidency as the 45th President of the United
States.

This list excludes trips made within Washington, D.C., the U.S. federal
capital in which the White House, the official residence and principal
workplace of the President, is located. Also excluded are trips to Camp
David, the country residence of the President. International trips are
included. The number of visits per state or territory where he traveled
are:

One visit to: Alabama, California, Colorado, Delaware, Indiana, Iowa,
Michigan, Minnesota, Nevada, New York, Ohio, Pennsylvania, and Wisconsin

Two visits to: Alaska, Georgia, and Louisiana

Three visits to: Maryland and Texas

Eight visits to: Florida

Twelve visits to: Virginia

January
=======

February
========

March
=====

April
=====

May
===

June
====

Future trips
============

See also
========

-   *List of post-election Donald Trump rallies*

-   *List of presidential trips made by Donald Trump*

-   *List of international presidential trips made by Donald Trump*

List of international presidential trips made by Donald Trump

List of post-election Donald Trump rallies

List of presidential trips made by Donald Trump

References
==========
