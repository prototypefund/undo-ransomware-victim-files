**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Simenona\_Martinez\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Simenona Martinez
=================

-   *Simenona released her debut EP, Awakening in 2012, for which she
    wrote and co-produced every track.*

-   *She was born on July 10, 1990, and is of Honduran and Cuban
    background.*

-   *She is most well known for her work on the Disney Channel's
    Playhouse Disney show Behind the Ears and for her role in the 2012
    action crime film Alex Cross alongside Tyler Perry.*

Simenona Martinez is an American actress, singer-songwriter, visual
artist and film director from Los Angeles, California. She was born on
July 10, 1990, and is of Honduran and Cuban background. Simenona
excelled in the arts at an early age, and worked with the San Francisco
Mime Trope as a teenager. She made her television debut on the WB20
Warner Brothers station in San Francisco, California. She is most well
known for her work on the Disney Channel's Playhouse Disney show Behind
the Ears and for her role in the 2012 action crime film Alex Cross
alongside Tyler Perry. Simenona released her debut EP, Awakening in
2012, for which she wrote and co-produced every track. Her second EP,
"Can't Stop" was released in 2013.

References
==========
