**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Reindalspasset\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Reindalspasset
==============

-   *Reindalspasset is a mountain pass in Nordenskiöld Land at
    Spitsbergen, Svalbard.*

-   *It separates the 38 kilometer long valley of Reindalen from the 14
    kilometer long valley Lundströmdalen.*

Reindalspasset is a mountain pass in Nordenskiöld Land at Spitsbergen,
Svalbard. It separates the 38 kilometer long valley of Reindalen from
the 14 kilometer long valley Lundströmdalen.

References
==========

-   *Coordinates: 78°03′24″N 16°55′18″E﻿ / ﻿78.05667°N 16.92167°E﻿ /
    78.05667; 16.92167*

Coordinates: 78°03′24″N 16°55′18″E﻿ / ﻿78.05667°N 16.92167°E﻿ /
78.05667; 16.92167
