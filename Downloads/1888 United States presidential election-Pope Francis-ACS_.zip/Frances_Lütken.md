**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Frances\_L%C3%BCtken\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Frances Lütken
==============

-   *Frances Lütken (born 2 October 1950) is a British cross-country
    skier.*

Frances Lütken (born 2 October 1950) is a British cross-country skier.
She competed in two events at the 1972 Winter Olympics.

References
==========
