**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/The%20Times%20of%20Israel\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

The Times of Israel
===================

-   *In February 2014, two years after its launch, The Times of Israel
    claimed a readership of 2 million.*

-   *Along with its original English-language site, The Times of Israel
    publishes in Arabic, French and Persian editions.*

-   *The Times of Israel is an Israel-based, primarily English-language
    online newspaper launched in 2012.*

The Times of Israel is an Israel-based, primarily English-language
online newspaper launched in 2012. It was co-founded by journalist David
Horovitz, who is also the founding editor, and American hedge fund
manager Seth Klarman. It covers "developments in Israel, the Middle East
and around the Jewish world." Along with its original English-language
site, The Times of Israel publishes in Arabic, French and Persian
editions. On May 1, 2019, it launched a Hebrew news site, Zman Yisrael.

In addition to publishing news reports and analysis, the website hosts a
multi-author blog platform.

In February 2014, two years after its launch, The Times of Israel
claimed a readership of 2 million. In 2017, readership increased to 3.5
million unique monthly users.

History
=======

-   *The Times of Israel was launched in February 2012.*

-   *In February 2014, two years after its launch, The Times of Israel
    claimed a readership of two million.*

-   *On 2 November 2017, hackers in Turkey took down the web site of The
    Times of Israel for three hours, replacing the homepage with
    anti-Israel propaganda.*

The Times of Israel was launched in February 2012. Its co-founders are
journalist David Horovitz, and American billionaire Seth Klarman,
founder of the Baupost Group and chairman of The David Project. Klarman
is the chairman of the website.

Several Times of Israel editors had previously worked for the Haaretz
English edition, including Joshua Davidovich and Raphael Ahren, and
former Haaretz Arab affairs correspondent Avi Isaacharoff joined as its
Middle East analyst.

The Times of Israel launched its Arabic edition, edited by Suha Halifa,
on 4 February 2014, its French edition, edited by Stephanie Bitan, on 25
February 2014 and its Persian edition, edited by Avi Davidi, on 7
October 2015. It launched its Hebrew site, Zman Yisael, on 1 May 2019,
edited by Biranit Goren.

Both the Arabic and French editions combine translations of English
content with original material in their respective languages, and also
host a blog platform. In announcing the Arabic edition, Horovitz
suggested, The Times of Israel may have created the first Arabic blog
platform that "draw\[s\] articles from across the spectrum of opinion.
We're inviting those of our Arabic readers with something of value that
they want to say to blog on our pages, respecting the parameters of
legitimate debate, joining our marketplace of ideas." In order "to avoid
the kind of anonymous comments that can reduce discussion to toxic
lows", comments on news articles and features in all of the site's
editions can only be posted by readers identified through their Facebook
profiles or equivalent.

In February 2014, two years after its launch, The Times of Israel
claimed a readership of two million. In 2017, readership increased to
3.5 million.

Since 2016, The Times has hosted the websites of Jewish newspapers in
several countries. In March 2016, it began hosting New York's The Jewish
Week. It also hosts Britain's Jewish News, the New Jersey Jewish
Standard, The Atlanta Jewish Times and The Jewish Chronicle of
Pittsburgh.

On 2 November 2017, hackers in Turkey took down the web site of The
Times of Israel for three hours, replacing the homepage with anti-Israel
propaganda. Responding to the attack, David Horovitz said: "We
constantly work to improve security on the site, which is subjected to
relentless attacks by hackers. How unfortunate, and how badly it
reflects on them that the hackers seek to prevent people from reading
responsible, independent journalism on Israel, the Middle East and the
Jewish world."

Editorial orientation
=====================

-   *According to editor David Horovitz, The Times of Israel is intended
    to be independent, without any political leanings."*

According to editor David Horovitz, The Times of Israel is intended to
be independent, without any political leanings." The paper's editorial
board is composed of former Jerusalem Report editor Sharon Ashley, Irwin
Cotler, Efraim Halevy, Saul Singer and Ehud Yaari. Yehuda Avner was a
member of the editorial board until his death in March 2015. Horowitz
said in 2012: "We are independent; we're not attached or affiliated with
any political party."

Coverage issues
===============

-   *It was a case of investigative journalism at its best and The Times
    of Israel should be proud of its journalists and editors."*

-   *In a Times of Israel blog, Knesset member Karine Elharrar of Yesh
    Atid credited the paper for bringing the issue to the attention of
    Israeli lawmakers: "Over the past year The Times of Israel shone a
    spotlight on Israel’s ugly binary options industry.*

A series of investigative articles, starting with a March 2016 piece by
Simona Weinglass titled "The wolves of Tel Aviv: Israel’s vast, amoral
binary options scam exposed," helped shed light on a
multi-billion-dollar global scam in Israel. As a direct result of The
Times of Israel’s investigative reporting on the fraud, on 23 October
2017 the Israeli parliament, the Knesset, unanimously passed a law
banning Israel’s binary options industry. The law gives binary options
firms in Israel three months since the law was passed to cease
operations. After that, anyone involved in binary options is punishable
by up to two years in jail.

In a Times of Israel blog, Knesset member Karine Elharrar of Yesh Atid
credited the paper for bringing the issue to the attention of Israeli
lawmakers: "Over the past year The Times of Israel shone a spotlight on
Israel’s ugly binary options industry. It was a case of investigative
journalism at its best and The Times of Israel should be proud of its
journalists and editors."

Notable writers
===============

Analysts and journalists
========================

Academics, bloggers, and public figures
=======================================

Competition
===========

-   *The Times of Israel competes for readership with The Jerusalem
    Post, Arutz Sheva, Haaretz, Israel Hayom and The Forward.*

The Times of Israel competes for readership with The Jerusalem Post,
Arutz Sheva, Haaretz, Israel Hayom and The Forward.

See also
========

-   *Media of Israel*

Media of Israel

References
==========

External links
==============

-   *Official website*

Official website
