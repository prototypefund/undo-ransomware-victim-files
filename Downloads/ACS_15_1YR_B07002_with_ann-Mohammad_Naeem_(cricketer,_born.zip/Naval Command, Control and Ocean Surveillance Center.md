**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Naval%20Command%2C%20Control%20and%20Ocean%20Surveillance%20Center\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Naval Command, Control and Ocean Surveillance Center
====================================================

-   *NCCOSC's mission, in support of SPAWAR, is to develop, acquire, and
    support systems for information transfer and management to provide
    naval forces a decisive warfare advantage and to be the Navy's
    center for research, development, test and evaluation, engineering,
    and fleet support for command, control, communications, and ocean
    surveillance systems.*

-   *The Naval Command, Control and Ocean Surveillance Center (NCCOSC)
    is the Space and Naval Warfare Systems Command's (SPAWAR's) warfare
    center for command, control, communications, and ocean
    surveillance.*

The Naval Command, Control and Ocean Surveillance Center (NCCOSC) is the
Space and Naval Warfare Systems Command's (SPAWAR's) warfare center for
command, control, communications, and ocean surveillance. NCCOSC's
mission, in support of SPAWAR, is to develop, acquire, and support
systems for information transfer and management to provide naval forces
a decisive warfare advantage and to be the Navy's center for research,
development, test and evaluation, engineering, and fleet support for
command, control, communications, and ocean surveillance systems.

External links
==============

-   *Official website*

Official website
