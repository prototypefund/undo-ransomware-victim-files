**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/List%20of%20United%20States%20Senators%20from%20West%20Virginia\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

List of United States Senators from West Virginia
=================================================

-   *West Virginia is currently represented in the Senate by Democrat
    Joe Manchin (serving since 2010) and Republican Shelley Moore Capito
    (serving since 2015), making it one of nine states to have a split
    United States Senate delegation.*

-   *Senators belong to Classes 1 and 2.*

-   *Below is a list of United States Senators from West Virginia.*

Below is a list of United States Senators from West Virginia. The
state's U.S. Senators belong to Classes 1 and 2. West Virginia is
currently represented in the Senate by Democrat Joe Manchin (serving
since 2010) and Republican Shelley Moore Capito (serving since 2015),
making it one of nine states to have a split United States Senate
delegation.

List of Senators
================

Living former U.S. Senators from West Virginia
==============================================

-   *As of January 2019\[update\], there are two living former U.S.*

-   *Senators from West Virginia, one from Class 1 and one from
    Class 2.*

As of January 2019\[update\], there are two living former U.S. Senators
from West Virginia, one from Class 1 and one from Class 2. The most
recent Senator to die was Robert Byrd (served 1959–2010), who died in
office on June 28, 2010 and is also the most recently serving Senator to
die.

See also
========

-   *United States congressional delegations from West Virginia*

-   *List of United States Representatives from West Virginia*

List of United States Representatives from West Virginia

United States congressional delegations from West Virginia

References
==========
