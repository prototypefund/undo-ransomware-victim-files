**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Rye\_Valley%2C\_Oregon\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Rye Valley, Oregon
==================

-   *Rye Valley is an unincorporated community in Baker County, in the
    U.S. state of Oregon.*

Rye Valley is an unincorporated community in Baker County, in the U.S.
state of Oregon. It lies along Dixie Creek, a tributary of the Burnt
River, about 30 miles (48 km) southeast of Baker City. It is slightly
west of Interstate 84 near Weatherby and Dixie.

The community is named for a native grass used as forage for pack
animals important to the region's immigrants and miners in the 1860s. A
Rye Valley post office opened on September 27, 1869, and operated
intermittently between then and September 14, 1935. Nayson S. Whitcomb
was the first postmaster.

On July 24, 2014, a wildfire started by lightning happened in Rye
Valley. The lightning first struck on Bureau of Land Management lands;
however, winds quickly drove it onto forestlands protected by the Oregon
Department of Forestry. The fire took three days to fully contain.

References
==========
