**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Carl\_Roberts\_%28diplomat%29\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Carl Roberts (diplomat)
=======================

-   *Carl Bertrand Westerby Roberts CMG (born October 13, 1948) is an
    Antiguan and Barbudan diplomat and is the former High Commissioner
    of Antigua and Barbuda to the United Kingdom, with concurrent
    accreditations as Ambassador of Antigua and Barbuda to France,
    Germany, Italy and Spain.*

Carl Bertrand Westerby Roberts CMG (born October 13, 1948) is an
Antiguan and Barbudan diplomat and is the former High Commissioner of
Antigua and Barbuda to the United Kingdom, with concurrent
accreditations as Ambassador of Antigua and Barbuda to France, Germany,
Italy and Spain.

Career
======

-   *From 2002 to 2004 he was Chief Executive of Cable & Wireless (WI)
    Ltd. in St Kitts & Nevis.*

-   *In 1967 he joined the Cable & Wireless (WI) Ltd.*

-   *On October 3, 2004 he was commissioned High Commissioner to
    London.*

-   *From 1997 to 2002 he was Chief Executive of Cable & Wireless (WI)
    Ltd. in Dominica.*

-   *From 1995 to 1997 he was General Manager of Cable & Wireless (WI)
    Ltd. in Montserrat.*

In 1967 he joined the Cable & Wireless (WI) Ltd.

From 1995 to 1997 he was General Manager of Cable & Wireless (WI) Ltd.
in Montserrat.

From 1997 to 2002 he was Chief Executive of Cable & Wireless (WI) Ltd.
in Dominica.

From 2002 to 2004 he was Chief Executive of Cable & Wireless (WI) Ltd.
in St Kitts & Nevis.

On October 3, 2004 he was commissioned High Commissioner to London.

On 8 December 2004 Roberts presented his Letters of Credence to Queen
Elizabeth II.

From 2004 to 2014 he was High Commissioner to London and concurrently
Ambassador to Berlin, Madrid, Moscow, Rome, Paris, where he was
Permanent Representative to the UNESCO and in Geneva he was Deputy
Permanent Representative to the World Trade Organization.

In the 2012 New Year Honours, Roberts was appointed Companion of the
Order of St Michael and St George (CMG)

References
==========
