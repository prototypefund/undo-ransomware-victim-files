**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Thyrgis\_lacryma\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Thyrgis lacryma
===============

-   *Thyrgis lacryma is a moth in the subfamily Arctiinae.*

Thyrgis lacryma is a moth in the subfamily Arctiinae. It was described
by Paul Dognin in 1919. It is found in French Guiana.

References
==========

-   *Natural History Museum Lepidoptera generic names catalog*

Natural History Museum Lepidoptera generic names catalog
