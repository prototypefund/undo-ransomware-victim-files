**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/French\_ship\_Caton\_%281777%29\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

French ship Caton (1777)
========================

-   *She was captured by the Royal Navy at the Battle of the Mona
    Passage on 19 April 1782, and commissioned as the third rate HMS
    Caton.*

-   *Le Caton was a 64-gun ship of the line of the French Navy, launched
    in 1777.*

Le Caton was a 64-gun ship of the line of the French Navy, launched in
1777.

She was captured by the Royal Navy at the Battle of the Mona Passage on
19 April 1782, and commissioned as the third rate HMS Caton. She sailed
with the fleet for England on 25 July 1782 but was said to have been
lost later that year in a hurricane storm off Newfoundland on 16–17
September, along with the other captured French prize ships Ville de
Paris, and Hector. In fact, she struggled to reach Halifax NS.

On January 26, 1783, a small British convoy of eight military transports
sailed out of Halifax for England; accompanied by the captured French
64-gun man-of war\
Le Caton, and escorted by the veteran 36-gun frigate HMS Pallas.

Later she became a prison hospital ship at Plymouth and was placed on
harbour service in 1798, and sold out of the service in 1815.

Notes
=====

References
==========
