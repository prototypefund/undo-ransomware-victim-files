**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Ruger\_SP101\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Ruger SP101
===========

-   *The Ruger SP101 is a series of double-action revolvers produced by
    the American company Sturm, Ruger.*

-   *The SP101 is a small frame and all-steel-construction carry
    revolver, with a five-shot (.38 Special, .357 Magnum, and 9×19mm
    Parabellum), six-shot (.327 Federal Magnum and .32 H&R Magnum), or
    eight-shot (.22 LR) cylinder.*

The Ruger SP101 is a series of double-action revolvers produced by the
American company Sturm, Ruger. The SP101 is a small frame and
all-steel-construction carry revolver, with a five-shot (.38 Special,
.357 Magnum, and 9×19mm Parabellum), six-shot (.327 Federal Magnum and
.32 H&R Magnum), or eight-shot (.22 LR) cylinder.

History
=======

-   *The Ruger SP101 was introduced in 1989 as the smaller-frame
    counterpart to the GP100.*

-   *Both of these revolvers, together, replaced Sturm, Ruger & Co's
    long-standing staple in the American firearms market, the Ruger
    Security-Six series revolvers.*

The Ruger SP101 was introduced in 1989 as the smaller-frame counterpart
to the GP100. Both of these revolvers, together, replaced Sturm, Ruger &
Co's long-standing staple in the American firearms market, the Ruger
Security-Six series revolvers. A 9 mm version was available until its
discontinuation around 1998, but was later re-released in early 2018. A
basic .22 LR version was also available until 2003 while a redesigned
version was introduced in 2011.

Features and description
========================

-   *Fixed (all calibers) or adjustable (.327 Federal Magnum, .357
    Magnum and .22 LR) sights*

-   *The SP101 is currently manufactured in .327 Federal Magnum, .357
    Magnum, 9 mm, .38 Special, and .22 LR.*

The SP101 is currently manufactured in .327 Federal Magnum, .357 Magnum,
9 mm, .38 Special, and .22 LR.

Barrel lengths 2​1⁄4" (57.15mm), 3​1⁄16" (77.79mm), and 4​1⁄5" (106.7mm)
with full underlugs. 4" (101.6 mm) and 4​1⁄5" (106.7mm) with half
underlug.

Stainless steel construction

Transfer bar safety mechanism\
Firing pin mounted in frame\
The Transfer bar in the SP101 is connected directly to the trigger

Fixed (all calibers) or adjustable (.327 Federal Magnum, .357 Magnum and
.22 LR) sights

Spurred or spurless (double-action only) hammer

Specifications
==============

-   *Five-shot (.38 Special, .357 Magnum, 9×19mm Parabellum), six-shot
    (.327 Federal Magnum, .32 H&R Magnum), eight-shot (.22 LR)*

-   *(765 g)\
    4​1⁄5", 22 LR: 30 oz.*

-   *(850 g), .327 Federal Magnum: 29.5 oz (836 g), and .357 Magnum:
    29.5 oz.*

-   *Weight:\
    2​1⁄4", 25​1⁄2 oz.*

Weight:\
2​1⁄4", 25​1⁄2 oz. (708 g)\
3​1⁄16", 27 oz. (765 g)\
4​1⁄5", 22 LR: 30 oz. (850 g), .327 Federal Magnum: 29.5 oz (836 g), and
.357 Magnum: 29.5 oz.(836 g)

Barrel lengths: 2​1⁄4" (57.15 mm), 3​1⁄16" (77.79 mm), 4" (101.6 mm)

Double-action/single-action\
Double action only on select models

Five-shot (.38 Special, .357 Magnum, 9×19mm Parabellum), six-shot (.327
Federal Magnum, .32 H&R Magnum), eight-shot (.22 LR)

Maximum effective range: 33 to 55 yards (30 to 50 meters) depending on
barrel length and cartridge load\[citation needed\]

Models
======

-   *Caliber: .357 Magnum SP101s handle all .357 Magnum factory loads
    and accept factory .38 Special cartridges*

All models are made of stainless steel

Caliber: .357 Magnum SP101s handle all .357 Magnum factory loads and
accept factory .38 Special cartridges

Spurless-hammer models (double-action only) are designated by an "L" in
their catalog numbers

Notes
=====

References
==========

-   *Ruger SP101 -- A Sturdy Rimfire "Secret" by Clair Rees, Guns*

-   *Ruger's SP101 page*

Ruger's SP101 page

Ruger SP101 -- A Sturdy Rimfire "Secret" by Clair Rees, Guns

External links
==============
