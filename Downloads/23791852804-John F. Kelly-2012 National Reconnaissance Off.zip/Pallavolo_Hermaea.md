**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Pallavolo\_Hermaea\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Pallavolo Hermaea
=================

-   *Volley Hermaea is an Italian women's volleyball club based in Olbia
    and currently playing in the Serie A2.*

Volley Hermaea is an Italian women's volleyball club based in Olbia and
currently playing in the Serie A2.

Previous names
==============

-   *Gruppo Sportivo Avis Olbia (1980–1983)*

-   *Golem Olbia (2017–present)*

-   *Volley Hermaea Olbia (....–2014)*

-   *Pallavolo Hermaea Olbia (1983–....)*

-   *Entu Olbia (2014–2017)*

Due to sponsorship, the club have competed under the following names:

Gruppo Sportivo Avis Olbia (1980–1983)

Pallavolo Hermaea Olbia (1983–....)

Volley Hermaea Olbia (....–2014)

Entu Olbia (2014–2017)

Golem Olbia (2017–present)

History
=======

-   *The club was established in 1980 and was originally named Gruppo
    Sportivo Avis Olbia.*

-   *The club arrived at Serie B2 (in 2007), Serie B1 (in 2012) and
    Serie A2 (in 2014).*

The club was established in 1980 and was originally named Gruppo
Sportivo Avis Olbia. It started competing in the lower divisions and
reached the Seire D in 1983, the same year its name was changed to
Pallavolo Hermaea. The club arrived at Serie B2 (in 2007), Serie B1 (in
2012) and Serie A2 (in 2014).

Venue
=====

-   *Since 2013 the club plays its home matches at the Geopalace in
    Olbia.*

Since 2013 the club plays its home matches at the Geopalace in Olbia.
The venue has a 3,000 spectators capacity.

Team
====

-   *Season 2017–2018, as of December 2017.*

Season 2017–2018, as of December 2017.

References
==========

-   *2018-2019*

-   *source:hermaeavolley.it*

2018-2019

source:hermaeavolley.it

External links
==============

-   *Official website ‹See Tfd›(in Italian)*

Official website ‹See Tfd›(in Italian)
