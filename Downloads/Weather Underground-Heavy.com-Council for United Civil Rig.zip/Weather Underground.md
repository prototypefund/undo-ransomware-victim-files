**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Weather%20Underground\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Weather Underground
===================

-   *The Weather Underground Organization (WUO), commonly known as the
    Weather Underground, was a radical left militant organization active
    in the late 1960s and 1970s, founded on the Ann Arbor campus of the
    University of Michigan.*

-   *In 1970 the group issued a "Declaration of a State of War" against
    the United States government, under the name "Weather Underground
    Organization".*

-   *The Weather Underground was classified by the FBI as "domestic
    terrorist group."*

The Weather Underground Organization (WUO), commonly known as the
Weather Underground, was a radical left militant organization active in
the late 1960s and 1970s, founded on the Ann Arbor campus of the
University of Michigan. Originally called Weatherman, the group became
known colloquially as the Weathermen. Weatherman organized in 1969 as a
faction of Students for a Democratic Society (SDS) composed for the most
part of the national office leadership of SDS and their supporters.
Their political goal, stated in print after 1974, was to create a
revolutionary party to overthrow U.S. imperialism.

The Weather Underground was classified by the FBI as "domestic terrorist
group." With revolutionary positions characterized by black power and
opposition to the Vietnam War, the group conducted a campaign of
bombings through the mid-1970s and took part in actions such as the
jailbreak of Timothy Leary in 1970. The "Days of Rage", their first
public demonstration on October 8, 1969, was a riot in Chicago timed to
coincide with the trial of the Chicago Seven. In 1970 the group issued a
"Declaration of a State of War" against the United States government,
under the name "Weather Underground Organization".

The bombing campaign targeted government buildings, along with several
banks. The group stated that the United States government had been
exploiting other nations by waging war as a means of solidifying America
as a greater nation. Some attacks were preceded by evacuation warnings,
along with threats identifying the particular matter that the attack was
intended to protest. Three members of the group were killed in the
accidental Greenwich Village townhouse explosion but no civilians were
killed in any of the terrorist attacks.

For the bombing of the United States Capitol on March 1, 1971, they
issued a communiqué saying that it was "in protest of the U.S. invasion
of Laos". For the bombing of the Pentagon on May 19, 1972, they stated
that it was "in retaliation for the U.S. bombing raid in Hanoi". For the
January 29, 1975 bombing of the United States Department of State
building, they stated that it was "in response to the escalation in
Vietnam".

The Weathermen grew out of the Revolutionary Youth Movement (RYM)
faction of SDS. It took its name from Bob Dylan's lyric, "You don't need
a weatherman to know which way the wind blows", from the song
"Subterranean Homesick Blues" (1965). "You Don't Need a Weatherman to
Know Which Way the Wind Blows" was the title of a position paper that
they distributed at an SDS convention in Chicago on June 18, 1969. This
founding document called for a "white fighting force" to be allied with
the "Black Liberation Movement" and other radical movements to achieve
"the destruction of U.S. imperialism and achieve a classless world:
world communism".

The Weathermen began to disintegrate after the United States reached a
peace accord in Vietnam in 1973,\[page needed\] after which the New Left
declined in influence. By 1977, the organization was defunct.

Background and formation
========================

-   *The police killing of Panther Fred Hampton prompted the Weatherman
    to issue a declaration of war upon the United States government.*

-   *The Weathermen emerged from the campus-based opposition to United
    States involvement in the Vietnam War and from the civil rights
    movement of the 1960s.*

-   *The Weathermen strongly sympathized with the radical Black Panther
    Party.*

The Weathermen emerged from the campus-based opposition to United States
involvement in the Vietnam War and from the civil rights movement of the
1960s. One of the factors that contributed to the radicalization of SDS
members was the Economic Research and Action Project that the SDS
undertook in Northern urban neighborhoods from 1963 to 1968. This
project was aimed at creating an interracial movement of the poor that
would mobilize for full and fair employment or guaranteed annual income
and political rights for poverty class Americans. Their goal was to
create a more democratic society "which guarantees political freedom,
economic and physical security, abundant education, and incentives for
wide cultural variety". While the initial phase of the SDS involved
campus organizing, phase two involved community organizing. These
experiences led some SDS members to conclude that deep social change
would not happen through community organizing and electoral politics,
and that more radical and disruptive tactics were needed.

In the late 1960s, United States military action in Southeast Asia
escalated, especially in Vietnam. In the U.S., the anti-war sentiment
was particularly pronounced during the 1968 U.S. presidential election

The origins of the Weathermen can be traced to the collapse and
fragmentation of the Students for a Democratic Society following a split
between office holders of SDS, or "National Office", and their
supporters and the Progressive Labor Party (PLP). During the factional
struggle National Office leaders such as Bernardine Dohrn and Mike
Klonsky began announcing their emerging perspectives, and Klonsky
published a document titled "Toward a Revolutionary Youth Movement"
(RYM).

RYM promoted the philosophy that young workers possessed the potential
to be a revolutionary force to overthrow capitalism, if not by
themselves then by transmitting radical ideas to the working class.
Klonsky's document reflected the philosophy of the National Office and
was eventually adopted as official SDS doctrine. During the summer of
1969, the National Office began to split. A group led by Klonsky became
known as RYM II, and the other side, RYM I, was led by Dohrn and
endorsed more aggressive tactics such as direct action, as some members
felt that years of nonviolent resistance had done little or nothing to
stop the Vietnam War. The Weathermen strongly sympathized with the
radical Black Panther Party. The police killing of Panther Fred Hampton
prompted the Weatherman to issue a declaration of war upon the United
States government.

SDS Convention, June 1969
=========================

-   *In July 1969, 30 members of Weatherman leadership traveled to Cuba
    and met with North Vietnamese representatives to gain from their
    revolutionary experience.*

-   *The latter document outlined the position of the group that would
    become the Weathermen.*

-   *The document called for creating a clandestine revolutionary
    party.*

At an SDS convention in Chicago on June 18, 1969, the National Office
attempted to persuade unaffiliated delegates not to endorse a takeover
of SDS by Progressive Labor who had packed the convention with their
supporters. At the beginning of the convention, two position papers were
passed out by the National Office leadership, one a revised statement of
Klonsky's RYM manifesto, the other called "You Don't Need a Weatherman
to Know Which Way the Wind Blows".\
The latter document outlined the position of the group that would become
the Weathermen. It had been signed by Karen Ashley, Bill Ayers,
Bernardine Dohrn, John Jacobs, Jeff Jones, Gerry Long, Howie Machtinger,
Jim Mellen, Terry Robbins, Mark Rudd, and Steve Tappis. The document
called for creating a clandestine revolutionary party.

At this convention the Weatherman faction of the Students for a
Democratic Society, planned for October 8–11, as a "National Action"
built around John Jacobs' slogan, "bring the war home". The National
Action grew out of a resolution drafted by Jacobs and introduced at the
October 1968 SDS National Council meeting in Boulder, Colorado. The
resolution, titled "The Elections Don't Mean Shit—Vote Where the Power
Is—Our Power Is In The Street" and adopted by the council, was prompted
by the success of the Democratic National Convention protests in August
1968 and reflected Jacobs' strong advocacy of direct action.

As part of the "National Action Staff", Jacobs was an integral part of
the planning for what quickly came to be called "Four Days of Rage". For
Jacobs, the goal of the "Days of Rage" was clear:

In July 1969, 30 members of Weatherman leadership traveled to Cuba and
met with North Vietnamese representatives to gain from their
revolutionary experience. The North Vietnamese requested armed political
action in order to stop the U.S. government's war in Vietnam.
Subsequently, they accepted funding, training, recommendations on
tactics and slogans from Cuba, and perhaps explosives as well.

SDS Convention, December 1969
=============================

-   *The Weather Underground hoped to create underground collectives in
    major cities throughout the country.*

-   *The Weatherman national leadership agreed, as did the New York City
    collective.*

-   *At the War Council, the Weathermen had decided to close the SDS
    National Office, ending the major campus-based organization of the
    1960s which at its peak was a mass organization with 100,000
    members.*

After the Days of Rage riots the Weatherman held the last of its
National Council meetings from December 26 to December 31, 1969 in
Flint, Michigan. The meeting, dubbed the "War Council" by the 300 people
who attended, adopted Jacobs' call for violent revolution. Dohrn opened
the conference by telling the delegates they needed to stop being afraid
and begin the "armed struggle." Over the next five days, the
participants met in informal groups to discuss what "going underground"
meant, how best to organize collectives, and justifications for
violence. In the evening, the groups reconvened for a mass
"wargasm"—practicing karate, engaging in physical exercise, singing
songs, and listening to speeches.

The War Council ended with a major speech by John Jacobs. Jacobs
condemned the "pacifism" of white middle-class American youth, a belief
which he claimed they held because they were insulated from the violence
which afflicted blacks and the poor. He predicted a successful
revolution, and declared that youth were moving away from passivity and
apathy and toward a new high-energy culture of "repersonalization"
brought about by drugs, sex, and armed revolution. "We're against
everything that's 'good and decent' in honky America," Jacobs said in
his most commonly quoted statement. "We will burn and loot and destroy.
We are the incubation of your mother's nightmare."

Two major decisions came out of the War Council. The first was to go
underground, and to begin a violent, armed struggle against the state
without attempting to organize or mobilize a broad swath of the public.
The Weather Underground hoped to create underground collectives in major
cities throughout the country. In fact, the Weathermen eventually
created only three significant, active collectives; one in California,
one in the Midwest, and one in New York City. The New York City
collective was led by Jacobs and Terry Robbins, and included Ted Gold,
Kathy Boudin, Cathy Wilkerson (Robbins' girlfriend), and Diana Oughton.
Jacobs was one of Robbins' biggest supporters, and pushed the Weathermen
to let Robbins be as violent as he wanted to be. The Weatherman national
leadership agreed, as did the New York City collective. The collective's
first target was Judge John Murtagh, who was overseeing the trial of the
"Panther 21".

The second major decision was the dissolution of SDS. After the summer
of 1969 fragmentation of SDS, Weatherman's adherents explicitly claimed
themselves the real leaders of SDS and retained control of the SDS
National Office. Thereafter, any leaflet, label, or logo bearing the
name "Students for a Democratic Society" (SDS) was in fact the views and
politics of Weatherman, not of the slate elected by Progressive Labor.
Weatherman contained the vast majority of former SDS National Committee
members, including Mark Rudd, David Gilbert and Bernardine Dohrn. The
group, while small, was able to commandeer the mantle of SDS and all of
its membership lists, but with Weatherman in charge there was little or
no support from local branches or members of the organization, and local
chapters soon disbanded. At the War Council, the Weathermen had decided
to close the SDS National Office, ending the major campus-based
organization of the 1960s which at its peak was a mass organization with
100,000 members.

Ideology
========

-   *The lyrics had been quoted at the bottom of an influential essay in
    the SDS newspaper, New Left Notes.*

-   *Participation in the Venceremos Brigade, a program which involved
    US students volunteering to work in the sugar harvest in Cuba, is
    highlighted as a common factor in the background of the founders of
    the Weather Underground, with China a secondary influence.*

The thesis of Weatherman theory, as expounded in its founding document,
You Don't Need a Weatherman to Know Which Way the Wind Blows, was that
"the main struggle going on in the world today is between U.S.
imperialism and the national liberation struggles against it", based on
Lenin's theory of imperialism, first expounded in 1916 in Imperialism,
the Highest Stage of Capitalism. In Weatherman theory "oppressed
peoples" are the creators of the wealth of empire, "and it is to them
that it belongs." "The goal of revolutionary struggle must be the
control and use of this wealth in the interest of the oppressed peoples
of the world." "The goal is the destruction of US imperialism and the
achievement of a classless world: world communism"

The Vietnamese and other third world countries, as well as third world
people within the United States play a vanguard role. They "set the
terms for class struggle in America ..." The role of the "Revolutionary
Youth Movement" is to build a centralized organization of
revolutionaries, a "Marxist-Leninist Party" supported by a mass
revolutionary movement to support international liberation movements and
"open another battlefield of the revolution."

The theoretical basis of the Revolutionary Youth Movement was an insight
that most of the American population, including both students and the
supposed "middle class," comprised, due to their relationship to the
instruments of production, the working class, thus the organizational
basis of the SDS, which had begun in the elite colleges and had been
extended to public institutions as the organization grew could be
extended to youth as a whole including students, those serving in the
military, and the unemployed. Students could be viewed as workers
gaining skills prior to employment. This contrasted to the Progressive
Labor view which viewed students and workers as being in separate
categories which could ally, but should not jointly organize.

FBI analysis of the travel history of the founders and initial followers
of the organization emphasized contacts with foreign governments,
particularly the Cuban and North Vietnamese and their influence on the
ideology of the organization. Participation in the Venceremos Brigade, a
program which involved US students volunteering to work in the sugar
harvest in Cuba, is highlighted as a common factor in the background of
the founders of the Weather Underground, with China a secondary
influence. This experience was cited by both Kathy Boudin and Bernardine
Dohrn as a major influence on their political development.

Terry Robbins took the organization's name from the lyrics of the Bob
Dylan song "Subterranean Homesick Blues," which featured the lyrics "You
don't need a weatherman to know which way the wind blows." The lyrics
had been quoted at the bottom of an influential essay in the SDS
newspaper, New Left Notes. By using this title the Weathermen meant,
partially, to appeal to the segment of US youth inspired to action for
social justice by Dylan's songs.

The Weatherman group had long held that militancy was becoming more
important than nonviolent forms of anti-war action, and that
university-campus-based demonstrations needed to be punctuated with more
dramatic actions, which had the potential to interfere with the US
military and internal security apparatus. The belief was that these
types of urban guerrilla actions would act as a catalyst for the coming
revolution. Many international events indeed seemed to support the
Weathermen's overall assertion that worldwide revolution was imminent,
such as the tumultuous Cultural Revolution in China; the 1968 student
revolts in France, Mexico City and elsewhere; the Prague Spring; the
Northern Ireland Civil Rights Association; the emergence of the
Tupamaros organization in Uruguay; the emergence of the Guinea-Bissauan
Revolution and similar Marxist-led independence movements throughout
Africa; and within the United States, the prominence of the Black
Panther Party, together with a series of "ghetto rebellions" throughout
poor black neighborhoods across the country.

The Weathermen were outspoken critics of the concepts that later came to
be known as "white privilege" (described as white-skin privilege) and
identity politics. As the civil disorder in poor black neighborhoods
intensified in the early 1970s, Bernardine Dohrn said, "White youth must
choose sides now. They must either fight on the side of the oppressed,
or be on the side of the oppressor."

Anti-imperialism, anti-racism, and white privilege
==================================================

-   *Weather put the international proletariat at the center of their
    political theory.*

-   *Members of Weather further contended that efforts at "organizing
    whites against their own perceived oppression" were "attempts by
    whites to carve out even more privilege than they already derive
    from the imperialist nexus".*

Weather maintained that their stance differed from the rest of the
movement at the time in the sense that they predicated their critiques
on the notion that they were engaged in "an anti-imperialist,
anti-racist struggle". Weather put the international proletariat at the
center of their political theory. Weather warned that other political
theories, including those addressing class interests or youth interests,
were "bound to lead in a racist and chauvinist direction". Weather
denounced other political theories of the time as "objectively racist"
if they did not side with the international proletariat; such political
theories, they argued, needed to be "smashed".

Members of Weather further contended that efforts at "organizing whites
against their own perceived oppression" were "attempts by whites to
carve out even more privilege than they already derive from the
imperialist nexus". Weather's political theory sought to make every
struggle an anti-imperialist, anti-racist struggle; out of this premise
came their interrogation of critical concepts that would later be known
as "white privilege". As historian Dan Berger writes, Weather raised the
question "what does it means to be a white person opposing racism and
imperialism?"

Practice
========

-   *This formation continued during 1969 and 1970 until the group went
    underground and a more relaxed lifestyle was adopted as the group
    blended into the counterculture.*

-   *However, the sessions were also successful at purging potential
    informants from the Weathermen's ranks, making them crucial to the
    Weathermen's survival as an underground organization.*

Shortly after its formation as an independent group, Weatherman created
a central committee, the Weather Bureau, which assigned its cadres to a
series of collectives in major cities. These cities included New York,
Boston, Seattle, Philadelphia, Cincinnati, Buffalo, and Chicago, the
home of the SDS' head office. The collectives set up under the Weather
Bureau drew their design from Che Guevara's foco theory, which focused
on the building of small, semi-autonomous cells guided by a central
leadership.

To try to turn their members into hardened revolutionaries and to
promote solidarity and cohesion, members of collectives engaged in
intensive criticism sessions which attempted to reconcile their prior
and current activities to Weathermen doctrine. These "criticism
self-criticism" sessions (also called "CSC" or "Weatherfries") were the
most distressing part of life in the collective. Derived from Maoist
techniques, it was intended to root out racist, individualist and
chauvinist tendencies within group members. At its most intense, members
would be berated for up to a dozen or more hours non-stop about their
flaws. It was intended to make group members believe that they were,
deep down, white supremacists by subjecting them to constant criticism
to break them down. The sessions were used to ridicule and bully those
who didn't agree with the party line and force them into acceptance.
However, the sessions were also successful at purging potential
informants from the Weathermen's ranks, making them crucial to the
Weathermen's survival as an underground organization. The Weathermen
were also determined to destroy "bourgeois individualism" amongst
members that would potentially interfere with their commitment to both
the Weathermen and the goal of revolution. Personal property was either
renounced or given to the collective, with income being used to purchase
the needs of the group and members enduring Spartan living conditions.
Conventional comforts were forbidden and the leadership was exalted,
giving them immense power over their subordinates (in some collectives
the leadership could even dictate personal decisions such as where one
went). Martial arts were practiced and occasional direct actions were
engaged in. Critical of monogamy, they launched a "smash monogamy"
campaign, in which couples (whose affection was deemed unacceptably
possessive, counterrevolutionary or even selfish) were to be split
apart; collectives underwent forced rotation of sex partners (including
allegations that some male leaders rotated women between collectives in
order to sleep with them) and in some cases engaged in sexual orgies.
This formation continued during 1969 and 1970 until the group went
underground and a more relaxed lifestyle was adopted as the group
blended into the counterculture.

Life in the collectives could be particularly hard for women, who made
up about half the members. Their political awakening had included a
growing awareness of sexism, yet they often found that men took the lead
in political activities and discussion, with women often engaging in
domestic work, as well as finding themselves confined to second-tier
leadership roles. Certain feminist political beliefs had to be disavowed
or muted and the women had to prove, regardless of prior activist
credentials, that they were as capable as men in engaging in political
action as part of "women's cadres", which were felt to be driven by
coerced machismo and failed to promote genuine solidarity amongst the
women. While the Weathermen's sexual politics did allow women to assert
desire and explore relationships with each other, it also made them
vulnerable to sexual exploitation.

Recruitment
===========

-   *Factions of the Weatherman organization began recruiting members by
    applying their own strategies.*

-   *Weather used various means by which to recruit new members and set
    into motion a nationwide revolt against the government.*

-   *In direct actions, dubbed Jailbreaks, Weather members invaded
    educational institutions as a means by which to recruit high school
    and college students.*

Weather used various means by which to recruit new members and set into
motion a nationwide revolt against the government. Weather members aimed
to mobilize people into action against the established leaders of the
nation and the patterns of injustice which existed in America and abroad
due to America's presence overseas. They also aimed to convince people
to resist reliance upon their given privilege and to rebel and take arms
if necessary. According to Weatherman, if people tolerated the unjust
actions of the state, they became complicit in those actions. In the
manifesto compiled by Bill Ayers, Bernardine Dohrn, Jeff Jones, and
Celia Sojourn, entitled "Prairie Fire: The Politics of Revolutionary
Anti-Imperialism," Weatherman explained that their intention was to
encourage the people and provoke leaps in confidence and consciousness
in an attempt to stir the imagination, organize the masses, and join in
the people's day-to-day struggles in every way possible.

In the year 1960, over a third of America's population was under 18
years of age. The number of young citizens set the stage for a
widespread revolt against perceived structures of racism, sexism, and
classism, the violence of the Vietnam War and America's interventions
abroad. At college campuses throughout the country, anger against "the
Establishment's" practices prompted both peaceful and violent protest.\
The members of Weatherman targeted high school and college students,
assuming they would be willing to rebel against the authoritative
figures who had oppressed them, including cops, principals, and bosses.
Weather aimed to develop roots within the class struggle, targeting
white working-class youths. The younger members of the working class
became the focus of the organizing effort because they felt the
oppression strongly in regards to the military draft, low-wage jobs, and
schooling.

Schools became a common place of recruitment for the movement. In direct
actions, dubbed Jailbreaks, Weather members invaded educational
institutions as a means by which to recruit high school and college
students. The motivation of these jailbreaks was the organization's
belief that school was where the youth were oppressed by the system and
where they learned to tolerate society's faults instead of rise against
them. According to "Prairie Fire", young people are channeled, coerced,
misled, miseducated, misused in the school setting. It is in schools
that the youth of the nation become alienated from the authentic
processes of learning about the world.

Factions of the Weatherman organization began recruiting members by
applying their own strategies. Women's groups such as The Motor City
Nine and Cell 16 took the lead in various recruitment efforts. Roxanne
Dunbar-Ortiz, a member of the radical women's liberation group Cell 16
spoke about her personal recruitment agenda saying that she wanted their
group to go out in every corner of the country and tell women the truth,
recruit the local people, poor and working-class people, in order to
build a new society.

Berger explains the controversy surrounding recruitment strategies
saying, "As an organizing strategy it was less than successful: white
working class youths were more alienated than organized by Weather's
spectacles, and even some of those interested in the group were turned
off by its early hi-jinks" The methods of recruitment applied by the
Weathermen met controversy as their call to arms became intensely
radical and their organization's leadership increasingly
exclusive.\[citation needed\]

Armed propaganda
================

-   *In 2006, Dan Berger (writer, activist, and longtime anti-racism
    organizer) states that following their initial set of bombings,
    which resulted in the Greenwich Village townhouse explosion, the
    organization adopted a new paradigm of direct action set forth in
    the communiqué New Morning, Changing Weather, which abjured attacks
    on people.*

In 2006, Dan Berger (writer, activist, and longtime anti-racism
organizer) states that following their initial set of bombings, which
resulted in the Greenwich Village townhouse explosion, the organization
adopted a new paradigm of direct action set forth in the communiqué New
Morning, Changing Weather, which abjured attacks on people. The shift in
the organization's outlook was in good part due to the 1970 death of
Weatherman Terry Robbins, Diana Oughton and Ted Gold, all graduate
students, in the Greenwich Village townhouse explosion. Terry Robbins
was renowned among the organization members for his radicalism and
belief in violence as effective action.\[citation needed\]

According to Dan Berger a relatively sophisticated program of armed
propaganda was adopted. This consisted of a series of bombings of
government and corporate targets in retaliation for specific imperialist
and oppressive acts. Small, well-constructed time bombs were used,
generally in vents in restrooms, which exploded at times the spaces were
empty. Timely warnings were made and communiqués issued explaining the
reason for the actions.

 Major activities
=================

![](media/image1.jpg){width="4.08659230096238in" height="5.5in"}\
*The Haymarket Square police memorial, seen in 1889*

Haymarket Police Memorial bombing
=================================

-   *The statue was rebuilt and unveiled on May 4, 1970 (coincidentally,
    the same day as the Kent State massacre), only to be blown up by the
    Weathermen a second time on October 6, 1970.*

-   *Shortly before the Days of Rage demonstrations on October 6, 1969,
    the Weatherman planted a bomb that blew up a statue in Chicago built
    to commemorate police casualties incurred in the 1886 Haymarket
    Riot.*

Shortly before the Days of Rage demonstrations on October 6, 1969, the
Weatherman planted a bomb that blew up a statue in Chicago built to
commemorate police casualties incurred in the 1886 Haymarket Riot. The
blast broke nearly 100 windows and scattered pieces of the statue onto
the Kennedy Expressway below. The statue was rebuilt and unveiled on May
4, 1970 (coincidentally, the same day as the Kent State massacre), only
to be blown up by the Weathermen a second time on October 6, 1970. The
statue was rebuilt once again and Mayor Richard J. Daley posted a
24-hour police guard to protect it, but the statue was later destroyed
again a third time. The monument was rebuilt and is located at Chicago
Police Headquarters.

"Days of Rage"
==============

-   *This was advertised to "Bring the war home!"*

-   *Most of the Weathermen and SDS leaders were now in jail, and the
    Weathermen would have to pay over \$243,000 for their bail.*

-   *One of the first acts of the Weathermen after splitting from SDS
    was to announce they would hold the "Days of Rage" that autumn.*

-   *On October 10, the Weatherman attempted to regroup and resume their
    demonstrations.*

One of the first acts of the Weathermen after splitting from SDS was to
announce they would hold the "Days of Rage" that autumn. This was
advertised to "Bring the war home!" Hoping to cause sufficient chaos to
"wake" the American public out of what they saw as complacency toward
the role of the US in the Vietnam War, the Weathermen meant it to be the
largest protest of the decade. They had been told by their regional
cadre to expect thousands to attend; however, when they arrived they
found only a few hundred people.

According to Bill Ayers in 2003, "The Days of Rage was an attempt to
break from the norms of kind of acceptable theatre of 'here are the
anti-war people: containable, marginal, predictable, and here's the
little path they're going to march down, and here's where they can make
their little statement.' We wanted to say, "No, what we're going to do
is whatever we had to do to stop the violence in Vietnam.'" The protests
did not meet Ayers' stated expectations.

Though the October 8, 1969, rally in Chicago had failed to draw as many
as the Weathermen had anticipated, the two or three hundred who did
attend shocked police by rioting through the affluent Gold Coast
neighborhood. They smashed the windows of a bank and those of many cars.
The crowd ran four blocks before encountering police barricades. They
charged the police but broke into small groups; more than 1,000 police
counter-attacked. Many protesters were wearing motorcycle or football
helmets, but the police were well-trained and armed. Large amounts of
tear gas were used, and at least twice police ran squad cars into the
mob. The rioting lasted about half an hour, during which 28 policemen
were injured. Six Weathermen were shot by the police and an unknown
number injured; 68 rioters were arrested.

For the next two days, the Weathermen held no rallies or protests.
Supporters of the RYM II movement, led by Klonsky and Noel Ignatin, held
peaceful rallies in front of the federal courthouse, an International
Harvester factory, and Cook County Hospital. The largest event of the
Days of Rage took place on Friday, October 9, when RYM II led an
interracial march of 2,000 people through a Spanish-speaking part of
Chicago.

On October 10, the Weatherman attempted to regroup and resume their
demonstrations. About 300 protesters marched through The Loop, Chicago's
main business district, watched by a double-line of heavily armed
police. The protesters suddenly broke through the police lines and
rampaged through the Loop, smashing the windows of cars and stores. The
police were prepared, and quickly isolated the rioters. Within 15
minutes, more than half the crowd had been arrested.

The Days of Rage cost Chicago and the state of Illinois about \$183,000
(\$100,000 for National Guard expenses, \$35,000 in damages, and
\$20,000 for one injured citizen's medical expenses). Most of the
Weathermen and SDS leaders were now in jail, and the Weathermen would
have to pay over \$243,000 for their bail.

Flint War Council
=================

-   *The Flint War Council was a series of meetings of the Weather
    Underground Organization and associates in Flint, Michigan, that
    took place from 27–31 December 1969.*

-   *During these meetings, the decisions were made for the Weather
    Underground Organization to go underground and to "engage in
    guerilla warfare against the U.S.*

The Flint War Council was a series of meetings of the Weather
Underground Organization and associates in Flint, Michigan, that took
place from 27–31 December 1969. During these meetings, the decisions
were made for the Weather Underground Organization to go underground and
to "engage in guerilla warfare against the U.S. government." This
decision was made in response to increased pressure from law
enforcement, and a belief that underground guerilla warfare was the best
way to combat the U.S. government.

During a closed-door meeting of the Weather Underground's leadership,
the decision was also taken to abolish Students for a Democratic
Society. This decision reflected the splintering of SDS into hostile
rival factions.

New York City arson attacks
===========================

-   *According to the December 6, 1970 "New Morning—Changing Weather"
    Weather Underground communiqué signed by Bernardine Dohrn, and Cathy
    Wilkerson's 2007 memoir, the fire-bombing of Judge Murtagh's home,
    in solidarity with the Panther 21, was carried out by four members
    of the New York cell that was devastated two weeks later by the
    March 6, 1970 townhouse explosion.*

On February 21, 1970, at around 4:30 a.m., three gasoline-filled Molotov
cocktails exploded in front of the home of New York Supreme Court
Justice John M. Murtagh, who was presiding over the pretrial hearings of
the so-called "Panther 21" members of the Black Panther Party over a
plot to bomb New York landmarks and department stores. Justice Murtagh
and his family were unharmed, but two panes of a front window were
shattered, an overhanging wooden eave was scorched, and the paint on a
car in the garage was charred. "Free the Panther 21" and "Viet Cong have
won" were written in large red letters on the sidewalk in front of the
judge's house at 529 W. 217th Street in the Inwood neighborhood of
Manhattan. The judge's house had been under hourly police surveillance
and an unidentified woman called the police a few minutes before the
explosions to report several prowlers there, which resulted in a police
car being sent immediately to the scene.

In the preceding hours, Molotov cocktails had been thrown at the second
floor of Columbia University's International Law Library at 434 W. 116th
Street and at a police car parked across the street from the Charles
Street police station in the West Village in Manhattan, and at Army and
Navy recruiting booths on Nostrand Avenue on the eastern fringe of the
Brooklyn College campus in Brooklyn, causing no or minimal damage in
incidents of unknown relation to that at Judge Murtagh's home.

According to the December 6, 1970 "New Morning—Changing Weather" Weather
Underground communiqué signed by Bernardine Dohrn, and Cathy Wilkerson's
2007 memoir, the fire-bombing of Judge Murtagh's home, in solidarity
with the Panther 21, was carried out by four members of the New York
cell that was devastated two weeks later by the March 6, 1970 townhouse
explosion.

Greenwich Village townhouse explosion
=====================================

-   *WUO members Diana Oughton, Ted Gold, and Terry Robbins died in the
    explosion.*

-   *An FBI report later stated that the group had possessed enough
    explosives to "level ... both sides of the street".*

On March 6, 1970, during preparations for the bombing of a
Non-Commissioned Officers' (NCO) dance at the Fort Dix U.S. Army base
and for Butler Library at Columbia University, there was an explosion in
a Greenwich Village safe house when the dynamite used in bomb
construction prematurely detonated for unknown reasons. WUO members
Diana Oughton, Ted Gold, and Terry Robbins died in the explosion. Cathy
Wilkerson and Kathy Boudin escaped unharmed. The site of the Village
explosion was the former residence of Merrill Lynch brokerage firm
co-founder Charles Merrill and the childhood home of his son, poet James
Merrill; the younger Merrill subsequently memorialized the event in his
poem 18 West 11th Street, the title being the address of the brownstone
townhouse.

An FBI report later stated that the group had possessed enough
explosives to "level ... both sides of the street".

Underground strategy change
===========================

-   *After the Greenwich Village townhouse explosion, per the December
    1969 Flint War Council decisions the group was now well underground,
    and began to refer to themselves as the Weather Underground
    Organization.*

-   *In 2003, Weather Underground members stated in interviews that they
    wanted to convince the American public that the United States was
    truly responsible for the calamity in Vietnam.*

After the Greenwich Village townhouse explosion, per the December 1969
Flint War Council decisions the group was now well underground, and
began to refer to themselves as the Weather Underground Organization. At
this juncture, WUO shrank considerably, becoming even fewer than they
had been when first formed. The group was devastated by the loss of
their friends, and in late April 1970, members of the Weathermen met in
California to discuss what had happened in New York and the future of
the organization. The group decided to reevaluate their strategy,
particularly regarding their initial belief in the acceptability of
human casualties, and rejected such tactics as kidnapping and
assassinations.\[citation needed\]

In 2003, Weather Underground members stated in interviews that they
wanted to convince the American public that the United States was truly
responsible for the calamity in Vietnam. The group began striking at
night, bombing empty offices, with warnings always issued in advance to
ensure a safe evacuation. According to David Gilbert, who took part in
the 1981 Brink's robbery that killed two police officers and a Brinks'
guard, and was jailed for murder, "\[their\] goal was to not hurt any
people, and a lot of work went into that. But we wanted to pick targets
that showed to the public who was responsible for what was really going
on." After the Greenwich Village explosion, in a review of the
documentary film The Weather Underground (2002), a Guardian journalist
restated the film's contention that no one was killed by WUO bombs.

Declaration of war
==================

-   *The FBI placed the Weather Underground organization on the ten
    most-wanted list by the end of 1970.*

-   *In response to the death of Black Panther members Fred Hampton and
    Mark Clark in December 1969 during a police raid, on May 21, 1970,
    the Weather Underground issued a "Declaration of War" against the
    United States government, using for the first time its new name, the
    "Weather Underground Organization" (WUO), adopting fake identities,
    and pursuing covert activities only.*

In response to the death of Black Panther members Fred Hampton and Mark
Clark in December 1969 during a police raid, on May 21, 1970, the
Weather Underground issued a "Declaration of War" against the United
States government, using for the first time its new name, the "Weather
Underground Organization" (WUO), adopting fake identities, and pursuing
covert activities only. These initially included preparations for a
bombing of a U.S. military non-commissioned officers' dance at Fort Dix,
New Jersey, in what Brian Flanagan said had been intended to be "the
most horrific hit the United States government had ever suffered on its
territory".

Bernardine Dohrn subsequently stated that it was Fred Hampton's death
that prompted the Weather Underground to declare war on the US
government.

In December 1969, the Chicago Police Department, in conjunction with the
FBI, conducted a raid on the home of Black Panther Fred Hampton, in
which he and Mark Clark were killed, with four of the seven other people
in the apartment wounded. The survivors of the raid were all charged
with assault and attempted murder. The police claimed they shot in
self-defense, although a controversy arose when the Panthers, other
activists and a Chicago newspaper reporter presented visual evidence, as
well as the testimony of an FBI ballistics expert, showing that the
sleeping Panthers were not resisting arrest and fired only one shot, as
opposed to the more than one hundred the police fired into the
apartment. The charges were later dropped, and the families of the dead
won a \$1.8 million settlement from the government. It was discovered in
1971 that Hampton had been targeted by the FBI's COINTELPRO. True to
Dohrn's words, this single event, in the continuing string of public
killings of black leaders of any political stripe, was the trigger that
pushed a large number of Weatherman and other students who had just
attended the last SDS national convention months earlier to go
underground and develop its logistical support network nationally.

On May 21, 1970, a communiqué from the Weather Underground was issued
promising to attack a "symbol or institution of American injustice"
within two weeks. The communiqué included taunts towards the FBI, daring
them to try to find the group, whose members were spread throughout the
United States. Many leftist organizations showed curiosity in the
communiqué, and waited to see if the act would in fact occur. However,
two weeks would pass without any occurrence. Then on June 9, 1970, their
first publicly acknowledged bombing occurred at a New York City police
station, saying it was "in outraged response to the assassination of the
Soledad Brother George Jackson," who had recently been killed by prison
guards in an escape attempt. The FBI placed the Weather Underground
organization on the ten most-wanted list by the end of 1970.

Activity in 1970
================

-   *In October 1970, Bernardine Dohrn was put on the FBI's Ten Most
    Wanted List.*

-   *On July 23, 1970, a Detroit federal grand jury indicted 13
    Weathermen members in a national bombing conspiracy, along with
    several unnamed co-conspirators.*

-   *On June 9, 1970, a bomb made with ten sticks of dynamite exploded
    in the 240 Centre Street, the headquarters of the New York City
    Police Department.*

On June 9, 1970, a bomb made with ten sticks of dynamite exploded in the
240 Centre Street, the headquarters of the New York City Police
Department. The explosion was preceded by a warning about six minutes
prior to the detonation and was followed by a WUO claim of
responsibility.

On July 23, 1970, a Detroit federal grand jury indicted 13 Weathermen
members in a national bombing conspiracy, along with several unnamed
co-conspirators. Ten of the thirteen already had outstanding federal
warrants.

In September 1970, the group accepted a \$20,000 payment from the
largest international psychedelic drug distribution organization, called
The Brotherhood of Eternal Love, to break LSD advocate Timothy Leary out
of a California prison in San Luis Obispo, north of Santa Barbara,
California, and transport him and his wife to Algeria, where Leary
joined Eldridge Cleaver. Rumors also circulated that the funds were
donated by an internationally known female folk singer in Los Angeles or
by Elephant's Memory, which was John Lennon's backup band in New York
City and was a factor with the attempted deportation of Lennon, who had
donated bail money for radical groups.

In October 1970, Bernardine Dohrn was put on the FBI's Ten Most Wanted
List.

Pentagon bombing
================

-   *On May 19, 1972, Ho Chi Minh's birthday, the Weather Underground
    placed a bomb in the women's bathroom in the Air Force wing of the
    Pentagon.*

On May 19, 1972, Ho Chi Minh's birthday, the Weather Underground placed
a bomb in the women's bathroom in the Air Force wing of the Pentagon.
The damage caused flooding that destroyed computer tapes holding
classified information. Other radical groups worldwide applauded the
bombing, illustrated by German youths protesting against American
military systems in Frankfurt. This was "in retaliation for the U.S.
bombing raid in Hanoi."

Withdrawal of charges
=====================

-   *\[citation needed\] The decisions in these cases led directly to
    the subsequent resignation of FBI Director, L. Patrick Gray, and the
    federal indictments of W. Mark Felt or "Deep Throat" and Edwin
    Miller and which, earlier, was the factor leading to the removal of
    federal "most-wanted" status against members of the Weather
    Underground leadership in 1973.*

In 1973, the government requested dropping charges against most of the
WUO members. The requests cited a recent decision by the Supreme Court
of the United States that barred electronic surveillance without a court
order. This Supreme Court decision would hamper any prosecution of the
WUO cases. In addition, the government did not want to reveal foreign
intelligence secrets that a trial would require. Bernardine Dohrn was
removed from the FBI's Ten Most Wanted List on 7 December 1973. As with
the earlier federal grand juries that subpoenaed Leslie Bacon and Stew
Albert in the U.S. Capitol bombing case, these investigations were known
as "fishing expeditions", with the evidence gathered through "black bag"
jobs including illegal mail openings that involved the FBI and United
States Postal Service, burglaries by FBI field offices, and electronic
surveillance by the Central Intelligence Agency against the support
network, friends, and family members of the Weather Underground as part
of Nixon's COINTELPRO apparatus.

These grand juries caused Sylvia Jane Brown, Robert Gelbhard, and future
members of the Seattle Weather Collective to be subpoenaed in Seattle
and Portland for the investigation of one of the first (and last)
captured WUO members. Four months afterwards the cases were
dismissed.\[citation needed\] The decisions in these cases led directly
to the subsequent resignation of FBI Director, L. Patrick Gray, and the
federal indictments of W. Mark Felt or "Deep Throat" and Edwin Miller
and which, earlier, was the factor leading to the removal of federal
"most-wanted" status against members of the Weather Underground
leadership in 1973.

Prairie Fire
============

-   *However, the decision to build only an underground group caused the
    Weather Underground to lose sight of its commitment to mass struggle
    and made future alliances with the mass movement difficult and
    tenuous.*

-   *The remaining Weather Underground members continued to attack U.S.
    institutions.*

-   *Hundreds of above-ground activists helped further the new political
    vision of the Weather Underground.*

With the help from Clayton Van Lydegraf, the Weather Underground sought
a more Marxist–Leninist ideological approach to the post-Vietnam
reality. The leading members of the Weather Underground (Bill Ayers,
Bernardine Dohrn, Jeff Jones, and Celia Sojourn) collaborated on ideas
and published a manifesto: Prairie Fire: The Politics of Revolutionary
Anti-Imperialism. The name came from a quote by Mao Zedong, "a single
spark can set a prairie fire." By the summer of 1974, 5,000 copies had
surfaced in coffee houses, bookstores and public libraries across the
U.S. Leftist newspapers praised the manifesto.

Abbie Hoffman publicly praised Prairie Fire and believed every American
should be given a copy. The manifesto's influence initiated the
formation of the Prairie Fire Organizing Committee in several American
cities. Hundreds of above-ground activists helped further the new
political vision of the Weather Underground. Essentially, after the 1969
failure of the Days of Rage to involve thousands of youth in massive
street fighting, Weather renounced most of the Left and decided to
operate as an isolated underground group. Prairie Fire urged people to
never "dissociate mass struggle from revolutionary violence". To do so,
asserted Weather, was to do the state's work. Just as in 1969–1970,
Weather still refused to renounce revolutionary violence for "to leave
people unprepared to fight the state is to seriously mislead them about
the inevitable nature of what lies ahead". However, the decision to
build only an underground group caused the Weather Underground to lose
sight of its commitment to mass struggle and made future alliances with
the mass movement difficult and tenuous.:76–77

By 1974, Weather had recognized this shortcoming and in Prairie Fire
detailed a different strategy for the 1970s which demanded both mass and
clandestine organizations. The role of the clandestine organization
would be to build the "consciousness of action" and prepare the way for
the development of a people's militia. Concurrently, the role of the
mass movement (i.e., above ground Prairie Fire collective) would include
support for, and encouragement of, armed action. Such an alliance would,
according to Weather, "help create the 'sea' for the guerrillas to swim
in".:76–77

According to Bill Ayers in the late 1970s, the Weatherman group further
split into two factions — the May 19th Communist Organization and the
Prairie Fire Collective — with Bernardine Dohrn and Bill Ayers in the
latter. The Prairie Fire Collective favored coming out of hiding and
establishing an above-ground revolutionary mass movement. With most WUO
members facing the limited criminal charges (most charges had been
dropped by the government in 1973) against them creating an above ground
organization was more feasible. The May 19 Communist Organization
continued in hiding as the clandestine organization. A decisive factor
in Dohrn's coming out of hiding were her concerns about her children.
The Prairie Fire Collective faction started to surrender to the
authorities from the late 1970s to the early 1980s. The remaining
Weather Underground members continued to attack U.S. institutions.

COINTELPRO
==========

Event
=====

-   *After COINTELPRO was dissolved in 1971 by J. Edgar Hoover, the FBI
    continued its counterintelligence on groups like the Weather
    Underground.*

-   *The Weather Underground was no longer a fugitive organization and
    could turn themselves in with minimal charges against them.*

-   *In 1973, the FBI established the "Special Target Information
    Development" program, where agents were sent undercover to penetrate
    the Weather Underground.*

In April 1971, the "Citizens' Commission to Investigate the FBI" broke
into an FBI office in Media, Pennsylvania. The group stole files with
several hundred pages. The files detailed the targeting of civil rights
leaders, labor rights organizations, and left wing groups in general,
and included documentation of acts of intimidation and disinformation by
the FBI, and attempts to erode public support for those popular
movements. By the end of April, the FBI offices were to terminate all
files dealing with leftist groups. The files were a part of an FBI
program called COINTELPRO.

After COINTELPRO was dissolved in 1971 by J. Edgar Hoover, the FBI
continued its counterintelligence on groups like the Weather
Underground. In 1973, the FBI established the "Special Target
Information Development" program, where agents were sent undercover to
penetrate the Weather Underground. Due to the illegal tactics of FBI
agents involved with the program, government attorneys requested all
weapons- and bomb-related charges be dropped against the Weather
Underground. The most well-publicized of these tactics were the
"black-bag jobs," referring to searches conducted in the homes of
relatives and acquaintances of Weatherman. The Weather Underground was
no longer a fugitive organization and could turn themselves in with
minimal charges against them. Additionally, the illegal domestic spying
conducted by the CIA in collaboration with the FBI also lessened the
legal repercussions for Weatherman turning themselves in.

Investigation and trial
=======================

-   *The Attorney General in the new Carter administration, Griffin B.*

-   *The indictment charged Felt and the others "did unlawfully,
    willfully, and knowingly combine, conspire, confederate, and agree
    together and with each other to injure and oppress citizens of the
    United States who were relatives and acquaintances of the Weatherman
    fugitives, in the free exercise and enjoyments of certain rights and
    privileges secured to them by the Constitution and the laws of the
    United States of America.*

-   *Writing in The New York Times a week after the conviction, Roy Cohn
    claimed that Felt and Miller were being used as scapegoats by the
    Carter administration and that it was an unfair prosecution.*

After the Church Committee revealed the FBI's illegal activities, many
agents were investigated. In 1976, former FBI Associate Director W. Mark
Felt publicly stated he had ordered break-ins and that individual agents
were merely obeying orders and should not be punished for it. Felt also
stated that acting Director L. Patrick Gray had also authorized the
break-ins, but Gray denied this. Felt said on the CBS television program
Face the Nation that he would probably be a "scapegoat" for the Bureau's
work. "I think this is justified and I'd do it again tomorrow," he said
on the program. While admitting the break-ins were "extralegal," he
justified it as protecting the "greater good." Felt said, "To not take
action against these people and know of a bombing in advance would
simply be to stick your fingers in your ears and protect your eardrums
when the explosion went off and then start the investigation."

The Attorney General in the new Carter administration, Griffin B. Bell,
investigated, and on April 10, 1978, a federal grand jury charged Felt,
Edward S. Miller, and Gray with conspiracy to violate the constitutional
rights of American citizens by searching their homes without warrants.
The case did not go to trial and was dropped by the government for lack
of evidence on December 11, 1980.

The indictment charged violations of Title 18, Section 241 of the United
States Code. The indictment charged Felt and the others "did unlawfully,
willfully, and knowingly combine, conspire, confederate, and agree
together and with each other to injure and oppress citizens of the
United States who were relatives and acquaintances of the Weatherman
fugitives, in the free exercise and enjoyments of certain rights and
privileges secured to them by the Constitution and the laws of the
United States of America.?

Felt and Miller attempted to plea bargain with the government, willing
to agree to a misdemeanor guilty plea to conducting searches without
warrants—a violation of 18 U.S.C. sec. 2236—but the government rejected
the offer in 1979. After eight postponements, the case against Felt and
Miller went to trial in the United States District Court for the
District of Columbia on September 18, 1980. On October 29, former
President Richard Nixon appeared as a rebuttal witness for the defense,
and testified that presidents since Franklin D. Roosevelt had authorized
the bureau to engage in break-ins while conducting foreign intelligence
and counterespionage investigations.

It was Nixon's first courtroom appearance since his resignation in 1974.
Nixon also contributed money to Felt's legal defense fund, with Felt's
legal expenses running over \$600,000. Also testifying were former
Attorneys General Herbert Brownell Jr., Nicholas Katzenbach, Ramsey
Clark, John N. Mitchell, and Richard G. Kleindienst, all of whom said
warrantless searches in national security matters were commonplace and
not understood to be illegal, but Mitchell and Kleindienst denied they
had authorized any of the break-ins at issue in the trial.

The jury returned guilty verdicts on November 6, 1980. Although the
charge carried a maximum sentence of 10 years in prison, Felt was fined
\$5,000. (Miller was fined \$3,500). Writing in The New York Times a
week after the conviction, Roy Cohn claimed that Felt and Miller were
being used as scapegoats by the Carter administration and that it was an
unfair prosecution. Cohn wrote it was the "final dirty trick" and that
there had been no "personal motive" to their actions.

The Times saluted the convictions, saying that it showed "the case has
established that zeal is no excuse for violating the Constitution". Felt
and Miller appealed the verdict, and they were later pardoned by Ronald
Reagan.

Dissolution
===========

-   *The conference increased divisions within the Weather Underground.*

-   *The Weather Underground held a conference in Chicago called Hard
    Times.*

-   *The Weather Underground faced accusations of abandonment of the
    revolution by reversing their original ideology.*

-   *Despite the change in their legal status, the Weather Underground
    remained underground for a few more years.*

Despite the change in their legal status, the Weather Underground
remained underground for a few more years. However, by 1976 the
organization was disintegrating. The Weather Underground held a
conference in Chicago called Hard Times. The idea was to create an
umbrella organization for all radical groups. However, the event turned
sour when Hispanic and Black groups accused the Weather Underground and
the Prairie Fire Committee of limiting their roles in racial issues. The
Weather Underground faced accusations of abandonment of the revolution
by reversing their original ideology.

The conference increased divisions within the Weather Underground. East
coast members favored a commitment to violence and challenged
commitments of old leaders, Bernardine Dohrn, Bill Ayers, and Jeff
Jones. These older members found they were no longer liable for federal
prosecution because of illegal wire taps and the government's
unwillingness to reveal sources and methods favored a strategy of
inversion where they would be above ground "revolutionary leaders".
Jeremy Varon argues that by 1977 the WUO had disbanded.

Matthew Steen appeared on the lead segment of CBS' 60 Minutes in 1976
and was interviewed by Mike Wallace about the ease of creating fake
identification, the first ex-Weatherman interview on national
television. (The House document has the date wrong, it aired February 1,
1976 and the title was Fake ID.)

The federal government estimated that only 38 Weathermen had gone
underground in 1970, though the estimates varied widely, according to a
variety of official and unofficial sources, as between 50 and 600
members. Most modern sources lean towards a much larger number than the
FBI reference. An FBI estimate in 1976, or slightly later, of then
current membership was down to 30 or fewer.

Plot to bomb office of California Senator
=========================================

-   *FBI agents Richard J. Gianotti and William D. Reagan lost their
    cover in November when federal judges needed their testimony to
    issue warrants for the arrest of Clayton Van Lydegraf and four
    Weather people.*

-   *Bernardine Dohrn and Bill Ayers turned themselves in on December 3,
    1980, in New York, with substantial media coverage.*

In November 1977, five WUO members were arrested on conspiracy to bomb
the office of California State Senator John Briggs. It was later
revealed that the Revolutionary Committee and PFOC had been infiltrated
by the FBI for almost six years. FBI agents Richard J. Gianotti and
William D. Reagan lost their cover in November when federal judges
needed their testimony to issue warrants for the arrest of Clayton Van
Lydegraf and four Weather people. The arrests were the results of the
infiltration.\
WUO members Judith Bissell, Thomas Justesen, Leslie Mullin, and Marc
Curtis pleaded guilty while Clayton Van Lydegraf, who helped write the
1974 Prairie Fire Manifesto, went to trial.

Within two years, many members turned themselves in after taking
advantage of President Jimmy Carter's amnesty for draft dodgers. Mark
Rudd turned himself in to authorities on January 20, 1978. Rudd was
fined \$4,000 and received two years probation. Bernardine Dohrn and
Bill Ayers turned themselves in on December 3, 1980, in New York, with
substantial media coverage. Charges were dropped for Ayers. Dohrn
received three years probation and a \$15,000 fine.

Brinks robbery
==============

-   *The documentary The Weather Underground described the Brinks
    Robbery as the "unofficial end" of the Weather Underground.*

-   *Media reports listed them as former Weatherman Underground members
    considered the "last gasps" of the Weather Underground.*

-   *Some members remained underground and joined splinter radical
    groups.*

Some members remained underground and joined splinter radical groups.
The US government states that years after the dissolution of the Weather
Underground, three former members, Kathy Boudin, Judith Alice Clark, and
David Gilbert, joined the May 19 Communist Organization, and on October
20, 1981 in Nanuet, New York, the group helped the Black Liberation Army
rob a Brinks armored truck containing \$1.6 million. The robbery was
violent, resulting in the deaths of three people including Waverly
Brown, the first black police officer on the Nyack police force.

Boudin, Clark, and Gilbert were found guilty and sentenced to lengthy
terms in prison. Media reports listed them as former Weatherman
Underground members considered the "last gasps" of the Weather
Underground. The documentary The Weather Underground described the
Brinks Robbery as the "unofficial end" of the Weather Underground.

May 19th Communist Organization
===============================

-   *The Weather Underground members involved in the May 19th Communist
    Organization alliance with the Black Liberation Army continued in a
    series of jail breaks, armed robberies and bombings until most
    members were finally arrested in 1985 and sentenced as part of the
    Brinks robbery and the Resistance Conspiracy case.*

The Weather Underground members involved in the May 19th Communist
Organization alliance with the Black Liberation Army continued in a
series of jail breaks, armed robberies and bombings until most members
were finally arrested in 1985 and sentenced as part of the Brinks
robbery and the Resistance Conspiracy case.

Coalitions with non-WUO members
===============================

-   *Throughout the underground years, the Weather Underground members
    worked closely with their counterparts in other organizations,
    including Jane Alpert, to bring attention their further actions to
    the press.*

-   *Weather members then wrote in response to her manifesto.*

Throughout the underground years, the Weather Underground members worked
closely with their counterparts in other organizations, including Jane
Alpert, to bring attention their further actions to the press. She
helped Weatherman pursue their main goal of overthrowing the U.S.
government through her writings. However, there were tensions within the
organization, brought about by her famous manifesto, "Mother Right",
that specifically called on the female members of the organization to
focus on their own cause rather than anti-imperialist causes. Weather
members then wrote in response to her manifesto.

Legacy
======

-   *The Weather Underground would claim responsibility for a total of
    about two dozen bombings.*

-   *A faction of the Weather Underground continues today as the Prairie
    Fire Organizing Committee.*

-   *The Weather Underground was referred to in its own time and
    afterwards as a terrorist group by articles in The New York Times,
    United Press International, and Time.*

Widely known members of the Weather Underground include Kathy Boudin,
Linda Sue Evans, Brian Flanagan, David Gilbert, Ted Gold, Naomi Jaffe,
Jeff Jones, Joe Kelly, Diana Oughton, Eleanor Raskin, Terry Robbins,
Mark Rudd, Matthew Steen, Susan Stern, Laura Whitehorn, Cathy Wilkerson,
and the still-married couple Bernardine Dohrn and Bill Ayers. Most
former Weathermen have successfully re-integrated into mainstream
society, without necessarily repudiating their original intent.

The Weather Underground was referred to in its own time and afterwards
as a terrorist group by articles in The New York Times, United Press
International, and Time. The group also fell under the auspices of the
FBI-New York City Police Anti Terrorist Task Force, a forerunner of the
FBI's Joint Terrorism Task Forces. The FBI, in a 2004 news story titled
"Byte out of History" published on its website, refers to the
organization as having been a "domestic terrorist group" that is no
longer an active concern. Others have disputed the "terrorist"
categorization, and justify the group's actions as an appropriate
response to what it described as the "terrorist activities" of the war
against Vietnam, domestic racism and the assassinations of black
leaders.

In his 2001 book about his Weatherman experiences, Bill Ayers stated his
objection to describing the WUO as terrorist. Ayers wrote: "Terrorists
terrorize, they kill innocent civilians, while we organized and
agitated. Terrorists destroy randomly, while our actions bore, we hoped,
the precise stamp of a cut diamond. Terrorists intimidate, while we
aimed only to educate. No, we're not terrorists." Dan Berger, in his
book about the Weatherman, Outlaws in America, asserts that the group
"purposefully and successfully avoided injuring anyone ... Its war
against property by definition means that the WUO was not a terrorist
organization."

The late 1960s and early 1970s were tumultuous times, with the FBI
attributing 1500 bombings in just 1972 to "civil unrest" by radical
groups. The Weather Underground would claim responsibility for a total
of about two dozen bombings. The observation that Weather Underground
never attacked or harmed people, and only targeted property, is
criticized by some who point to the bombs which caused the Greenwich
Village townhouse explosion, which could have been used to harm people
if they hadn't exploded prematurely. Former Weather Underground member
Mark Rudd, reminiscing in 2005 about that explosion, said:

Prompted in part by claims made by informants working for the FBI within
the Weather Underground, grand juries were convened in 2001 and 2009 to
investigate if Weather Underground was responsible for the San Francisco
Police Department Park Station bombing, in which one officer was fatally
wounded, one maimed and eight more wounded by shrapnel from a pipe bomb.
Ultimately, it was concluded that members of the Black Liberation Army,
whom WUO members affiliated with while underground, were responsible for
not only this action, but also the bombing of another police precinct in
San Francisco, as well as bombing the Catholic Church funeral services
of the police officer killed in the Park Precinct bombing in the early
summer of 1970.

In 2001 Bill Ayers was quoted in a New York Times interview saying "I
don't regret setting bombs", but has since claimed he was misquoted.
During the presidential election campaign of 2008, several candidates
questioned Barack Obama's contacts with Ayers, including Hillary
Clinton, John McCain and Sarah Palin. Ayers responded in December 2008,
after Obama's election victory, in an op-ed piece in The New York Times:

Mark Rudd, now a teacher of mathematics at Central New Mexico Community
College, has said he doesn't speak publicly about his experiences
because he has "mixed feelings, guilt and shame ...".

A faction of the Weather Underground continues today as the Prairie Fire
Organizing Committee. Their official site reads:

The site further supports non-violent civil disobedience and direct
action:

See also
========

-   *Weather Underground, a corporate weather service, subsidiary of The
    Weather Company, and unrelated to the militant student organization;
    the name dates from the service's founding as an offshoot of the
    weather database of the University of Michigan, where the original
    Weather Underground was also founded.*

List of Weather Collectives

List of Weatherman actions

List of Weatherman members

May 19th Communist Organization

Osawatomie (periodical)

Resistance Conspiracy case

Underground (1976 film), documentary

The Weather Underground (2002 film), nominated for 2003 Academy Award
for Best Documentary Feature

Antifa (United States)

General:

Domestic terrorism in the United States

List of incidents of political violence in Washington, D.C.

Weather Underground, a corporate weather service, subsidiary of The
Weather Company, and unrelated to the militant student organization; the
name dates from the service's founding as an offshoot of the weather
database of the University of Michigan, where the original Weather
Underground was also founded.

References
==========

Further reading
===============

-   *Outlaws of America: The Weather Underground and the Politics of
    Solidarity.*

-   *Sing a Battle Song: The Revolutionary Poetry, Statements, and
    Communiqués of the Weather Underground, 1970–1974.*

-   *Bringing the War Home: The Weather Underground, the Red Army
    Faction, and Revolutionary Violence in the Sixties and Seventies.*

-   *The Way the Wind Blew: A History of the Weather Underground.*

Alpert, Jane (1981). Growing up underground (1st ed.). New York: Morrow.
ISBN 0688006558.

Ayers, Bill (2008). Fugitive Days: Memoirs of an Antiwar Activist.
Boston: Beacon Press. ISBN 0-8070-3277-8.

Berger, Dan (2006). Outlaws of America: The Weather Underground and the
Politics of Solidarity. Oakland: AK Press. ISBN 1-904859-41-0.

Burrough, Bryan, Days of Rage: America's Radical Underground, the FBI,
and the Forgotten Age of Revolutionary Violence. New York: Penguin
Books, 2015.

Dohrn, Bernardine; Ayers, Bill; Jones, Jeff. Sing a Battle Song: The
Revolutionary Poetry, Statements, and Communiqués of the Weather
Underground, 1970–1974. New York: Seven Stories Press.
ISBN 1-58322-726-1.CS1 maint: Multiple names: authors list (link)

Eckstein, Arthur M. Bad Moon Rising: How the Weather Underground Beat
the FBI and Lost the Revolution. New Haven, CT: Yale University Press,
2016.

Jacobs, Harold (1971). Weatherman. San Francisco: Ramparts Press.
ISBN 978-0-87867-001-7.

Jacobs, Ron (1997). The Way the Wind Blew: A History of the Weather
Underground. London: Verso. ISBN 1-85984-167-8.

Kirkpatrick, Rob (2009). 1969: The Year Everything Changed. New York:
Skyhorse Publishing. ISBN 1-60239-366-4.

Lerner, Jonathan. Swords in the Hands of Children: Reflections of an
American Revolutionary. OR Books. p. 228. ISBN 978-1-682190-98-2.

Sale, Kirkpatrick (1974). SDS. New York: Vintage Books.
ISBN 0-394-71965-4.

Unger, Irwin (1974). The Movement: A History of the American New Left,
1959–1972. New York: Dodd, Mead. ISBN 0-396-06939-8.

Varon, Jeremy (2004). Bringing the War Home: The Weather Underground,
the Red Army Faction, and Revolutionary Violence in the Sixties and
Seventies. Berkeley and Los Angeles: University of California Press.
ISBN 0-520-24119-3.

Wilkerson, Cathy (2007). Flying Close to the Sun: My Life and Times as a
Weatherman. New York: Seven Stories Press. ISBN 1-58322-771-7.

Government publications
=======================

-   *The Weather Underground.*

United States. Congress. Senate. Committee on the Judiciary.
Subcommittee to Investigate the Administration of the Internal Security
Act and Other Internal Security Laws (1974). Terroristic Activity:
Hearings before the Subcommittee to Investigate the Administration of
the Internal Security Act and other Internal Security Laws, of the
Committee on the Judiciary, United States Senate, Ninety-third Congress,
Second Session. Part 2, Inside the Weatherman Movement. Washington,
D.C.: U.S. Government Printing Office.

United States. Congress. Senate. Committee on the Judiciary.
Subcommittee to Investigate the Administration of the Internal Security
Act and Other Internal Security Laws of the Committee on the Judiciary,
United States Senate, Ninety-fourth Congress, First Session (1975). The
Weather Underground. Washington, D.C.: U.S. Government Printing Office.

External links
==============

-   *"Weatherman (Weather Underground Organization, WUO), 1969-77".*

-   *"FBI files: Weather Underground Organization (Weathermen)".*

"FBI files: Weather Underground Organization (Weathermen)".

"WUO communiqués and other documents". SDS-60s.Org. Retrieved January
18, 2011.

Full text of "Harold Jacob's Weatherman (PDF format)" (PDF).
SDS-60s.Org. Retrieved January 18, 2011.

Machtinger, Howard (February 18, 2009). "You Say You Want a Revolution".
In These Times. Retrieved January 18, 2011.

Rudd, Mark (2008). "The Death of SDS". MarkRudd.com. Retrieved January
18, 2011.

"Prairie Fire". Prairie Fire Organizing Committee (1975–present).
Retrieved January 19, 2011.

"Weatherman (Weather Underground Organization, WUO), 1969-77". Archived
from the original on July 26, 2010. Retrieved January 18, 2011. History,
critics, books online

Film and video
==============

-   *Underground (1976).*

-   *"The Weather Underground".*

"The Weather Underground". Documentary directed and produced by Sam
Green, Bill Siegel and Carrie Lozano.

Underground (1976). Documentary directed by Emile de Antonio, Haskell
Wexler and Mary Lampson.

The Company You Keep (2012). Fiction directed by Robert Redford.

Fiction
=======

-   *Willimantic, CT : New York, NY: Curbstone Press ; Distributed to
    the trade by the Talman Co. ISBN 0915306824.*

-   *New York: Viking.*

-   *ISBN 0670032182.*

Bushell, Agnes (1990). Local deities: a novel. Willimantic, CT : New
York, NY: Curbstone Press ; Distributed to the trade by the Talman Co.
ISBN 0915306824.

Gordon, Neil (2003). The company you keep. New York: Viking.
ISBN 0670032182.

Audio sources
=============

-   *Guests: Mark Rudd, former member of the Weather Underground, Sam
    Green and Bill Siegel, documentary filmmakers/directors.*

-   *Growing Up in the Weather Underground: A Father and Son Tell Their
    Story.*

-   *The Weather Underground: A Look Back at the Antiwar Activists Who
    Met Violence with Violence.*

"Vietnam: Index of /MRC/pacificaviet". University of California,
Berkeley. Retrieved January 18, 2011. Contains online audiorecordings,
texts, and other media related to the WUO

The Weather Underground: A Look Back at the Antiwar Activists Who Met
Violence with Violence. Guests: Mark Rudd, former member of the Weather
Underground, Sam Green and Bill Siegel, documentary
filmmakers/directors. Interviewers: Juan Gonzalez and Amy Goodman.
Democracy Now!. Segment available via streaming RealAudio, or MP3
download. 1 hour 40 minutes. Thursday, June 5, 2003. Retrieved May 20,
2005.

Jennifer Dohrn: I Was The Target Of Illegal FBI Break-Ins Ordered by
Mark Felt a.k.a. "Deep Throat". Guest: Jennifer Dohrn. Interviewers:
Juan Gonzalez and Amy Goodman. Segment available in transcript and via
streaming RealAudio, 128k streaming real video or MP3 download. 29:32
minutes. Thursday, June 2, 2005. Retrieved June 2, 2005.

Growing Up in the Weather Underground: A Father and Son Tell Their
Story. Guests: Thai Jones and Jeff Jones. Interviewers: Juan Gonzalez
and Amy Goodman. Democracy Now!. Segment available in transcript and via
streaming RealAudio, 128k streaming Real Video or MP3 download. 17:01
minutes. Friday, December 3, 2004. Retrieved May 20, 2005.
