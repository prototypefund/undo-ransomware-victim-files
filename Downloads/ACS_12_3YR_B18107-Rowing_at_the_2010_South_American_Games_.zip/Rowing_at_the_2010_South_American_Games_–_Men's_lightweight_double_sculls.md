**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Rowing\_at\_the\_2010\_South\_American\_Games\_%E2%80%93\_Men%27s\_lightweight\_double\_sculls\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Rowing at the 2010 South American Games – Men's lightweight double sculls
=========================================================================

-   *The Men's lightweight double sculls event at the 2010 South
    American Games was held over March 19–20.*

-   *The qualification round and the repechage were held on the first
    day, beginning at 9:30 and the final was held on the following day
    at 9:20.*

The Men's lightweight double sculls event at the 2010 South American
Games was held over March 19–20. The qualification round and the
repechage were held on the first day, beginning at 9:30 and the final
was held on the following day at 9:20.

Medalists
=========

Records
=======

Results
=======

Heats
=====

Heat 1
======

Heat 2
======

Repechage
=========

Final
=====

References
==========

-   *Heat 1*

-   *Heat 2*

Heat 1

Heat 2

Repechage

Final
