**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/2020%20Democratic%20Party%20presidential%20candidates\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

2020 Democratic Party presidential primaries
============================================

-   *The 2020 Democratic Party presidential primaries and caucuses will
    be a series of electoral contests organized by the Democratic Party
    to select the approximately 3,768 pledged delegates to the
    Democratic National Convention, who by pledged votes shall elect the
    Democratic nominee for President of the United States in the 2020
    U.S. presidential election.*

The 2020 Democratic Party presidential primaries and caucuses will be a
series of electoral contests organized by the Democratic Party to select
the approximately 3,768 pledged delegates to the Democratic National
Convention, who by pledged votes shall elect the Democratic nominee for
President of the United States in the 2020 U.S. presidential election.
The elections are scheduled to take place from February to June 2020,
within all fifty U.S. states, the District of Columbia, five U.S.
territories, and Democrats Abroad.

Independently of the result of primaries and caucuses, the Democratic
party will, from its group of party leaders and elected officials, also
appoint 764 unpledged delegates (superdelegates) to participate in its
National Convention. In contrast to all previous election cycles,
superdelegates will no longer have the right to cast decisive votes at
the convention's first ballot for the presidential nomination (limiting
their voting rights to either non-decisive votes on the first ballot or
decisive votes for subsequent ballots on a contested convention).

26 major candidates have entered the race for the 2020 Democratic Party
presidential nomination, of which one candidate (Richard Ojeda) opted to
withdraw. This is the largest field of presidential candidates for any
political party in the post-reform era of American history, exceeding
the field of 17 major candidates that sought the Republican presidential
nomination in 2016.

Background
==========

-   *Several candidates began releasing serious policy proposals early
    in 2019 resulting in the "invisible primary" being more visible than
    in previous elections.*

After Hillary Clinton's loss in the previous election, many felt the
Democratic Party lacked a clear leader. There remained divisions in the
party following the 2016 primaries which pitted Clinton against Bernie
Sanders. Between the 2016 election and the 2018 midterm elections,
Senate Democrats have generally shifted to the political left in
relation to college tuition, healthcare, and immigration.

Soon after the 2016 general election, the division between Clinton and
Sanders supporters was highlighted in the 2017 Democratic National
Committee chairmanship election between Tom Perez and Keith Ellison.
Perez was narrowly elected Chairman and subsequently appointed Ellison
as the Deputy Chair, a largely ceremonial role. Several candidates began
releasing serious policy proposals early in 2019 resulting in the
"invisible primary" being more visible than in previous
elections.\[citation needed\] The number of viable candidates running
for the presidency is the largest in history.

Reforms since 2016
==================

-   *On August 25, 2018, the Democratic National Committee (DNC) members
    passed reforms to the Democratic Party's primary process in order to
    increase participation and ensure transparency.*

-   *The new reforms also regulate how the Democratic National
    Convention shall handle the outcome of primaries and caucuses for
    three potential scenarios:*

On August 25, 2018, the Democratic National Committee (DNC) members
passed reforms to the Democratic Party's primary process in order to
increase participation and ensure transparency. State parties are
encouraged to use a government-run primary whenever available and
increase the accessibility of their primary through same-day or
automatic registration and same-day party switching. Caucuses are
required to have absentee voting, or to otherwise allow those who cannot
participate in person to be included.

The new reforms also regulate how the Democratic National Convention
shall handle the outcome of primaries and caucuses for three potential
scenarios:

If a single candidate wins at least 2,267 pledged delegates:
Superdelegates will be allowed to vote at first ballot, as their
influence can not overturn the majority of pledged delegates.

If a single candidate wins 1,885-2,266 pledged delegates: Superdelegates
will be barred from voting at first ballot, which solely will be decided
by the will of pledged delegates.

If no candidate will win more than 1,884 pledged delegates: This will
result in a contested convention, where superdelegates are barred from
voting at the first formal ballot, but regain their right to vote for
their preferred presidential nominee for all subsequent ballots needed
until the delegates reach a majority.

The reforms mandate that superdelegates refrain from voting on the first
presidential nominating ballot, unless a candidate via the outcome of
primaries and caucuses already has gained enough votes (more than 50% of
all delegate votes) among only the elected pledged delegates. The
prohibition for superdelegates to vote at the first ballot for the last
two mentioned scenarios, does not preclude superdelegates from publicly
endorsing a candidate of their choosing before the convention.

In a contested convention where no majority of minimum 1,885 pledged
delegate votes is found for a single candidate in the first ballot, all
superdelegates will then regain their right to vote on any subsequent
ballot necessary in order for a presidential candidate to be nominated
(raising the majority needed for such to 2,267 votes).

Candidates
==========

Declared candidates
===================

-   *In addition to having filed with the Federal Election Commission to
    run for president in the Democratic Party primary in 2020 and having
    confirmed this by an official campaign announcement (while still
    campaigning actively as of today), the 25 major candidates have
    either: (a) held public office; (b) been included in a minimum of
    five independent national polls; or (c) received substantial media
    coverage.*

In addition to having filed with the Federal Election Commission to run
for president in the Democratic Party primary in 2020 and having
confirmed this by an official campaign announcement (while still
campaigning actively as of today), the 25 major candidates have either:
(a) held public office; (b) been included in a minimum of five
independent national polls; or (c) received substantial media coverage.

Beside the 25 major candidates, more than 240 other candidates who did
not meet the criteria above to be deemed major, also filed with the
Federal Election Commission to run for president in the Democratic Party
primary. Among the other candidates, the notable ones who are still
active include:

Michael E. Arth, artist, builder, architectural and urban designer, and
political scientist.

Harry Braun, renewable energy consultant and researcher

Ben Gleib, actor, comedian, satirist, and writer

Ami Horowitz, documentary filmmaker and right-wing activist.

Ken Nwadike Jr., documentary filmmaker, motivational speaker, and peace
activist.

Robby Wells, former college football coach.

Withdrawn candidates
====================

-   *The candidates in this section have withdrawn or suspended their
    campaigns.*

The candidates in this section have withdrawn or suspended their
campaigns.

Individuals who have publicly expressed interest
================================================

-   *\
    Individuals in this section have expressed an interest in running
    for president within the last six months, as of June 2019.*

Individuals in this section have expressed an interest in running for
president within the last six months, as of June 2019.

Stacey Abrams, Georgia State Representative 2007–2017; Democratic
nominee for Governor of Georgia in 2018 (decision expected by
September)\[90\]

Former State RepresentativeStacey Abramsfrom Georgia

Declined to be candidates
=========================

-   *These individuals have been the subject of speculation, but have
    publicly denied or recanted interest in running for president.*

These individuals have been the subject of speculation, but have
publicly denied or recanted interest in running for president.

Debates
=======

Timeline
========

Background
==========

-   *In December 2018, the Democratic National Committee (DNC) announced
    the preliminary schedule for 12 official DNC-sanctioned debates, set
    to begin in June 2019, with six debates in 2019 and the remaining
    six during the first four months of 2020.*

In the weeks following the election of Donald Trump in the 2016
election, media speculation regarding potential candidates for the 2020
Democratic Party presidential primaries began to circulate. Speculation
centered on the prospects of the "hell-no caucus", six senators who went
on to vote against the majority of Trump's nominees. According to
Politico, the members of the "hell-no caucus" were Cory Booker, Kamala
Harris, Kirsten Gillibrand, Bernie Sanders, Jeff Merkley and Elizabeth
Warren. Other speculation centred on then-Vice-President Joe Biden,
making a third presidential bid following failed attempts in 1988 and
2008. Biden had previously served as U.S. Senator from Delaware
(1973-2009).

On July 28, 2017, U.S. Representative John Delaney became the first
major Democrat to announce their candidacy in an op-ed in The Washington
Post. On November 6, 2017, tech entrepreneur Andrew Yang became the
second major Democrat to announce their candidacy. In August 2018,
Democratic Party officials and television networks begin discussions as
to the nature and scheduling of the following year's debates and the
nomination process. In December 2018, the Democratic National Committee
(DNC) announced the preliminary schedule for 12 official DNC-sanctioned
debates, set to begin in June 2019, with six debates in 2019 and the
remaining six during the first four months of 2020. Following these
announcements, there was a general consensus that debates would have a
greater, influential role in the primaries.

Overview
========

2017
====

-   *November 6: Tech entrepreneur Andrew Yang of New York announces his
    candidacy.*

July 28: Representative John Delaney of Maryland announces his candidacy
in an op-ed in The Washington Post.

November 6: Tech entrepreneur Andrew Yang of New York announces his
candidacy.

2018
====

-   *August 25: Democratic Party officials and television networks begin
    discussions as to the nature and scheduling of the following year's
    debates and the nomination process.*

-   *November 6: The 2018 midterm elections are held.*

-   *November 19: Ojeda holds a campaign launch rally in Louisville,
    Kentucky.*

August

August 25: Democratic Party officials and television networks begin
discussions as to the nature and scheduling of the following year's
debates and the nomination process. Changes were made to the role of
superdelegates, deciding to only allow them to vote on the first ballot
if the nomination is uncontested.

November

November 6: The 2018 midterm elections are held.

November 11: State Senator Richard Ojeda of West Virginia announces his
candidacy.

November 15: Spiritual teacher and author Marianne Williamson of
California forms an exploratory committee.

November 19: Ojeda holds a campaign launch rally in Louisville,
Kentucky.

December

December 12: Former Secretary of Housing and Urban Development Julian
Castro of Texas forms an exploratory committee.

December 31: Senator Elizabeth Warren of Massachusetts forms an
exploratory committee.

2019
====

-   *February*

-   *March*

-   *January*

-   *April 13: Booker holds a campaign launch rally in Newark, New
    Jersey.*

-   *March 11: DNC announces Milwaukee, Wisconsin as the site of the
    2020 Democratic National Convention.*

-   *April*

-   *March 2: Sanders holds a campaign launch rally at Brooklyn College
    in Brooklyn, New York.*

January

January 11: Representative Tulsi Gabbard of Hawaii announces her
candidacy during an interview on The Van Jones Show.

January 12: Castro announces his candidacy at a rally in San Antonio,
Texas.

January 15: Senator Kirsten Gillibrand of New York forms an exploratory
committee during an interview on The Late Show with Stephen Colbert.

January 21: Senator Kamala Harris of California announces her candidacy
during an interview on Good Morning America.

January 23: Mayor Pete Buttigieg of South Bend, Indiana forms an
exploratory committee.

January 25: Ojeda drops out of the race.

January 27: Harris holds a campaign launch rally in Oakland, California.

January 28: Williamson announces her candidacy at a rally in Los
Angeles, California.

February

February 1: Senator Cory Booker of New Jersey announces his candidacy.

February 2: Gabbard holds a campaign launch rally in Honolulu, Hawaii.

February 9: Warren announces her candidacy at a rally in Lawrence,
Massachusetts.

February 10: Senator Amy Klobuchar of Minnesota announces her candidacy
at a rally in Minneapolis, Minnesota.

February 19: Senator Bernie Sanders of Vermont announces his candidacy
via an email to supporters and appears on Vermont Public Radio as well
as CBS This Morning as part of his campaign launch.

March

March 1: Governor Jay Inslee of Washington announces his candidacy.

March 2: Sanders holds a campaign launch rally at Brooklyn College in
Brooklyn, New York.

March 4: Former Governor John Hickenlooper of Colorado announces his
candidacy.

March 7: Hickenlooper holds a campaign launch rally in Denver, Colorado.

March 11: DNC announces Milwaukee, Wisconsin as the site of the 2020
Democratic National Convention.

March 13: Mayor Wayne Messam of Miramar, Florida forms an exploratory
committee.

March 14: Former Representative Beto O'Rourke of Texas announces his
candidacy.

March 17: Gillibrand formally announces her candidacy via a video on
Twitter.

March 19: An exploratory committee is formed on behalf of former Senator
Mike Gravel of Alaska.

March 24: Gillibrand holds a campaign launch rally outside of Trump
Tower in New York City.

March 28: Messam formally announces his candidacy in an online video.

March 30: O'Rourke holds a campaign launch rally on the Mexico–United
States border in El Paso, Texas.

April

April 4: Representative Tim Ryan of Ohio announces his candidacy and
appears on The View as part of a campaign launch.

April 8:\
Gravel formally announces his candidacy in an online video.\[203\]\
Representative Eric Swalwell of California announces his candidacy
during an interview on The Late Show with Stephen Colbert.\[64\]

April 13: Booker holds a campaign launch rally in Newark, New Jersey.

April 14:\
Buttigieg announces his candidacy at a rally in South Bend,
Indiana.\[31\]\
Swalwell holds a campaign launch rally at Dublin High School in Dublin,
California.\[205\]

April 22: Representative Seth Moulton of Massachusetts announces his
candidacy in an online video.

April 25: Former Vice President Joe Biden of Delaware announces his
candidacy via a video published on social media.

April 29: Biden holds a campaign launch rally at a union hall in
Pittsburgh, Pennsylvania

May

May 2: Senator Michael Bennet of Colorado announces his candidacy on CBS
This Morning.

May 14: Governor Steve Bullock of Montana announces his candidacy via a
video published on social media.

May 16: Mayor Bill de Blasio of New York City announces his candidacy
via a campaign video published on social media, and appears on Good
Morning America as part of a campaign launch.

May 31 – June 2: The California State Democratic Convention, a major
"cattle call" event attended by most major candidates, takes place.

June

June 5: Iowa Democrats' Hall of Fame Dinner: a "Cattle Call" event
featuring 19 candidates.

June 13: The Democratic National Committee announces that 20 candidates
will participate in the first official debate on June 26–27.

June 22: Former Representative Joe Sestak of Pennsylvania announces his
candidacy with a midnight campaign website launch.

June 26: The first part of the first official debate will take place in
Miami, Florida.

June 27: The second part of the first official debate will take place in
Miami, Florida.

July

July 30: The first part of the second official debate will take place in
Detroit, Michigan.

July 31: The second part of the second official debate will take place
in Detroit, Michigan.

September

September 12: The third official debate will take place, aired on ABC
and Univision.

September 13: If necessary, a second part of the third official debate
will take place.

Primary and caucus calendar
===========================

-   *As of June 2019\[update\], primaries and caucuses for the following
    states/territories are not yet scheduled:*

-   *April 7: Wisconsin primary*

-   *The final decision setting the format and date will be communicated
    via an updated plan in the summer of 2019.*

-   *June 7: Puerto Rico primary (Governor Ricardo Rosselló tabled a
    bill that would move it to March 29, which is expected to be
    approved by the legislative assembly during the summer of 2019, and
    earlier the Puerto Rico Democratic Party signalled they would revise
    their adopted Delegate Selection Plan accordingly.*

The following primary and caucus dates have been scheduled by state
statutes or state party decisions, but are subject to change pending
legislation, state party delegate selection plans, or the decisions of
state secretaries of state:

February 3: Iowa caucuses

February 11: New Hampshire primary

February 22: Nevada caucuses

February 29: South Carolina primary

March 3: Super Tuesday (Alabama, Arkansas, California, Colorado, Maine,
Massachusetts, Minnesota, North Carolina, Oklahoma, Tennessee, Texas,
Utah, Vermont, and Virginia primaries); Democrats Abroad party-run
primary for expatriates features a March 3–10 voting period.

March 10: Idaho, Michigan, Mississippi, Missouri, Ohio, and Washington
primaries; North Dakota firehouse caucuses (identical to a party-run
primary)

March 17: Arizona, Florida and Illinois primaries

March 24: Georgia primary

April 4: Alaska, Hawaii, and Louisiana primaries

April 7: Wisconsin primary

April 28: Connecticut, Delaware, Maryland, Pennsylvania, and Rhode
Island primaries

May 2: Kansas primary

May 5: Indiana primary

May 12: Nebraska and West Virginia primaries

May 19: Kentucky and Oregon primaries (Oregon legislature considering
move to March 3 or 10)

June 2: Montana, New Jersey, New Mexico, and South Dakota primaries

June 7: Puerto Rico primary (Governor Ricardo Rosselló tabled a bill
that would move it to March 29, which is expected to be approved by the
legislative assembly during the summer of 2019, and earlier the Puerto
Rico Democratic Party signalled they would revise their adopted Delegate
Selection Plan accordingly. Two competing bills likewise propose a move
to March 29, but compared to the governor's bill they also entail a
comprehensive reform of the entire election law.)

June 16: District of Columbia primary (bill proposing a move to June 2
has been tabled)

As of June 2019\[update\], primaries and caucuses for the following
states/territories are not yet scheduled:

American Samoa caucuses (previously held on March 1, 2016)

Northern Mariana Islands caucuses (previously held on March 12, 2016)

Wyoming caucuses (previously held on April 9, 2016): The state party
initially via its draft plan proposed a party-run caucus for March 2020,
then shortly considered moving it to April 18, but may have the option
of replacing it with a party-run primary (as a government-run primary is
not an option in the state). The final decision setting the format and
date will be communicated via an updated plan in the summer of 2019.

New York primary (previously held on April 19, 2016): The primary is
currently scheduled for a default February 4 date only for procedural
reasons, as setting the official date awaits the legislature's pass of a
bill to amend the existing election law. The Democratic draft delegate
selection plan proposed April 28 as the actual date for the primary, and
a month later this was adopted as the official plan of the state party.
Both chambers of the New York State Legislature also approved the plan,
which now only awaits approval of the governor to become a law.

Guam caucuses (previously held on May 7, 2016)

United States Virgin Islands caucuses (previously held on June 4, 2016)

The 57 states/district/territories with elections of pledged delegates
to decide the Democratic presidential nominee, currently plan to hold
the first major determining step for these elections via 49 primaries
and 6 caucuses (Iowa, Nevada and four territories), while two states
(Wyoming and Maine) have not yet decided their election format - as
their state parties currently consider approving last minute changes to
their earlier drafted state delegate selection plans. The number of
states holding caucuses decreased from 14 in the 2016 nomination process
to so far only two in 2020.

National convention
===================

-   *The 2020 Democratic National Convention is scheduled to take place
    in Milwaukee, Wisconsin on July 13–16, 2020.*

The 2020 Democratic National Convention is scheduled to take place in
Milwaukee, Wisconsin on July 13–16, 2020.

In addition to Milwaukee, the DNC also considered bids from three other
cities: Houston, Texas; Miami Beach, Florida; and Denver, Colorado.
Denver, though, was immediately withdrawn from consideration by
representatives for the city, who cited scheduling conflicts.

Endorsements
============

Primary election polling
========================

Political positions of candidates
=================================

Campaign finance
================

-   *This is an overview of the money being raised and spent by each
    campaign for the entire period running from January 1, 2017 to March
    31, 2019, as it was reported to the Federal Election Commission
    (FEC).*

-   *The last column, Cash On Hand (COH), has been calculated by
    subtracting the "spent" amount from the "raised" amount, thereby
    showing the remaining cash each campaign had available for its
    future spending as of March 31, 2019.*

This is an overview of the money being raised and spent by each campaign
for the entire period running from January 1, 2017 to March 31, 2019, as
it was reported to the Federal Election Commission (FEC). Total raised
are the sum of all individual contributions (large and small), loans
from the candidate, and transfers from other campaign committees. The
last column, Cash On Hand (COH), has been calculated by subtracting the
"spent" amount from the "raised" amount, thereby showing the remaining
cash each campaign had available for its future spending as of March 31,
2019.

See also
========

-   *2020 Libertarian Party presidential primaries*

-   *2020 Democratic National Convention*

-   *2020 Green Party presidential primaries*

-   *2020 Republican Party presidential primaries*

2020 Democratic National Convention

2020 Republican Party presidential primaries

2020 Green Party presidential primaries

2020 Libertarian Party presidential primaries

Notes
=====

References
==========
