**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/Trump%20Force%20One\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

Trump Force One
===============

-   *The current incarnation of Trump Force One is a Boeing 757, which
    replaced the preceding Boeing 727.*

-   *Trump Force One is an informal name for Donald Trump's private
    jet.*

-   *It is operated as part of "Trump Air", the air assets of The Trump
    Organization.*

Trump Force One is an informal name for Donald Trump's private jet. The
current incarnation of Trump Force One is a Boeing 757, which replaced
the preceding Boeing 727. It is operated as part of "Trump Air", the air
assets of The Trump Organization.

Boeing 727 (1997–2011)
======================

-   *Donald Trump repurchased it in 1997 as his private jet.*

-   *It later operated for Trump Shuttle, before being sold.*

-   *Trump put it up for sale in 2009, but was still using it in 2011,
    when he received the 757.*

The Boeing 727 was registered in Bermuda as VP-BDJ and was built in
1968. It was originally delivered to American Airlines. By 1981, it was
converted into a business jet for Diamond Shamrock. It later operated
for Trump Shuttle, before being sold. Donald Trump repurchased it in
1997 as his private jet. Trump put it up for sale in 2009, but was still
using it in 2011, when he received the 757. It was sold later in 2011,
and then operated by Weststar Aviation. The aircraft was scrapped at
Montréal–Mirabel International Airport in 2017.

When operating as Donald Trump's private jet, the plane was configured
with seating for 24, winglets, a master bedroom, bidet, dining room,
galley, conference rooms, and multiple lavatories.

Boeing 757 (2011–)
==================

-   *Trump used the 757 for transportation during his successful 2016
    presidential campaign.*

-   *After becoming President, Trump began to travel with Air Force
    One.*

-   *Donald Trump had planned to use the 757 for campaigning during his
    putative 2012 presidential bid.*

The Boeing 757-200 is registered in the United States as N757AF and was
built in 1991. It originally was delivered to Denmark's Sterling
Airlines, and later, by 1993, operated by Mexico's TAESA. In 1995, it
became a corporate business jet for Paul Allen's enterprises.

The aircraft is equipped with Rolls-Royce RB211 turbofans, a glass
cockpit, and is configured to seat 43. The plane is fitted with a dining
room, bathroom, shower, bedroom, guest room, and galley. Most fixtures
are coated in 24k gold.

Donald Trump had planned to use the 757 for campaigning during his
putative 2012 presidential bid. Trump used the 757 for transportation
during his successful 2016 presidential campaign. After becoming
President, Trump began to travel with Air Force One.

See also
========

-   *Private jet*

-   *Business jet*

Business jet

Private jet

VIP transport

References
==========

Further reading
===============

-   *"Trump 757".*

-   *Trump 757 on IMDb*

"Trump 757". Mighty Planes. Season 2. Episode 3. June 9, 2013. Discovery
Channel Canada.

Trump 757 on IMDb
