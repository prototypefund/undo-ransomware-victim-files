**From Wikipedia, the free encyclopedia**

https://en.wikipedia.org/wiki/First\_Lady\_of\_Botswana\
Licensed under CC BY-SA 3.0:\
https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_Creative\_Commons\_Attribution-ShareAlike\_3.0\_Unported\_License

First Lady of Botswana
======================

-   *The current First Lady is Neo Masisi, the wife of President
    Mokgweetsi Masisi.*

-   *The First Lady of the Republic of Botswana is the wife of the
    President of Botswana.*

The First Lady of the Republic of Botswana is the wife of the President
of Botswana. The current First Lady is Neo Masisi, the wife of President
Mokgweetsi Masisi.

History
=======

-   *There was no First Lady from 1 April 2008 to 1 April 2018, as
    President Ian Khama was unmarried.*

There was no First Lady from 1 April 2008 to 1 April 2018, as President
Ian Khama was unmarried. The absence of a First Lady was problematic for
some official functions, and there were moves to find a substitute for
some occasions. President Kharma's unmarried status was controversial
because of the requirements of tribal traditions.

First Ladies of Botswana
========================

See also
========

-   *List of heads of state of Botswana*

List of heads of state of Botswana

References
==========
